/*
 * VsStatement.cpp
 *
 *     Implementation of classes:
 *	  VsValue
 *        VsStatement
 *        VsReturn
 *        VsIf
 *        VsFor
 *
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 */

#include <assert.h>
#include "vsstatement.h"
#include "vsexpr.h"
#include "vsfunction.h"

const VsValue VsValue::nothing(0.0);

VsValue::VsValue(double num)
{
    type = vNUMBER;
    number = num;
}

VsValue::VsValue(void *ptr)
{
    type = vVOID;
    data = ptr;
}

VsValue::VsValue(char *str)
{
    type = vSTRING;
    string = str;
}

int
VsValue::getBool() const
{
    if (type == VsValue::vNUMBER) {
	if (number != 0.0) return 1;
    }
    else if (type == VsValue::vSTRING) {
	// Null or empty string is FALSE:
	if (string != NULL && string[0] != '\0') return 1;
    }
    return 0;
}


VsStatement::VsStatement()
{
}

VsStatement::~VsStatement()
{
}

VsReturn::VsReturn(VsExpr *expr)
{
    expression = expr;
    if (expression != NULL) {
	expression->ref();
    }
}

VsReturn::~VsReturn()
{
    if (expression != NULL) {
	expression->unref();
    }
}

VsStatement::Status
VsReturn::execute(VsFunctionCall *f)
{
    if (expression != NULL) {
	f->setReturnValue(expression->evaluate(f));
    }
    return VsStatement::RETURN;
}

VsIf::VsIf(VsExpr *_condition, VsStatementList *_if,
	   VsStatementList *_else)
{
    assert(_condition != NULL);

    condition = _condition;
    condition->ref();
    ifStatements = _if;
    elseStatements = _else;
}

VsIf::~VsIf()
{
    condition->unref();
    if (ifStatements != NULL) delete ifStatements;
    if (elseStatements != NULL) delete elseStatements;
}

VsStatement::Status
VsIf::execute(VsFunctionCall *f)
{
    VsStatement::Status result = VsStatement::NORMAL;

    // do either if or else statements, executing all the statements
    // on the list unless we hit a return, break, or continue statement.
    if (condition->evaluate(f).getBool()) {
	if (ifStatements != NULL) {
	    result = ifStatements->execute(f);
	}
    }
    else {
	if (elseStatements != NULL) {
	    result = elseStatements->execute(f);
	}
    }

    return result;
}

VsFor::VsFor(VsExpr *_initial, VsExpr *_condition, VsExpr *_increment,
	   VsStatementList *_body)
{
    assert(_body != NULL);

    body = _body;
    initial = _initial;
    if (initial) initial->ref();
    condition = _condition;
    if (condition) condition->ref();
    increment = _increment;
    if (increment) increment->ref();
}

VsFor::~VsFor()
{
    delete body;
    if (initial != NULL) initial->unref();
    if (increment != NULL) increment->unref();
    if (condition != NULL) condition->unref();
}

VsStatement::Status
VsFor::execute(VsFunctionCall *f)
{
    // The (void)1's here are annoying, but are necessary to keep the
    // compiler happy.
    for (initial ? (void)initial->evaluate(f) : (void)1;
	 condition ? condition->evaluate(f).getBool() : 1;
	 increment ? (void)increment->evaluate(f) : (void)1 ) {

	VsStatement::Status s = body->execute(f);

	if (s == VsStatement::CONTINUE) { 
	    continue;
	}
	if (s == VsStatement::BREAK) {
	    break;
	}
	if (s == VsStatement::RETURN) {
	    return s;
	}
    }
    return VsStatement::NORMAL;
}

VsForIn::VsForIn(VsVar *_variable, VsExpr *_object, VsStatementList *_body)
{
    assert(_body != NULL);

    body = _body;
    variable = _variable;
    if (variable) variable->ref();
    object = _object;
    if (object) object->ref();
}

VsForIn::~VsForIn()
{
    delete body;
    if (variable != NULL) variable->unref();
    if (object != NULL)   object->unref();
}

VsStatement::Status
VsForIn::execute(VsFunctionCall *f)
{
    // NOT IMPLEMENTED YET - DO NOTHING

    return VsStatement::NORMAL;
}

VsWhile::VsWhile(VsExpr *_condition, VsStatementList *_body)
{
    assert(_body != NULL && _condition != NULL);

    body = _body;

    condition = _condition;
    condition->ref();
}

VsWhile::~VsWhile()
{
    assert (condition != NULL);

    delete body;
    condition->unref();
}

VsStatement::Status
VsWhile::execute(VsFunctionCall *f)
{
    assert (condition != NULL);

    while (condition->evaluate(f).getBool()) {
	VsStatement::Status s = body->execute(f);

	if (s == VsStatement::CONTINUE) { 
	    continue;
	}
	if (s == VsStatement::BREAK) {
	    break;
	}
	if (s == VsStatement::RETURN) {
	    return s;
	}
    }   

    return VsStatement::NORMAL;
}

VsBreak::VsBreak()
{
}

VsBreak::~VsBreak()
{
}

VsStatement::Status
VsBreak::execute(VsFunctionCall *f)
{
    return VsStatement::BREAK;
}

VsContinue::VsContinue()
{

}

VsContinue::~VsContinue()
{
}

VsStatement::Status
VsContinue::execute(VsFunctionCall *f)
{
    return VsStatement::CONTINUE;
}

VsWith::VsWith(VsExpr *_object, VsStatementList* _body)
{
    object = _object;
    if (object) object->ref();

    assert(_body != NULL);

    body = _body;

}

VsWith::~VsWith()
{
    if (object) object->unref();

    delete body;
}

VsStatement::Status
VsWith::execute(VsFunctionCall *f)
{
    // CURRENTLY UNIMPLEMENTED - DO NOTHING

    return VsStatement::NORMAL;
}

VsStatementList::~VsStatementList()
{
    for (int i = 0; i < getLength(); i++) {
	if ((*this)[i] != NULL) {
    	    delete (*this)[i];
	}
    }
}

VsStatement::Status
VsStatementList::execute(VsFunctionCall *f)
{
    VsStatement::Status result = VsStatement::NORMAL;

    for (int i = 0; i < getLength() && result == VsStatement::NORMAL; i++) {
	result = (*this)[i]->execute(f);
    }
    return result;
}
