/*
 * VbString.h
 *
 *      Declaration of classes:
 *        VbString
 *	  VbName
 *        VbNameEntry
 *	  
 *
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 *
 */


#ifndef _VB_STRING_
#define _VB_STRING_

#include "system.h"

#include "VbBasic.h"
#include <string.h>

class AFX_EXT_CLASS VbString {
  public:
    VbString()				{ string = staticStorage; 
					  string[0] = '\0'; }
    VbString(const char *str)		{ string = staticStorage;
					  *this = str; }
    VbString(const VbString &str)	{ string = staticStorage;
					  *this = str.string; }
    ~VbString();
    u_long		hash()		{ return VbString::hash(string); }
    int			getLength() const	{ return strlen(string); }
    void		makeEmpty(VbBool freeOld = TRUE);
    const char *	getString() const	{ return string; }
    VbString &		operator =(const char *str);
    VbString &		operator =(const VbString &str)
	{ return (*this = str.string); }
    VbString &		operator +=(const char *str);
    VbString &		operator +=(const VbString &str);
    
    int			operator !() const { return (string[0] == '\0'); }
    friend int AFX_EXT_API operator ==(const VbString &str, const char *s);
   
    friend int		operator ==(const char *s, const VbString &str)
	{ return (str == s); }
    
    friend int		operator ==(const VbString &str1, const VbString &str2)
	{ return (str1 == str2.string); }
    friend int AFX_EXT_API operator !=(const VbString &str, const char *s);
    
    friend int		operator !=(const char *s, const VbString &str)
	{ return (str != s); }
    friend int		operator !=(const VbString &str1,
				    const VbString &str2)
	{ return (str1 != str2.string); }
    static u_long	hash(const char *s);
    
    // Deletes the characters from startChar to endChar, inclusive,
    // from the string. If endChar is -1 (the default), all characters
    // from startChar until the end are deleted.
    void		deleteSubString(int startChar, int endChar = -1);
    
    // Returns new string representing sub-string from startChar to
    // endChar, inclusive. If endChar is -1 (the default), the
    // sub-string from startChar until the end is returned.
    VbString		getSubString(int startChar, int endChar = -1) const;    
        	
  private:
    char		*string;
    int			storageSize;
#define VB_STRING_STATIC_STORAGE_SIZE		32
    char		staticStorage[VB_STRING_STATIC_STORAGE_SIZE];
    void		expand(int bySize);
};

class AFX_EXT_CLASS VbNameEntry {
 public:
    VbBool		isEmpty() const   { return (string[0] == '\0'); }
    VbBool		isEqual(const char *s) const
	{ return (string[0] == s[0] && ! strcmp(string, s)); }

 private:
    static int		nameTableSize;
    static VbNameEntry	**nameTable;
    static struct VbNameChunk *chunk;		
    const char		*string;
    u_long		hashValue;
    VbNameEntry		*next;			
    static void		initClass();
    VbNameEntry(const char *s, u_long h, VbNameEntry *n)
	{ string = s; hashValue = h; next = n; }
    static const VbNameEntry *	insert(const char *s);

friend class VbName;
};

class AFX_EXT_CLASS VbName {
  public:
    VbName();
    VbName(const char *s)		{ entry = VbNameEntry::insert(s); }
    VbName(const VbString &s)	{ entry = VbNameEntry::insert(s.getString()); }

    VbName(const VbName &n)			{ entry = n.entry; }
    ~VbName()					{}
    const char		*getString() const	{ return entry->string; }
    int			getLength() const   { return strlen(entry->string); }
    static VbBool 	isIdentStartChar(char c);
    static VbBool	isIdentChar(char c);
    static VbBool 	isNodeNameStartChar(char c);
    static VbBool	isNodeNameChar(char c);
    int			operator !() const   { return entry->isEmpty(); }
    friend int		operator ==(const VbName &n, const char *s)
	{ return n.entry->isEqual(s); }
    friend int		operator ==(const char *s, const VbName &n)
	{ return n.entry->isEqual(s); }
    
    friend int 		operator ==(const VbName &n1, const VbName &n2)
	{ return n1.entry == n2.entry; }
    friend int		operator !=(const VbName &n, const char *s)
	{ return ! n.entry->isEqual(s); }
    friend int		operator !=(const char *s, const VbName &n)
	{ return ! n.entry->isEqual(s); }
    
    friend int 		operator !=(const VbName &n1, const VbName &n2)
	{ return n1.entry != n2.entry; }
  private:
    const VbNameEntry	*entry;
};

#endif /* _VB_STRING_ */
