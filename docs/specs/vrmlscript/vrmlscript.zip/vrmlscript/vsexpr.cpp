/*
 * VsExpr.c++
 *
 *     Implementation of classes:
 *        VsExpr
 *        VsConstant
 *        VsAssign
 *        VsArith
 *        VsLogicOp
 *	  VsUArithOp
 *	  VsULogicOp
 *	  VsUIncDec
 *	  VsComma
 *	  VsArrayVar
 *
 * Expressions
 * 
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 */

#include <assert.h>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>

#ifdef __sgi
#include <Inventor/SbString.h>
#else
#include "vbstring.h"
#endif

#include "vsexpr.h"

class VsFunctionDef;
class VsFunctionCall;

#include "y.tab.h"  /* For the PLUS/etc #defines */

VsExpr::VsExpr()
{
    refCount = 0;
}

void
VsExpr::ref()
{
    ++refCount;
}

void
VsExpr::unref()
{
    --refCount;
    if (refCount <= 0) delete this;
}

VsExpr::~VsExpr()
{
}


VsValue
VsVar::assign(const VsValue &v, int32_t, VsFunctionCall *f)
{
    return assign(v, f);
}

VsStatement::Status
VsExpr::execute(VsFunctionCall *f)
{
    evaluate(f);  // Ignore resulting value...
    return VsStatement::NORMAL;
}

VsConstant::VsConstant(const char *string)
{
    myValue.type = VsValue::vSTRING;
    myValue.string = (char *)string;	// string is alloc'ed in scan.lpp
					// can be freed in here
}

VsConstant::VsConstant(double number)
{
    myValue.type = VsValue::vNUMBER;
    myValue.number = number;
}

VsConstant::~VsConstant()
{
    if (myValue.type == VsValue::vSTRING) {
	delete[] myValue.string;
    }
}

VsValue
VsConstant::evaluate(VsFunctionCall *)
{
    return myValue;
}

///////////////////////////////////////////////////////////////////////////

VsArrayVar::VsArrayVar(VsExpr *_array, VsExpr *_subscript)
{
    array     = (VsVar *)_array;  // for now, assume this is a Var
    subscript = _subscript;

    if (array != NULL) {
        array->ref();
    }
    if (subscript != NULL) {
        subscript->ref();	
    }
}

VsArrayVar::~VsArrayVar()
{
    if (array != NULL) {
        array->unref();
    }
    if (subscript != NULL) {
        subscript->unref();
    }
}

VsValue
VsArrayVar::evaluate(VsFunctionCall *f)
{
    if ((array == NULL) || (subscript == NULL)) {
	return VsValue(0.0);
    }

    const VsValue &sub = subscript->evaluate(f);
    int32_t index = (int32_t)sub.number;

    const VsValue &arr = array->evaluate(f);

    if ((arr.type == VsValue::vFLOAT_ARRAY) ||
	(arr.type == VsValue::vROTATION)) {
	return(arr.floatArray->array[index]);
    } else if (arr.type == VsValue::vINT32_ARRAY) {
	return(arr.int32Array->array[index]);
    } else if (arr.type == VsValue::vSTRING_ARRAY) {
	return((char *)(arr.stringArray->array[index].getString()));
    } else if (arr.type == VsValue::vVOID_ARRAY) {
	return(arr.voidArray->array[index]);
    } else {
//	fprintf(stderr, "BAD TYPE OF ARRAY VAR\n");
    }

    return VsValue(0.0);
}

VsValue
VsArrayVar::assign(const VsValue &v, VsFunctionCall* f)
{
    if ((array == NULL) || (subscript == NULL)) {
	// ERROR
	return VsValue(0.0);
    }     

    const VsValue &ss = subscript->evaluate(f);
    int32_t index = (int32_t)ss.number;

    VsValue arr = array->evaluate(f);

    if ((arr.type == VsValue::vFLOAT_ARRAY) ||
        (arr.type == VsValue::vROTATION)) {
	array->assign(v, index, f);
        return(arr.floatArray->array[index]);
    } else if (arr.type == VsValue::vINT32_ARRAY) {
	array->assign(v, index, f);
        return(arr.int32Array->array[index]);
    } else if (arr.type == VsValue::vSTRING_ARRAY) {
	array->assign(v, index, f);
        return((char *)(arr.stringArray->array[index].getString()));
    } else if (arr.type == VsValue::vVOID_ARRAY) {
	array->assign(v, index, f);
        return(arr.voidArray->array[index]);
    } else {
//	fprintf(stderr, "BAD TYPE OF ARRAY VAR 2\n");
    }

    return VsValue(0.0);
}

VsAssign::VsAssign(VsVar *v, VsExpr *e)
{
//    assert(v != NULL && e != NULL);

    var = v;
    if (var != NULL) {
        var->ref();
    }
    expr = e;
    
    if (expr != NULL) {
        expr->ref();
    }
}

VsAssign::~VsAssign()
{
    if (var != NULL) {	
        var->unref();
    }
    if (expr != NULL) {
        expr->unref();
    }
}

VsValue
VsAssign::evaluate(VsFunctionCall *f)
{
    // This is the normal scalar assignment.
    if ((var != NULL) && (expr != NULL)) {
        return var->assign(expr->evaluate(f), f);
    } else {
	return VsValue(0.0);
    }
}

VsArith::VsArith(VsExpr *e1, VsExpr *e2, int op)
{
//    assert(e1 != NULL && e2 != NULL);

    expr1 = e1;
    if (expr1 != NULL) {
        expr1->ref();
    }
    expr2 = e2;
    if (expr2 != NULL) {
        expr2->ref();
    }
    operation = op;
}

VsArith::~VsArith()
{
    if (expr1 != NULL) {
        expr1->unref();
    }
    if (expr2 != NULL) {
        expr2->unref();
    }
}

VsValue
VsArith::evaluate(VsFunctionCall *f)
{
    if ((expr1 == NULL) || (expr2 == NULL)) {
	return VsValue(0.0);
    }

    const VsValue &v1 = expr1->evaluate(f);
    const VsValue &v2 = expr2->evaluate(f);

    VsValue result;
    int32_t tempInt;

    if (v1.type == VsValue::vNUMBER && v2.type == VsValue::vNUMBER) {
	result.type = VsValue::vNUMBER;

	switch (operation) {
	  case tPLUS:
	    result.number = v1.number + v2.number;
	    break;
	  case tMINUS:
	    result.number = v1.number - v2.number;
	    break;
	  case tMULTIPLY:
	    result.number = v1.number * v2.number;
	    break;
	  case tDIVIDE:
	    result.number = v1.number / v2.number;
	    break;
	  case tMOD:
	    result.number = ((int32_t)v1.number) % ((int32_t)v2.number);
	    break;
	  case tAND:
	    result.number = ((uint32_t)v1.number) & ((uint32_t)v2.number);
	    break;
	  case tOR:
	    result.number = ((uint32_t)v1.number) | ((uint32_t)v2.number);
	    break;
	  case tXOR:
	    result.number = ((uint32_t)v1.number) ^ ((uint32_t)v2.number);
	    break;
	  case tLSHIFT:
	    result.number = ((uint32_t)v1.number) << ((uint32_t)v2.number);
	    break;
	  case tRSHIFT:
	    result.number = ((uint32_t)v1.number) >> ((uint32_t)v2.number);
	    break;
	  case tRSHIFTFILL:
	    // make sure high order bit is zero before shifting
	    if (v2.number >= 1) {
		tempInt = (uint32_t)v1.number & 0x7FFFFFFF;
	    } else {
		tempInt = (uint32_t)v1.number;
	    }
	    result.number = (tempInt >> ((int32_t)v2.number));
	    break;
	  default:
	    assert(0);
	    break;
	}
    }
    return result;
}

VsCondExpr::VsCondExpr(VsExpr *t, VsExpr *e1, VsExpr *e2)
{
//    assert(t != NULL && e1 != NULL && e2 != NULL);

    test = t;
    if (test != NULL) {
        test->ref();
    }
    expr1 = e1;
    if (expr1 != NULL) {
        expr1->ref();
    }
    expr2 = e2;
    if (expr2 != NULL) {   
        expr2->ref();
    }
}

VsCondExpr::~VsCondExpr()
{
    if (test != NULL) {
        test->unref();
    }
    if (expr1 != NULL) {
        expr1->unref();
    }
    if (expr2 != NULL) {
        expr2->unref();
    }
}

VsValue
VsCondExpr::evaluate(VsFunctionCall *f)
{
    if (test == NULL) {
	return VsValue(0.0);
    }

    if (test->evaluate(f).getBool()) {
	if (expr1 == NULL) {
	    return VsValue(0.0);
	}
	return expr1->evaluate(f);
    }
    else {
	if (expr2 == NULL) {
	    return VsValue(0.0);
	}
	return expr2->evaluate(f);
    }
}

VsIncDec::VsIncDec(VsExpr *_var, int _increment, int _prefix)
{
//    assert (_var != NULL);

    var = (VsVar *)_var;
    if (var != NULL) {
        var->ref();
    }

    increment = _increment;
    prefix    = _prefix;
    
}

VsIncDec::~VsIncDec()
{
    if (var != NULL) {
        var->unref();
    }
}

VsValue
VsIncDec::evaluate(VsFunctionCall *f)
{
    if (var == NULL) {
	return VsValue(0.0);
    }

    const VsValue &initval = var->evaluate(f);

    VsValue newval = initval;

    if (initval.type == VsValue::vNUMBER) {
	if (increment) {
	    newval.number += 1;
	} else {
	    newval.number -= 1;
	}
    } else {
	// JavaScript only allows increment/decrement for numeric types
	// ??? warn if not numeric ???
    }

    // This is the normal scalar assignment.
    var->assign(newval, f);

    if (prefix) {
	return newval;
    } else {
	return initval;
    }
}

VsUArithOp::VsUArithOp(VsExpr *e, int op)
{
//    assert(e != NULL);

    expr = e;
    if (expr != NULL) {
        expr->ref();
    }

    operation = op;
}

VsUArithOp::~VsUArithOp()
{
    if (expr != NULL) {
        expr->unref();
    }
}

VsValue
VsUArithOp::evaluate(VsFunctionCall *f)
{
    if (expr == NULL) {
	return VsValue(0.0);
    }

    const VsValue &v = expr->evaluate(f);

    VsValue result;


    if (v.type == VsValue::vNUMBER) {
    	result.type = VsValue::vNUMBER;

	switch (operation) {
	  case tMINUS:
	    result.number = -v.number;
	    break;
	  case tONESCOMP:
	    result.number = ~((int32_t)v.number);
	    break;
	  default:
	    assert(0);
	    break;
	}
    }

    return result;
}

VsLogicOp::VsLogicOp(VsExpr *e1, VsExpr *e2, int op)
{
//    assert(e1 != NULL && e2 != NULL);

    expr1 = e1;
    if (expr1 != NULL) {
        expr1->ref();
    }
    expr2 = e2;
    if (expr2 != NULL) {
        expr2->ref();
    }
    operation = op;
}

VsLogicOp::~VsLogicOp()
{
    if (expr1 != NULL) {
        expr1->unref();
    }
    if (expr2 != NULL) {
        expr2->unref();
    }
}

VsValue
VsLogicOp::evaluate(VsFunctionCall *f)
{
    if (expr1 == NULL) {
	return VsValue(0.0);
    }

    const VsValue &v1 = expr1->evaluate(f);

    VsValue result;
    result.type = VsValue::vNUMBER;

    // short circuit evaluation
    // if operation is LAND or LOR, don't always evaluate v2
    if ((operation == tLAND) && (v1.getBool() == FALSE)) {
	result.number = FALSE;

	return result;
    } else if ((operation == tLOR) && (v1.getBool() == TRUE)) {
	result.number = TRUE;

	return result;
    }

    if (expr2 == NULL) {
	return VsValue(0.0);
    }

    const VsValue &v2 = expr2->evaluate(f);

    if (v1.type == VsValue::vNUMBER && v2.type == VsValue::vNUMBER) {
	switch (operation) {
	  case tEQ:
	    result.number = (v1.number == v2.number);
	    break;
	  case tNE:
	    result.number = (v1.number != v2.number);
	    break;
	  case tLT:
	    result.number = (v1.number < v2.number);
	    break;
	  case tLE:
	    result.number = (v1.number <= v2.number);
	    break;
	  case tGT:
	    result.number = (v1.number > v2.number);
	    break;
	  case tGE:
	    result.number = (v1.number >= v2.number);
	    break;
	  case tLAND:
	    result.number = v1.number && v2.number;
	    break;
	  case tLOR:
	    result.number = v1.number || v2.number;
	    break;
	  default:
	    assert(0);
	    break;
	}
    }
    else if (v1.type == VsValue::vSTRING || v2.type == VsValue::vSTRING) {
	const char *s1;
	const char *s2;
	char scratch[26];
	if (v1.type == VsValue::vNUMBER) {
	    sprintf(scratch, "%d", v1.number);
	    s1 = scratch; s2 = v2.string;
	} else if (v2.type == VsValue::vNUMBER) {
	    sprintf(scratch, "%d", v2.number);
	    s2 = scratch; s1 = v1.string;
	} else if (v1.type != VsValue::vSTRING || 
		    v2.type != VsValue::vSTRING) {
	    // ??? ERROR ???
	    result.number = 0.0;
	    return result;
	}

	int cmp = strcmp(s1, s2);

	switch (operation) {
	  case tEQ:
	    result.number = (cmp == 0);
	    break;
	  case tNE:
	    result.number = (cmp != 0);
	    break;
	  case tLT:
	    result.number = (cmp < 0);
	    break;
	  case tLE:
	    result.number = (cmp <= 0);
	    break;
	  case tGT:
	    result.number = (cmp > 0);
	    break;
	  case tGE:
	    result.number = (cmp >= 0);
	    break;
	  default:
	    assert(0);
	    break;
	}
    }
    return result;
}

VsULogicOp::VsULogicOp(VsExpr *e, int op)
{
//    assert(e != NULL);

    expr = e;
    if (expr != NULL) {
        expr->ref();
    }
    operation = op;
}

VsULogicOp::~VsULogicOp()
{
    if (expr != NULL) {
        expr->unref();
    }
}

VsValue
VsULogicOp::evaluate(VsFunctionCall *f)
{
    if (expr == NULL) {
	return VsValue(0.0);
    }

    const VsValue &v = expr->evaluate(f);

    VsValue result;
    result.type = VsValue::vNUMBER;

    if (v.type == VsValue::vNUMBER) {
	switch (operation) {
	  case tNOT:
	    result.number = ! (v.number != 0.0);
	    break;
	  default:
	    assert(0);
	    break;
	}
    }
    else if (v.type == VsValue::vSTRING) {
        if (v.string && v.string[0] != '\0')
            result.number = 0.0;
        else
            result.number = 1.0;
    }
    return result;
}

VsComma::VsComma(VsExpr *e1, VsExpr *e2)
{
    expr1 = e1;
    if (expr1 != NULL) {
        expr1->ref();
    }
    expr2 = e2;
    if (expr2 != NULL) {
        expr2->ref();
    }
}

VsComma::~VsComma()
{
    if (expr1 != NULL) {
        expr1->unref();
    }
    if (expr2 != NULL) {
        expr2->unref();
    }
}

VsValue
VsComma::evaluate(VsFunctionCall *f)
{
    if (expr1 != NULL) {
	expr1->evaluate(f);
    }

    if (expr2 != NULL) {
	VsValue result = expr2->evaluate(f);

	return result;
    } else {
	return VsValue(0.0);
    }
}
