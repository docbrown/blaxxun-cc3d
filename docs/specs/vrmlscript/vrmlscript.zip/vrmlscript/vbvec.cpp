/*
 * Copyright (C) 1996   Silicon Graphics, Inc.
 *
 _______________________________________________________________________
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 |
 |   $Revision: 1.2 $
 |
 |   Classes:
 |	VbVec3f
 |	VbVec2f
 |
 |   Author(s)		: Paul S. Strauss, Nick Thompson, Alain Dumesny
 |      (for the PC)    : Jim Kent, Daniel Woods
 |
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 _______________________________________________________________________
 */

#include "VbLinear.h"

// amount squared to figure if two floats are equal
#define DELTA 1e-6


//////////////////////////////////////////////////////////////////////////////
//
// Vec3f class
//
//////////////////////////////////////////////////////////////////////////////

/* COMMENTED OUT FOR PC
//
// constructor that creates vector from intersection of three planes
//

#define DET3(m) (( 			\
    m[0][0] * m[1][1] * m[2][2]	\
  + m[0][1] * m[1][2] * m[2][0]	\
  + m[0][2] * m[1][0] * m[2][1]	\
  - m[2][0] * m[1][1] * m[0][2]	\
  - m[2][1] * m[1][2] * m[0][0]	\
  - m[2][2] * m[1][0] * m[0][1]))

VbVec3f::VbVec3f(VbPlane &p0, VbPlane &p1, MBPlane &p2)
{
    float	v[3], del, mx[3][3], mi[3][3];

    // create 3x3 matrix of normal coefficients
    mx[0][0] = p0.getNormal()[0];
    mx[0][1] = p0.getNormal()[1];
    mx[0][2] = p0.getNormal()[2];
    mx[1][0] = p1.getNormal()[0];
    mx[1][1] = p1.getNormal()[1];
    mx[1][2] = p1.getNormal()[2];
    mx[2][0] = p2.getNormal()[0];
    mx[2][1] = p2.getNormal()[1];
    mx[2][2] = p2.getNormal()[2];

    // find determinant of matrix to use for divisor
    del = DET3(mx);

//    printf("mx = %10.5f %10.5f %10.5f\n", mx[0][0], mx[0][1], mx[0][2]);
//    printf("     %10.5f %10.5f %10.5f\n", mx[1][0], mx[1][1], mx[1][2]);
//    printf("     %10.5f %10.5f %10.5f\n", mx[2][0], mx[2][1], mx[2][2]);
    if(del > -DELTA && del < DELTA) {	// if singular, just set to the origin
	vec[0] = 0;
	vec[1] = 0;
	vec[2] = 0;
    }
    else {
	v[0] = p0.getDistanceFromOrigin();
	v[1] = p1.getDistanceFromOrigin();
	v[2] = p2.getDistanceFromOrigin();

//	printf("v = %10.5f\n    %10.5f\n    %10.5f\n", v[0], v[1], v[2]);

	mi[0][0] = v[0]; mi[0][1] = mx[0][1]; mi[0][2] = mx[0][2];
	mi[1][0] = v[1]; mi[1][1] = mx[1][1]; mi[1][2] = mx[1][2];
	mi[2][0] = v[2]; mi[2][1] = mx[2][1]; mi[2][2] = mx[2][2];

//	printf("mi = %10.5f %10.5f %10.5f\n", mi[0][0], mi[0][1], mi[0][2]);
//	printf("     %10.5f %10.5f %10.5f\n", mi[1][0], mi[1][1], mi[1][2]);
//	printf("     %10.5f %10.5f %10.5f\n", mi[2][0], mi[2][1], mi[2][2]);

	vec[0] = DET3(mi) / del;
	mi[0][0] = mx[0][0]; mi[0][1] = v[0]; mi[0][2] = mx[0][2];
	mi[1][0] = mx[1][0]; mi[1][1] = v[1]; mi[1][2] = mx[1][2];
	mi[2][0] = mx[2][0]; mi[2][1] = v[2]; mi[2][2] = mx[2][2];

//	printf("mi = %10.5f %10.5f %10.5f\n", mi[0][0], mi[0][1], mi[0][2]);
//	printf("     %10.5f %10.5f %10.5f\n", mi[1][0], mi[1][1], mi[1][2]);
//	printf("     %10.5f %10.5f %10.5f\n", mi[2][0], mi[2][1], mi[2][2]);

	vec[1] = DET3(mi) / del;
	mi[0][0] = mx[0][0]; mi[0][1] = mx[0][1]; mi[0][2] = v[0];
	mi[1][0] = mx[1][0]; mi[1][1] = mx[1][1]; mi[1][2] = v[1];
	mi[2][0] = mx[2][0]; mi[2][1] = mx[2][1]; mi[2][2] = v[2];

//	printf("mi = %10.5f %10.5f %10.5f\n", mi[0][0], mi[0][1], mi[0][2]);
//	printf("     %10.5f %10.5f %10.5f\n", mi[1][0], mi[1][1], mi[1][2]);
//	printf("     %10.5f %10.5f %10.5f\n", mi[2][0], mi[2][1], mi[2][2]);

	vec[2] = DET3(mi) / del;
    }

//    printf("%10.5f %10.5f %10.5f\n", vec[0], vec[1], vec[2]);
}
   END COMMENTED OUT FOR PC */

//
// Returns right-handed cross product of vector and another vector
//

VbVec3f
VbVec3f::cross(const VbVec3f &v) const
{
    return VbVec3f(vec[1] * v.vec[2] - vec[2] * v.vec[1],
		  vec[2] * v.vec[0] - vec[0] * v.vec[2],
		  vec[0] * v.vec[1] - vec[1] * v.vec[0]);
}

//
// Returns dot (inner) product of vector and another vector
//

float
VbVec3f::dot(const VbVec3f &v) const
{
    return (vec[0] * v.vec[0] +
	    vec[1] * v.vec[1] +
	    vec[2] * v.vec[2]);
}

//
// Returns 3 individual components
//

void
VbVec3f::getValue(float &x, float &y, float &z) const
{
    x = vec[0];
    y = vec[1];
    z = vec[2];
}

//
// Returns geometric length of vector
//

float
VbVec3f::length() const
{
    return (float)sqrt(vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2]);
}

//
// Negates each component of vector in place
//

void
VbVec3f::negate()
{
    vec[0] = -vec[0];
    vec[1] = -vec[1];
    vec[2] = -vec[2];
}

//
// Changes vector to be unit length
//

float
VbVec3f::normalize()
{
    float len = length();

    if (len != 0.0)
	(*this) *= (1.0f / len);

    else setValue(0.0f, 0.0f, 0.0f);

    return len;
}

VbVec3f &
VbVec3f::setValue(const VbVec3f &barycentric,
		  const VbVec3f &v0, const VbVec3f &v1, const VbVec3f &v2)
{
    *this = v0 * barycentric[0] + v1 * barycentric[1] + v2 * barycentric[2];
    return (*this);
}
    

//
// Component-wise scalar multiplication operator
//

VbVec3f &
VbVec3f::operator *=(float d)
{
    vec[0] *= d;
    vec[1] *= d;
    vec[2] *= d;

    return *this;
}

//
// Component-wise vector addition operator
//

VbVec3f &
VbVec3f::operator +=(VbVec3f v)
{
    vec[0] += v.vec[0];
    vec[1] += v.vec[1];
    vec[2] += v.vec[2];

    return *this;
}

//
// Component-wise vector subtraction operator
//

VbVec3f &
VbVec3f::operator -=(VbVec3f v)
{
    vec[0] -= v.vec[0];
    vec[1] -= v.vec[1];
    vec[2] -= v.vec[2];

    return *this;
}

//
// Nondestructive unary negation - returns a new vector
//

VbVec3f
VbVec3f::operator -() const
{
    return VbVec3f(-vec[0], -vec[1], -vec[2]);
}

//
// Component-wise binary scalar multiplication operator
//

VbVec3f
operator *(const VbVec3f &v, float d)
{
    return VbVec3f(v.vec[0] * d,
		  v.vec[1] * d,
		  v.vec[2] * d);
}

//
// Component-wise binary vector addition operator
//

VbVec3f
operator +(const VbVec3f &v1, const VbVec3f &v2)
{
    return VbVec3f(v1.vec[0] + v2.vec[0],
		  v1.vec[1] + v2.vec[1],
		  v1.vec[2] + v2.vec[2]);
}

//
// Component-wise binary vector subtraction operator
//

VbVec3f
operator -(const VbVec3f &v1, const VbVec3f &v2)
{
    return VbVec3f(v1.vec[0] - v2.vec[0],
		   v1.vec[1] - v2.vec[1],
		   v1.vec[2] - v2.vec[2]);
}

//
// Equality comparison operator. Componenents must match exactly.
//

int
operator ==(const VbVec3f &v1, const VbVec3f &v2)
{
    return (v1.vec[0] == v2.vec[0] &&
	    v1.vec[1] == v2.vec[1] &&
	    v1.vec[2] == v2.vec[2]);
}

//
// Equality comparison operator within a tolerance.
//

VbBool
VbVec3f::equals(const VbVec3f v, float tolerance) const
{
    VbVec3f	diff = *this - v;

    return diff.dot(diff) <= tolerance;
}

//
// Returns principal axis that is closest (based on maximum dot
// product) to this vector.
//

VbVec3f
VbVec3f::getClosestAxis() const
{
    VbVec3f	axis(0.0f, 0.0f, 0.0f), bestAxis;
    float	d, max = -21.234f;

#define TEST_AXIS()							      \
    if ((d = dot(axis)) > max) {					      \
	max = d;							      \
	bestAxis = axis;						      \
    }

    axis[0] = 1.0f;	// +x axis
    TEST_AXIS();

    axis[0] = -1.0f;	// -x axis
    TEST_AXIS();
    axis[0] = 0.0f;

    axis[1] = 1.0f;	// +y axis
    TEST_AXIS();

    axis[1] = -1.0f;	// -y axis
    TEST_AXIS();
    axis[1] = 0.0f;

    axis[2] = 1.0f;	// +z axis
    TEST_AXIS();

    axis[2] = -1.0f;	// -z axis
    TEST_AXIS();

#undef TEST_AXIS

    return bestAxis;
}

//////////////////////////////////////////////////////////////////////////////
//
// Vec2f class
//
//////////////////////////////////////////////////////////////////////////////

//
// Returns dot (inner) product of vector and another vector
//

float
VbVec2f::dot(const VbVec2f &v) const
{
    return vec[0] * v.vec[0] + vec[1] * v.vec[1];
}

//
// Returns 2 individual components
//

void
VbVec2f::getValue(float &x, float &y) const
{
    x = vec[0];
    y = vec[1];
}

//
// Returns geometric length of vector
//

float
VbVec2f::length() const
{
    return (float)sqrt(vec[0] * vec[0] + vec[1] * vec[1]);
}

//
// Negates each component of vector in place
//

void
VbVec2f::negate()
{
    vec[0] = -vec[0];
    vec[1] = -vec[1];
}

//
// Changes vector to be unit length
//

float
VbVec2f::normalize()
{
    float len = length();

    if (len != 0.0f)
	(*this) *= (1.0f / len);

    else setValue(0.0f, 0.0f);

    return len;
}

//
// Sets value of vector from array of 2 components
//

VbVec2f &
VbVec2f::setValue(const float v[2])	
{
    vec[0] = v[0];
    vec[1] = v[1];

    return (*this);
}

//
// Sets value of vector from 2 individual components
//

VbVec2f &
VbVec2f::setValue(float x, float y)	
{
    vec[0] = x;
    vec[1] = y;

    return (*this);
}

//
// Component-wise scalar multiplication operator
//

VbVec2f &
VbVec2f::operator *=(float d)
{
    vec[0] *= d;
    vec[1] *= d;

    return *this;
}

//
// Component-wise vector addition operator
//

VbVec2f &
VbVec2f::operator +=(const VbVec2f &u)
{
    vec[0] += u.vec[0];
    vec[1] += u.vec[1];

    return *this;
}

//
// Component-wise vector subtraction operator
//

VbVec2f &
VbVec2f::operator -=(const VbVec2f &u)
{
    vec[0] -= u.vec[0];
    vec[1] -= u.vec[1];

    return *this;
}

//
// Nondestructive unary negation - returns a new vector
//

VbVec2f
VbVec2f::operator -() const
{
    return VbVec2f(-vec[0], -vec[1]);
}


//
// Component-wise binary scalar multiplication operator
//

VbVec2f
operator *(const VbVec2f &v, float d)
{
    return VbVec2f(v.vec[0] * d, v.vec[1] * d);
}

//
// Component-wise binary vector addition operator
//

VbVec2f
operator +(const VbVec2f &v1, const VbVec2f &v2)
{
    return VbVec2f(v1.vec[0] + v2.vec[0],
		  v1.vec[1] + v2.vec[1]);
}

//
// Component-wise binary vector subtraction operator
//

VbVec2f
operator -(const VbVec2f &v1, const VbVec2f &v2)
{
    return VbVec2f(v1.vec[0] - v2.vec[0],
		  v1.vec[1] - v2.vec[1]);
}

//
// Equality comparison operator. Componenents must match exactly.
//

int
operator ==(const VbVec2f &v1, const VbVec2f &v2)
{
    return (v1.vec[0] == v2.vec[0] &&
	    v1.vec[1] == v2.vec[1]);
}

//
// Equality comparison operator within a tolerance.
//

VbBool
VbVec2f::equals(const VbVec2f v, float tolerance) const
{
    VbVec2f	diff = *this - v;

    return diff.dot(diff) <= tolerance;
}

