
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
    const char *string;
    double number;
    VsExpr *expr;
    VsVar *var;
    VsArrayVar *arrayvar;
    VsFunctionDef *funcDef;
    VsFunctionCall *funcCall;
    VsMethodCall   *objMethodCall;
    VsMemberAccess *objMemberAccess;
    VsStatement *stmnt;
    VsExprList *exprList;
    VsStatementList *stmntList;
} YYSTYPE;
extern YYSTYPE yylval;
# define tNUMBER 257
# define tSTRING 258
# define tIDENTIFIER 259
# define tUNIMPL_KEYWORD 666
# define tASSIGN 261
# define tFUNCTION 262
# define tIF 263
# define tELSE 264
# define tFOR 265
# define tIN 266
# define tWHILE 267
# define tWITH 268
# define tBREAK 269
# define tCONTINUE 270
# define tRETURN 271
# define tCOMMA 272
# define tPLUSEQ 273
# define tMINUSEQ 274
# define tMULTIPLYEQ 275
# define tDIVIDEEQ 276
# define tMODEQ 277
# define tRSHIFTEQ 278
# define tLSHIFTEQ 279
# define tRSHIFTFILLEQ 280
# define tANDEQ 281
# define tXOREQ 282
# define tOREQ 283
# define tCONDTEST 284
# define tCONDSEP 285
# define tLOR 286
# define tLAND 287
# define tOR 288
# define tXOR 289
# define tAND 290
# define tEQ 291
# define tNE 292
# define tLT 293
# define tLE 294
# define tGE 295
# define tGT 296
# define tRSHIFT 297
# define tLSHIFT 298
# define tRSHIFTFILL 299
# define tPLUS 300
# define tMINUS 301
# define tMULTIPLY 302
# define tDIVIDE 303
# define tMOD 304
# define tNOT 305
# define tNEG 306
# define tONESCOMP 307
# define tINCREMENT 308
# define tDECREMENT 309
# define tDOT 310
# define tRIGHTBRACKET 311
# define tLEFTBRACKET 312
