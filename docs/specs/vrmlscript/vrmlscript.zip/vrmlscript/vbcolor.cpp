/*
 * Copyright (C) 1996   Silicon Graphics, Inc.
 *
 _______________________________________________________________________
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 |
 |   $Revision: 1.6 $
 |
 |   Classes:
 |	VbColor
 |
 |   Author(s)	: Alain Dumesny
 |		    Alan Norton (for the PC)
 |
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 _______________________________________________________________________
 */

#include <math.h>
#include "VbColor.h"

VbBool VbColor::usePalette = FALSE;
//
// Default constructor. Defined here to reduce warnings.
//

VbColor::VbColor()
{
}

//
// Sets value of vector from 3 individual hsv components
//
VbColor &
VbColor::setHSVValue(float hue, float sat, float val)
{
    float f,q,t,p;
    int i;
    
    if (hue == 1.0f)
	hue = 0.0f;
    else
	hue *= 6.0f;
    i = (int)(floor(hue));
    f = hue-i;
    p = val*(1.0f-sat);
    q = val*(1.0f-(sat*f));
    t = val*(1.0f-(sat*(1.0f-f)));
    switch (i) {
	case 0: vec[0] = val; vec[1] = t; vec[2] = p; break;
	case 1: vec[0] = q; vec[1] = val; vec[2] = p; break;
	case 2: vec[0] = p; vec[1] = val; vec[2] = t; break;
	case 3: vec[0] = p; vec[1] = q; vec[2] = val; break;
	case 4: vec[0] = t; vec[1] = p; vec[2] = val; break;
	case 5: vec[0] = val; vec[1] = p; vec[2] = q; break;
    }

    return (*this);
}

//
// Returns 3 individual hsv components
//
void
VbColor::getHSVValue(float &hue, float &sat, float &val) const
{
    float max,min;
    
    max = (vec[0] > vec[1]) ? 
	((vec[0] > vec[2]) ? vec[0] : vec[2]) : 
	((vec[1] > vec[2]) ? vec[1] : vec[2]);
    min = (vec[0] < vec[1]) ? 
	((vec[0] < vec[2]) ? vec[0] : vec[2]) : 
	((vec[1] < vec[2]) ? vec[1] : vec[2]);
    
    // brightness
    val = max;
    
    // saturation
    if (max != 0.0f) 
	sat = (max-min)/max;
    else
	sat = 0.0f;
    
    // finally the hue
    if (sat  !=  0.0f) {
    	float h;
	
	if (vec[0]  ==  max) 
	    h = (vec[1] - vec[2]) / (max-min);
	else if (vec[1]  ==  max)
	    h = 2.0f + (vec[2] - vec[0]) / (max-min);
	else
	    h = 4.0f + (vec[0] - vec[1]) / (max-min);
	if (h < 0.0f)
	    h += 6.0f;
	hue = h/6.0f;
    }
    else
    	hue = 0.0f;
}
//Helper routine to be used with renderware , and 8-bit color.  
//If color palette is used, Color is converted to
//one of a set of hues from the color map.  Resulting rampColor is one of
//the following rgb values:
// 1 1 1, 1 0 0, 0 1 0, 0 0 1, 1 1 0, 1 0 1, 0 1 1, 1 .5 0,
//The following (unsaturated colors) in the map are not targeted: 
// 1 .5 .5, .5 1 .5. (?)
// If palette is not being used, color is normalized to have max = 1.0.
void
VbColor::matchRamp(VbColor& rampColor) const
{
    //First normalize color:
    float maxClr = max(vec[0],max(vec[1],vec[2]));
    if (maxClr >0.f) {
	rampColor = VbColor(vec[0]*(1.f/maxClr),vec[1]*(1.f/maxClr),
		vec[2]*(1.f/maxClr));
    }
    else { 
	rampColor = VbColor(1.f,1.f,1.f);
	return;
    }
    if (!useColorPalette()) return;

    float hue, sat, val;
    rampColor.getHSVValue(hue, sat, val);
    
    if (sat <= 0.01f*val) {
	rampColor = VbColor(1.f,1.f,1.f);
	return;
    }
    hue = hue*12.f+0.5f;
    int inthue = (int)hue;
    
    switch (inthue){
	case(0):
	case(12):
	    //Red
	    rampColor = VbColor(1.0f,0.f,0.f);
	    break;
	case(1):
	    //Orange
	    rampColor = VbColor(1.0f,0.673f,0.0f);
	    break;
	case(2):
	case(3):
	    //Yellow
	    rampColor = VbColor(1.0f,0.952f,0.f);
	    break;
	case(4):
	case(5):
	    //Green
	    rampColor = VbColor(0.f,1.0f,0.f);
	    break;
	case(6):
	case(7):
	    //blue-green
	    rampColor = VbColor(0.f,1.0f,1.0f);
	    break;
	case(8):
	case(9):
	    //blue
	    rampColor = VbColor(0.f,0.f,1.0f);
	    break;
	case(10):
	case(11):
	    //purple
	    rampColor = VbColor(0.952f,0.f,1.0f);
	    break;
	default:
	_ASSERT(0);

    }
    return;    
}
//Utility to make a 16-bit color from a VbColor:
//assumes colors are 5,6,5
unsigned short
VbColor::make16()
{
    float fr = (float)pow(vec[0],1.f/1.7f);
    float fg = (float)pow(vec[1],1.f/1.7f);
    float fb = (float)pow(vec[2],1.f/1.7f);
    unsigned int r = (int)(fr*31.0f);
    unsigned int g = (int)(fg*63.0f);
    unsigned int b = (int)(fb*31.0f);
    return (unsigned short)((r<<11)|(g<<5)|b);
}


