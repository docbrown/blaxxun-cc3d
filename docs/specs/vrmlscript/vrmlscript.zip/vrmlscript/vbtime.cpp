/*
 * Copyright (C) 1996   Silicon Graphics, Inc.
 *
 _______________________________________________________________________
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 |
 |   $Revision: 1.4 $
 |
 |   Classes:
 |	VbTime
 |
 |   Author(s)		: Nick Thompson
 |			    Alan Norton (PC version)
 |
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 _______________________________________________________________________
 */

#include <stdio.h>
#include <sys/Timeb.h>
#include "VbTime.h"


////////////////////////////////////////////////////////////////////////
//
// Description:
//    Returns the current time in an VbTime.
//
// Use: public

VbTime
VbTime::getTimeOfDay()
//
////////////////////////////////////////////////////////////////////////
{
    VbTime	tm;
    struct _timeb tstruct;
    _ftime(&tstruct);
    
    tm.t = (double)(tstruct.time) + 0.001*(double)tstruct.millitm;
 
    return tm;
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Sets to the current time.
//
// Use: public

void
VbTime::setToTimeOfDay()
//
////////////////////////////////////////////////////////////////////////
{
    struct _timeb tstruct;
    _ftime(&tstruct);
    
    t = (double)(tstruct.time + 0.001*tstruct.millitm);
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Converts to a formatted string.  The format string supports the following:
//
//	%%			the '%' character
//	%D	 		total number of days
//    	%H	 		total number of hours 
//	%M			total number of minutes
//    	%S			total number of seconds
//	%I			total number of milliseconds
//	%U			total number of microseconds
//	%h	00-23		hours remaining after the days
//	%m	00-59		minutes remaining after the hours
//	%s	00-59		seconds remaining after the minutes
//	%i	000-999		milliseconds remaining after the seconds
//	%u	000000-999999	microseconds remaining after the seconds
//
// uppercase descriptors are formatted with a leading '-' for negative times
// lowercase descriptors are formatted fixed width with leading zeros
//
// Use: public

VbString
VbTime::format(const char *fmt) const
//
////////////////////////////////////////////////////////////////////////
{
    VbBool		negative;
    double		tv;

    // turn into sign-magnitude form
    if (t >= 0) {
	negative = 0;
	tv = t;
    }
    else {
	negative = 1;
	tv = -t;
    }

    // first calculate total durations
    const int32_t tday = (int32_t)(tv / (60.0*60.0*24.0));
    const int32_t thour = (int32_t)(tv / (60.0*60.0));
    const int32_t tmin = (int32_t)(tv / 60.0);
    const int32_t tsec = (int32_t)(tv);
    const int32_t tmilli = (int32_t)(1000.0*tv);
    const int32_t tmicro = (int32_t)(1000000.0*tv);

    // then calculate remaining durations
    const int32_t rhour = (int32_t)(thour - 24.0*tday);
    const int32_t rmin = (int32_t)(tmin - 60.0*thour);
    const int32_t rsec = (int32_t)(tsec - 60.0*tmin);
    const int32_t rmilli = (int32_t)(tmilli - 1000.0*tsec);
    const int32_t rmicro = (int32_t)(tmicro - 1000000.0*tsec);
    
    char buf[200];
    char *s = buf;

    for (; *fmt; fmt++) {
	if (*fmt != '%')
	    *s++ = *fmt;
	else
	    switch(*++fmt) {
	      case 0:
		fmt--;	// trailing '%' in format string
		break;

	      case '%':
		*s++ = '%';	// "%%" in format string
		break;

	      case 'D':
		if (negative) *s++ = '-';
		s += sprintf(s, "%ld", tday);
		break;

	      case 'H':
		if (negative) *s++ = '-';
		s += sprintf(s, "%ld", thour);
		break;

	      case 'M':
		if (negative) *s++ = '-';
		s += sprintf(s, "%ld", tmin);
		break;

	      case 'S':
		if (negative) *s++ = '-';
		s += sprintf(s, "%ld", tsec);
		break;

	      case 'I':
		if (negative) *s++ = '-';
		s += sprintf(s, "%ld", tmilli);
		break;

	      case 'U':
		if (negative) *s++ = '-';
		s += sprintf(s, "%ld", tmicro);
		break;

	      case 'h':
		s += sprintf(s, "%.2ld", rhour);
		break;

	      case 'm':
		s += sprintf(s, "%.2ld", rmin);
		break;

	      case 's':
		s += sprintf(s, "%.2ld", rsec);
		break;

	      case 'i':
		s += sprintf(s, "%.3ld", rmilli);
		break;

	      case 'u':
		s += sprintf(s, "%.6ld", rmicro);
		break;

	      default:
		*s++ = '%';	// echo any bad '%?'
		*s++ = *fmt;	// specifier
	    }
	if (s-buf >= sizeof(buf)-7) // don't overshoot the buffer
	    break;
    }
    *s = 0;

    return buf;
}



////////////////////////////////////////////////////////////////////////
//
// Description:
//
// Use: public

VbTime
operator +(const VbTime &t0, const VbTime &t1)
//
////////////////////////////////////////////////////////////////////////
{
    VbTime tm(t0.getValue() + t1.getValue());
    return tm;
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//
// Use: public

VbTime
operator -(const VbTime &t0, const VbTime &t1)
//
////////////////////////////////////////////////////////////////////////
{				

    return VbTime(t0.getValue() - t1.getValue());
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//
// Use: public

VbTime
operator *(const VbTime &tm, double s)
//
////////////////////////////////////////////////////////////////////////
{
    return VbTime(tm.getValue() * s);
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//
// Use: public

VbTime
operator /(const VbTime &tm, double s)
//
////////////////////////////////////////////////////////////////////////
{
    return tm * (1.0 / s);
}

