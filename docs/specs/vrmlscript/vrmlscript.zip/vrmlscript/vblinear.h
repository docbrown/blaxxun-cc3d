//  -*- C++ -*-

/*
 * Copyright (C) 1996   Silicon Graphics, Inc.
 *
 _______________________________________________________________________
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 |
 |   $Revision: 1.10 $
 |
 |   Description:
 |	This file contains definitions of various linear algebra classes,
 |	such as vectors, coordinates, etc..
 |
 |   Classes:
 |	VbVec3f
 |	VbVec2f 
 |	VbRotation
 |
 |   Author(s)		: Paul S. Strauss, Nick Thompson, 
 |			  David Mott, Alain Dumesny
 |        (for the PC)  : Jim Kent, Daniel Woods
 |
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 _______________________________________________________________________
 */

#ifndef _VB_LINEAR_
#define _VB_LINEAR_

#include "system.h"
#include "string.h"

#include <math.h>
#include "VbBasic.h"
#include "rwlib.h"

#ifndef RTOD
#define RTOD(a)	    ((a)*180.0f/3.14159f)
#endif
#ifndef DTOR
#define DTOR(a)	    ((a)*3.14159f/180.0f)
#endif
#ifndef ABS
#define ABS(a)	    (((a) < 0) ? -(a) : (a))
#endif

// -----------------------------------
//
// Types/classes defined in this file:
// 
// -----------------------------------

class VbVec3f;
class VbVec2f;

class VbRotation;

//////////////////////////////////////////////////////////////////////////////
//
//  Class: VbVec3f
//
//  3D vector used to represent points or directions. Each component of
//  the vector is a floating-point number.
//
//////////////////////////////////////////////////////////////////////////////

class AFX_EXT_CLASS VbVec3f {
  public:
    // Default constructor
    VbVec3f()						{ }

    // Constructor given an array of 3 components
    VbVec3f(const float v[3])
	 { vec[0] = v[0]; vec[1] = v[1]; vec[2] = v[2]; }

    // Constructor given 3 individual components
    VbVec3f(float x, float y, float z)
	 { vec[0] = x; vec[1] = y; vec[2] = z; }

    // Returns right-handed cross product of vector and another vector
    VbVec3f	cross(const VbVec3f &v) const;

    // Returns dot (inner) product of vector and another vector
    float	dot(const VbVec3f &v) const;

    // Returns pointer to array of 3 components
    const float	*getValue() const			{ return vec; }

    // Returns 3 individual components
    void	getValue(float &x, float &y, float &z) const;

    // Returns geometric length of vector
    float	length() const;

    // Changes vector to be unit length
    float	normalize();

    // Negates each component of vector in place
    void	negate();

    // Sets value of vector from array of 3 components
    VbVec3f &	setValue(const float v[3])
	 { vec[0] = v[0]; vec[1] = v[1]; vec[2] = v[2]; return *this; }

    // Sets value of vector from 3 individual components
    VbVec3f &	setValue(float x, float y, float z)
	 { vec[0] = x; vec[1] = y; vec[2] = z; return *this; }

    // Sets value of vector to be convex combination of 3 other
    // vectors, using barycentic coordinates
    VbVec3f &	setValue(const VbVec3f &barycentic,
		const VbVec3f &v0, const VbVec3f &v1, const VbVec3f &v2);

    // Accesses indexed component of vector
    float &	  operator [](int i) 		{ return (vec[i]); }
    const float & operator [](int i) const	{ return (vec[i]); }

    // Component-wise scalar multiplication and division operators
    VbVec3f &	operator *=(float d);
    VbVec3f &	operator /=(float d)
	{ return *this *= (float)(1.0 / d); }

    // Component-wise vector addition and subtraction operators
    VbVec3f &	operator +=(VbVec3f v);
    VbVec3f &	operator -=(VbVec3f v);

    // Nondestructive unary negation - returns a new vector
    VbVec3f	operator -() const;

    // Component-wise binary scalar multiplication and division operators
    friend VbVec3f	operator *(const VbVec3f &v, float d);
    friend VbVec3f	operator *(float d, const VbVec3f &v)
	{ return v * d; }
    friend VbVec3f	operator /(const VbVec3f &v, float d)
	{ return v * (1.0f / d); }

    // Component-wise binary vector addition and subtraction operators
    friend VbVec3f	operator +(const VbVec3f &v1, const VbVec3f &v2);

    friend VbVec3f	operator -(const VbVec3f &v1, const VbVec3f &v2);

    // Equality comparison operator
    friend int		operator ==(const VbVec3f &v1, const VbVec3f &v2);
    friend int		operator !=(const VbVec3f &v1, const VbVec3f &v2)
	{ return !(v1 == v2); }

    // Equality comparison within given tolerance - the square of the
    // length of the maximum distance between the two vectors
    VbBool		equals(const VbVec3f v, float tolerance) const;

    // Returns principal axis that is closest (based on maximum dot
    // product) to this vector
    VbVec3f		getClosestAxis() const;

  protected:
    float	vec[3];		// Storage for vector components
};

//////////////////////////////////////////////////////////////////////////////
//
//  Class: VbVec2f
//
//  2D vector used to represet points or directions. Each component of
//  the vector is a float.
//
//////////////////////////////////////////////////////////////////////////////

class AFX_EXT_CLASS VbVec2f {
  public:

    // Default constructor
    VbVec2f()						{ }

    // Constructor given an array of 2 components
    VbVec2f(const float v[2])				{ setValue(v); }

    // Constructor given 2 individual components
    VbVec2f(float x, float y)				{ setValue(x, y); }

    // Returns dot (inner) product of vector and another vector
    float	dot(const VbVec2f &v) const;

    // Returns pointer to array of 2 components
    const float	*getValue() const			{ return vec; }

    // Returns 2 individual components
    void	getValue(float &x, float &y) const;

    // Returns geometric length of vector
    float	length() const;

    // Negates each component of vector in place
    void	negate();

    // Changes vector to be unit length
    float	normalize();

    // Sets value of vector from array of 2 components
    VbVec2f &	setValue(const float v[2]);

    // Sets value of vector from 2 individual components
    VbVec2f &	setValue(float x, float y);

    // Accesses indexed component of vector
    float &	  operator [](int i) 		{ return (vec[i]); }
    const float & operator [](int i) const 	{ return (vec[i]); }

    // Component-wise scalar multiplication and division operators
    VbVec2f &	operator *=(float d);
    VbVec2f &	operator /=(float d)
	{ return *this *= (1.0f / d); }

    // Component-wise vector addition and subtraction operators
    VbVec2f &	operator +=(const VbVec2f &u);
    VbVec2f &	operator -=(const VbVec2f &u);

    // Nondestructive unary negation - returns a new vector
    VbVec2f	operator -() const;

    // Component-wise binary scalar multiplication and division operators
    friend VbVec2f	operator *(const VbVec2f &v, float d);
    friend VbVec2f	operator *(float d, const VbVec2f &v)
	{ return v * d; }
    friend VbVec2f	operator /(const VbVec2f &v, float d)
	{ return v * (1.0f / d); }

    // Component-wise binary vector addition and subtraction operators
    friend VbVec2f	operator +(const VbVec2f &v1, const VbVec2f &v2);
    friend VbVec2f	operator -(const VbVec2f &v1, const VbVec2f &v2);

    // Equality comparison operator
    friend int		operator ==(const VbVec2f &v1, const VbVec2f &v2);
    friend int		operator !=(const VbVec2f &v1, const VbVec2f &v2)
	{ return !(v1 == v2); }

    // Equality comparison within given tolerance - the square of the
    // length of the maximum distance between the two vectors
    VbBool		equals(const VbVec2f v, float tolerance) const;

  protected:
    float	vec[2];		// Storage for vector components
};

//////////////////////////////////////////////////////////////////////////////
//
//  Class: VbRotation
//
//  Rotation specfication. It is stored internally as a quaternion,
//  which has 4 floating-point components.
//
//////////////////////////////////////////////////////////////////////////////

class AFX_EXT_CLASS VbRotation {
  public:

    // Default constructor
    VbRotation()
	{}

    // Constructor given a quaternion as an array of 4 components
    VbRotation(const float v[4])
	{ setValue(v); }

    // Constructor given 4 individual components of a quaternion
    VbRotation(float q0, float q1, float q2, float q3)
	{ setValue(q0, q1, q2, q3); }

    // Constructor given 3D rotation axis vector and angle in radians
    VbRotation(const VbVec3f &axis, float radians)
	{ setValue(axis, radians); }

    // Constructor for rotation that rotates one direction vector to another
    VbRotation(const VbVec3f &rotateFrom, const VbVec3f &rotateTo)
	{ setValue(rotateFrom, rotateTo); }
	
    // Returns pointer to array of 4 components defining quaternion
    const float	*	getValue() const
	{ return (quat); }

    // Returns 4 individual components of rotation quaternion 
    void		getValue(float &q0, float &q1,
				 float &q2, float &q3) const;

    // Returns corresponding 3D rotation axis vector and angle in radians
    void		getValue(VbVec3f &axis, float &radians) const;

    // Changes a rotation to be its inverse
    VbRotation &	invert();

    // Returns the inverse of a rotation
    VbRotation		inverse() const
	{ VbRotation q = *this; return q.invert(); }

    // Sets value of rotation from array of 4 components of a quaternion
    VbRotation &	setValue(const float q[4]);

    // Sets value of rotation from 4 individual components of a quaternion 
    VbRotation &	setValue(float q0, float q1, float q2, float q3);

    // Sets value of vector from 3D rotation axis vector and angle in radians
    VbRotation &	setValue(const VbVec3f &axis, float radians);

    // Sets rotation to rotate one direction vector to another
    VbRotation &	setValue(const VbVec3f &rotateFrom,
				 const VbVec3f &rotateTo);
		
    // Multiplies by another rotation; results in product of rotations
    VbRotation &	 operator *=(const VbRotation &q);

    // Equality comparison operator
    friend int	operator ==(const VbRotation &q1, const VbRotation &q2);
    friend int	operator !=(const VbRotation &q1, const VbRotation &q2)
	{ return !(q1 == q2); }

    // Equality comparison within given tolerance - the square of the
    // length of the maximum distance between the two quaternion vectors
    VbBool		equals(const VbRotation &r, float tolerance) const;

    // Multiplication of two rotations; results in product of rotations
    friend VbRotation	operator *(const VbRotation &q1, const VbRotation &q2);

    // Puts the given vector through this rotation
    // (Multiplies the given vector by the matrix of this rotation),.
    void	multVec(const VbVec3f &src, VbVec3f &dst) const;
    
    // Keep the axis the same. Multiply the angle of rotation by 
    // the amount 'scaleFactor'
    void scaleAngle( float scaleFactor );

    // Spherical linear interpolation: as t goes from 0 to 1, returned
    // value goes from rot0 to rot1
    static VbRotation	slerp(const VbRotation &rot0,
			      const VbRotation &rot1, float t);

    // Null rotation
    static VbRotation	identity()
	{ return VbRotation(0.0f, 0.0f, 0.0f, 1.0f); }

  private:
    float	quat[4];	// Storage for quaternion components

    // Returns the norm (square of the 4D length) of a rotation's quaterion
    float	norm() const;

    // Normalizes a rotation quaternion to unit 4D length
    void	normalize();
};

#endif /* _VB_LINEAR_ */
