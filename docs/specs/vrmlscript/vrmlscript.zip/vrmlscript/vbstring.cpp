/*
 * VbString.cpp
 *
 *      Definition of classes:
 *        VbString
 *	  
 *
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 *
 */

#include "vbstring.h"


VbString::~VbString()
{
    if (string != staticStorage)
	delete [] string;
}

void
VbString::expand(int bySize)
{
    int newSize = strlen(string) + bySize + 1;

    if (newSize >= VB_STRING_STATIC_STORAGE_SIZE &&
	(string == staticStorage || newSize > storageSize)) {



	char *newString = new char[newSize];



	strcpy(newString, string);

	if (string != staticStorage)
	    delete [] string;

	string      = newString;
	storageSize = newSize;
    }
}

u_long
VbString::hash(const char *s)
{
    u_long	total, shift;

    total = shift = 0;
    while (*s) {
	total = total ^ ((*s) << shift);
	shift+=5;
	if (shift>24) shift -= 24;
	s++;
    }

    return( total );
}

void
VbString::makeEmpty(VbBool freeOld)
{
    if (string != staticStorage) {
	if (freeOld)
	    delete [] string;
	string = staticStorage;
    }
    string[0] = '\0';
}

VbString &
VbString::operator =(const char *str)
{
    int size = strlen(str) + 1;

    if (str >= string &&
	str < string + (string != staticStorage ? storageSize :
			VB_STRING_STATIC_STORAGE_SIZE)) {

	VbString tmp = str;
	*this = tmp;
	return *this;
    }

			


    if (size < VB_STRING_STATIC_STORAGE_SIZE) {
		if (string != staticStorage)
			makeEmpty();
    }

    else if (string == staticStorage)
		string = new char[size];

    else if (size > storageSize) {
		delete [] string;
		string = new char[size];
    }



    strcpy(string, str);
    storageSize = size;
    return *this;
}
//
// Concatenation operator "+=" for string
//

VbString &
VbString::operator +=(const char *str)
{
    expand(strlen(str));
    strcat(string, str);
    return *this;
}

//
// Concatenation operator "+=" for VbString
//

VbString &
VbString::operator +=(const VbString &str)
{
    (*this) += str.getString();
    return *this;
}
//
// Returns new string representing given sub-string. If endChar is
// -1 (the default), the sub-string from startChar until the end
// is returned.
//

VbString
VbString::getSubString(int startChar, int endChar) const
{
    int		len = getLength();

    // Get substring that starts at specified character
    VbString	tmp = &string[startChar];

    // Delete characters from end if necessary
    if (endChar >= 0 && endChar < len - 1)
	tmp.deleteSubString(endChar - startChar + 1);

    return tmp;
}
//
// Deletes the specified characters from the string. If endChar is
// -1 (the default), all characters from startChar until the end
// are deleted.
//

void
VbString::deleteSubString(int startChar, int endChar)
{
    int		len = getLength();

    // Modify string in place
    if (endChar < 0 || endChar >= len - 1)
	string[startChar] = '\0';
    else {
	int	i, numToMove = len - endChar - 1;

	for (i = 0; i < numToMove; i++)
	    string[startChar + i] = string[endChar + i + 1];
	string[startChar + numToMove] = '\0';
    }

    // Use temporary string to allow us to free up old storage if necessary
    VbString	tmp = string;
    *this = tmp;
}

int
operator ==(const VbString &str, const char *s)
{
    return (str.string[0] == s[0] && ! strcmp(str.string, s));
}

int
operator !=(const VbString &str, const char *s)
{
    return (str.string[0] != s[0] || strcmp(str.string, s));
}
