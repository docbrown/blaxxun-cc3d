/*
 * Test harness for VRMLScript interpreter
 *
 * This test program will read the passed file into a buffer
 * then send the buffer to the parser. The result is a list
 * of compiled functions ready for execution by the interpreter.
 *
 * Next it creates a dummy field and eventOut of the Script node
 * being simulated. Note that there is no difference between
 * the definition of the two. In this implementation it is 
 * intended that an eventOut is a subclass of a field with the
 * additional semantics that data stored there is also sent as
 * an eventOut.
 *
 * It then finds a function named "myEventIn" to show the mechanism
 * for looking up functions by name. Then it constructs a list
 * of arguments and calls the function with those arguments. The 
 * return value from the function is given back. If this is a 
 * string or number it is printed. The function is called 10 times
 * with a numeric argument of 0 to 9. An SFTime argument of 0 is 
 * passed to simulate calling an eventIn function (named "myEventIn")
 * of type SFInt32 with a value and a timestamp.
 *
 * To use the code, the parser should be run on the vrmlscript
 * source when a Script node is read (this can be delayed until
 * just before the first execution for efficiency). The resulting
 * compiled functions are then saved with the Script node. Next the
 * fields and eventOuts of the Script node are defined to the 
 * compiled functions. 
 *
 * When an eventIn is received the function with the corresponding
 * name is looked up. Then 2 arguments are built - a value with 
 * the type of the eventIn containing the eventIn data, and an
 * SFTime value with the current timestamp. The function is then
 * executed and the return value is discarded. The eventsProcessed,
 * initialize and shutdown functions should also be handled
 * according to the VRML 2.0 spec if they appear in the function
 * list.
 *
 * On the other end there are 4 _stub files. These contain stubs
 * for all the data types. There are 19 classes which correspond to
 * the 19 VRML data types. These should be replaced with the 
 * actual classes corresponding to the data handling mechanism of
 * your browser. These will hold the values used in the interpreter
 * and will contain the persistant data of Script node (fields and
 * eventOuts). A mechanism which will send an event when a data
 * value corresponding to an eventOut is set must be created
 * according to your browser's event handling mechanism.
 */

#include <stdio.h>
#include <stdlib.h>

#include "vsparse.h"
#include "vsfields.h"
#include "vsfunction.h"
#include "vrmlfields_stub.h"

extern int yydebug;   /* Set to 1 to debug YACC */
extern int lldebug;   /* Set to 1 to debug lexer */

main(int argc, char **argv)
{
    // collect options
    int optind;
    for (optind = 1; optind < argc && argv[optind][0] == '/'; ++optind)
    {
	switch(argv[optind][1])
	{
	    case 'y':	// run debugger
		yydebug = 1;
		break;
	    case 'l':	// debug parser
		lldebug = 1;
		break;
	    default:
		fprintf(stderr, "usage: interp [-yl] <script file>\n");
		exit(2);
	}
    }

    if (optind >= argc) {
	fprintf(stderr, "usage: interp [-yl] <script file>\n");
	exit(2);
    }

    // create the parse tree. This will contain the executable
    // functions and global (Script node) data pointers.
    VsParseTree *t = new VsParseTree;

    // add an eventOut named "myEventOut" to the parse tree globals.
    // This would correspond to the line:
    //
    //    eventOut SFInt32 myEventOut
    //
    // in the Script node

    VrmlSFInt32 myEventOut;
    VsField *myEventOutValue = VsField::create(SFINT32, VsField::RW);
    myEventOutValue->setField(&myEventOut);
    t->addGlobalVar("myEventOut", myEventOutValue);

    // add a field named "myField" to the parse tree globals.
    // This would correspond to the line:
    //
    //    field SFInt32 myField 0
    //
    // in the Script node
    //
    // (note that this is the same as the eventOut definition. It
    // is assumed that the eventOut would be a subclass of the 
    // field class with additional semantics to allow it to send
    // events when set).

    VrmlSFInt32 myField;
    VsField *myFieldValue = VsField::create(SFINT32, VsField::RW);
    myFieldValue->setField(&myField);
    t->addGlobalVar("myField", myFieldValue);

    // open the file
    FILE *fp = fopen(argv[optind], "r");

    if (fp == NULL) {
	perror("error opening input file");
	exit(2);
    }
    
    // read file into a buffer
    char *buf = (char *) malloc(1);
    int size = 0;

    while (!feof(fp)) {
	buf = (char *) realloc(buf, size+1000);
	size += fread(buf+size, 1, 999, fp);
    }

    // terminate buffer to make it a legal string
    buf[size] = '\0';

    // parse the vrmlscript in the buffer
    int result = t->parse(buf, "myScript");

    free(buf);

    // handle error condition
    if (result == 0) printf("MAIN: syntax error\n");
    else {
	
	// Ok, test out intepreter:
	// First find the function with a given name (this is the
	// name of the eventIn being handled or the name 
	// "eventsProcessed", "initialize", or "shutdown")

	VsFunctionDef *f_main = t->findFunction("myEventIn");
	if (f_main == NULL) {
	    fprintf(stderr, "Couldn't find function main\n");
	    return result;
	}

	// create an argument list
	VsExprList arguments;

	// Create an argument corresponding to the eventIn value
	VrmlSFInt32 myEventIn;
	VsField *myEventInArg = VsField::create(SFINT32, VsField::RO);
	arguments.append(myEventInArg);

	// Create an argument corresponding to the eventIn timestamp
	VrmlSFTime myTimestamp;
	VsField *myTimestampArg = VsField::create(SFTIME, VsField::RO);
	arguments.append(myTimestampArg);

	// create a function call instance with the function and
	// its arguments
	VsFunctionCall *f_call = new VsFunctionCall(f_main, arguments);

	// Now, run interpreter with 10 different inputs:
	for (int i = 0; i < 10; i++) {
	    printf("-----------Iteration: %d-------------\n", i);

	    // set the value of the arguments
	    myEventIn.setValue(i);
	    myEventInArg->setField(&myEventIn);
	    myTimestamp.setValue(i+1);
	    myTimestampArg->setField(&myTimestamp);

	    // call the function, get the return value so it can
	    // be printed (it is normally discarded).
	    VsValue v = f_call->evaluate(NULL);

	    // print the return value for testing purposed
	    switch (v.type) {
	      case VsValue::vNUMBER:
		printf("main(%d) returned %g\n", i, v.number);
		break;
	      case VsValue::vSTRING:
		printf("main(%d) returned \"%s\"\n", i, v.string);
		break;
	      default:
		break;
	    }
	}
    }

    printf("\n\nPress return to exit\n");
    int c = getchar();
    return result;
}

