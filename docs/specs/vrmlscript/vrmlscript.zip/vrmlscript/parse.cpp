#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vsexpr.h"
#include "vsfunction.h"
#include "vsstatement.h"
#include "vsparse.h"

// Lex and YACC are hard-coded for these routine names:
#define input() VsParseTree::input()
#define unput(_char) VsParseTree::unput(_char)
#define yyerror(_error) VsParseTree::yyerror(_error)

#define gettxt(a,b) (b)  /* SGI YACC produces these... */
#ifdef _DEBUG
#define YYDEBUG 1
#else
#define YYDEBUG 0
#endif

typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
    const char *string;
    double number;
    VsExpr *expr;
    VsVar *var;
    VsArrayVar *arrayvar;
    VsFunctionDef *funcDef;
    VsFunctionCall *funcCall;
    VsMethodCall   *objMethodCall;
    VsMemberAccess *objMemberAccess;
    VsStatement *stmnt;
    VsExprList *exprList;
    VsStatementList *stmntList;
} YYSTYPE;
# define tNUMBER 257
# define tSTRING 258
# define tIDENTIFIER 259
# define tUNIMPL_KEYWORD 666
# define tASSIGN 261
# define tFUNCTION 262
# define tIF 263
# define tELSE 264
# define tFOR 265
# define tIN 266
# define tWHILE 267
# define tWITH 268
# define tBREAK 269
# define tCONTINUE 270
# define tRETURN 271
# define tCOMMA 272
# define tPLUSEQ 273
# define tMINUSEQ 274
# define tMULTIPLYEQ 275
# define tDIVIDEEQ 276
# define tMODEQ 277
# define tRSHIFTEQ 278
# define tLSHIFTEQ 279
# define tRSHIFTFILLEQ 280
# define tANDEQ 281
# define tXOREQ 282
# define tOREQ 283
# define tCONDTEST 284
# define tCONDSEP 285
# define tLOR 286
# define tLAND 287
# define tOR 288
# define tXOR 289
# define tAND 290
# define tEQ 291
# define tNE 292
# define tLT 293
# define tLE 294
# define tGE 295
# define tGT 296
# define tRSHIFT 297
# define tLSHIFT 298
# define tRSHIFTFILL 299
# define tPLUS 300
# define tMINUS 301
# define tMULTIPLY 302
# define tDIVIDE 303
# define tMOD 304
# define tNOT 305
# define tNEG 306
# define tONESCOMP 307
# define tINCREMENT 308
# define tDECREMENT 309
# define tDOT 310
# define tRIGHTBRACKET 311
# define tLEFTBRACKET 312

#include <malloc.h>
#include <memory.h>

#ifdef __cplusplus

#ifndef yyerror
	void yyerror(const char *);
#endif
#ifndef yylex
	extern "C" int yylex(void);
#endif
	int yyparse(void);

#endif
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
YYSTYPE yylval;
YYSTYPE yyval;
typedef int yytabelem;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#if YYMAXDEPTH > 0
int yy_yys[YYMAXDEPTH], *yys = yy_yys;
YYSTYPE yy_yyv[YYMAXDEPTH], *yyv = yy_yyv;
#else	/* user does initial allocation */
int *yys;
YYSTYPE *yyv;
#endif
static int yymaxdepth = YYMAXDEPTH;
# define YYERRCODE 256
yytabelem yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
-1, 43,
	261, 90,
	273, 90,
	274, 90,
	275, 90,
	276, 90,
	277, 90,
	278, 90,
	279, 90,
	280, 90,
	281, 90,
	282, 90,
	283, 90,
	-2, 82,
-1, 44,
	261, 91,
	273, 91,
	274, 91,
	275, 91,
	276, 91,
	277, 91,
	278, 91,
	279, 91,
	280, 91,
	281, 91,
	282, 91,
	283, 91,
	-2, 83,
-1, 45,
	261, 92,
	273, 92,
	274, 92,
	275, 92,
	276, 92,
	277, 92,
	278, 92,
	279, 92,
	280, 92,
	281, 92,
	282, 92,
	283, 92,
	-2, 84,
-1, 109,
	261, 92,
	273, 92,
	274, 92,
	275, 92,
	276, 92,
	277, 92,
	278, 92,
	279, 92,
	280, 92,
	281, 92,
	282, 92,
	283, 92,
	-2, 84,
	};
# define YYNPROD 96
# define YYLAST 706
yytabelem yyact[]={

   171,    59,    60,    81,    82,    61,   155,    69,    68,    76,
    77,    75,    62,    63,    64,    65,    66,    67,    79,    78,
    80,    70,    71,    72,    73,    74,    58,   157,   158,    59,
    60,    81,    82,   153,   172,   160,   169,     4,    61,   133,
    69,    68,    76,    77,    75,    62,    63,    64,    65,    66,
    67,    79,    78,    80,    70,    71,    72,    73,    74,    47,
    10,     7,    59,    60,    81,    82,    61,   170,    69,    68,
    76,    77,    75,    62,    63,    64,    65,    66,    67,    79,
    78,    80,    70,    71,    72,    73,    74,   149,   152,    54,
    59,    60,    81,    82,    69,    68,    76,    77,    75,    62,
    63,    64,    65,    66,    67,    79,    78,    80,    70,    71,
    72,    73,    74,    53,    52,    51,    59,    60,    81,    82,
    68,    76,    77,    75,    62,    63,    64,    65,    66,    67,
    79,    78,    80,    70,    71,    72,    73,    74,   176,   154,
    11,    59,    60,    81,    82,    76,    77,    75,    62,    63,
    64,    65,    66,    67,    79,    78,    80,    70,    71,    72,
    73,    74,   151,   136,   156,    59,    60,    81,    82,    77,
    75,    62,    63,    64,    65,    66,    67,    79,    78,    80,
    70,    71,    72,    73,    74,   108,   103,    32,    59,    60,
    81,    82,    75,    62,    63,    64,    65,    66,    67,    79,
    78,    80,    70,    71,    72,    73,    74,    84,    57,    32,
    59,    60,    81,    82,    62,    63,    64,    65,    66,    67,
    79,    78,    80,    70,    71,    72,    73,    74,    56,    55,
    13,    59,    60,    81,    82,     8,    45,     2,     3,     1,
    32,     5,    43,    61,   166,    69,    68,    76,    77,    75,
    62,    63,    64,    65,    66,    67,    79,    78,    80,    70,
    71,    72,    73,    74,    32,   159,   159,    59,    60,    81,
    82,    61,   104,    69,    68,    76,    77,    75,    62,    63,
    64,    65,    66,    67,    79,    78,    80,    70,    71,    72,
    73,    74,    14,   109,    41,    59,    60,    81,    82,    64,
    65,    66,    67,    79,    78,    80,    70,    71,    72,    73,
    74,    42,     9,     6,    59,    60,    81,    82,    79,    78,
    80,    70,    71,    72,    73,    74,    48,    21,    23,    59,
    60,    81,    82,    70,    71,    72,    73,    74,   162,    22,
    18,    59,    60,    81,    82,    72,    73,    74,    89,    49,
    20,    59,    60,    81,    82,    16,   174,    17,    44,    15,
    90,    91,    92,    93,    94,    99,    98,   100,    95,    97,
    96,    12,    36,     0,    50,     0,     0,     0,     0,     0,
     0,     0,   161,     0,     0,   164,     0,     0,     0,   167,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   173,     0,   175,   106,    40,    39,    46,   177,   105,     0,
    24,     0,    25,     0,    26,    29,    30,    31,    28,     0,
     0,     0,     0,     0,     0,     0,    40,    39,    46,     0,
     0,     0,    24,     0,    25,     0,    26,    29,    30,    31,
    28,     0,     0,     0,     0,     0,     0,     0,    33,     0,
     0,     0,    34,     0,    35,    37,    38,    40,    39,    46,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    33,     0,     0,     0,    34,     0,    35,    37,    38,    27,
     0,    40,    39,    46,     0,     0,     0,    24,     0,    25,
     0,    26,    29,    30,    31,    28,     0,     0,     0,     0,
     0,    33,     0,     0,     0,    34,     0,    35,    37,    38,
     0,     0,     0,    86,    87,    88,     0,   101,   102,     0,
     0,     0,     0,     0,     0,    33,     0,     0,     0,    34,
     0,    35,    37,    38,    19,     0,     0,     0,     0,     0,
     0,   113,   114,   115,   116,   117,   118,   119,   120,   121,
   122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
   132,     0,     0,    83,   135,     0,     0,    85,     0,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,     0,     0,   150,     0,     0,     0,     0,     0,     0,
   107,   110,   111,   112,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   134,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   163,     0,   165,   150,     0,     0,   168,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   110,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   110 };
yytabelem yypact[]={

  -225,-10000000,  -225,-10000000,  -198,-10000000,   195,-10000000,  -199,    99,
-10000000,   169,  -200,-10000000,   224,-10000000,-10000000,-10000000,-10000000,    56,
    55,-10000000,    54,    30,   189,   188,   168,  -246,   200,   167,
-10000000,-10000000,   200,   200,   200,   200,    87,   200,   200,-10000000,
-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,   146,-10000000,   147,-10000000,
-10000000,-10000000,-10000000,-10000000,-10000000,   200,   200,   200,   200,-10000000,
-10000000,   200,   200,   200,   200,   200,   200,   200,   200,   200,
   200,   200,   200,   200,   200,   200,   200,   200,   200,   200,
   200,  -220,   200,-10000000,   200,   122,  -307,  -307,  -307,   200,
   200,   200,   200,   200,   200,   200,   200,   200,   200,   200,
   200,  -307,  -307,   200,-10000000,-10000000,-10000000,   121,    29,  -233,
-10000000,    98,-10000000,  -279,     6,     6,    21,    21,    21,    21,
  -143,  -167,    43,    43,  -307,  -307,  -307,   -77,  -120,   -98,
    33,    33,    33,   124,  -285,   -13,-10000000,  -218,  -218,  -218,
  -218,  -218,  -218,  -218,  -218,  -218,  -218,  -218,  -218,    -6,
  -218,   169,   200,   200,   169,   200,   200,-10000000,   169,   200,
-10000000,  -228,     8,   -41,-10000000,  -192,    -7,-10000000,  -218,   169,
   200,   169,-10000000,-10000000,    97,-10000000,   169,-10000000 };
yytabelem yypgo[]={

     0,   479,   185,   534,   236,   372,   358,   357,   355,   350,
   359,   340,   339,   328,   327,   326,   230,   238,   313,    87,
   312,   311,   294,   242,   239,   237 };
yytabelem yyr1[]={

     0,    24,    24,    25,    25,    17,    18,    20,    20,    20,
    16,    16,    16,    15,    15,    15,    10,    10,    10,    10,
    10,    10,    10,    10,     9,     9,     8,     8,     7,     7,
    12,    13,    14,    11,     2,     2,     3,     3,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,    19,    19,    19,    21,    22,
     5,     5,     5,    23,     6,     4 };
yytabelem yyr2[]={

     0,     2,     0,     4,     2,    13,     3,     7,     3,     1,
     7,     5,     3,     5,     3,     5,     3,     3,     3,     5,
     5,     3,     5,     5,     5,     3,    11,    15,    19,    15,
     3,     3,    11,    11,     3,     1,     3,     7,     7,     5,
     5,     5,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     7,     7,     7,     5,     5,     5,     5,    11,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     3,     3,
     3,     3,     3,     3,     3,     7,     3,     1,     9,    13,
     3,     3,     3,     7,     9,     3 };
yytabelem yychk[]={

-10000000,   -24,   -25,   -17,   262,   -17,   -18,   259,    40,   -20,
   259,    41,   272,   -16,   123,   -10,    -8,    -7,   -11,    -3,
    -9,   -14,   -12,   -13,   263,   265,   267,    -1,   271,   268,
   269,   270,    40,   301,   305,   307,    -5,   308,   309,   258,
   257,   -22,   -21,   -23,    -6,    -4,   259,   259,   -15,   125,
   -10,    59,    59,    59,    59,    40,    40,    40,   272,   308,
   309,   284,   291,   292,   293,   294,   295,   296,   287,   286,
   300,   301,   302,   303,   304,   290,   288,   289,   298,   297,
   299,   310,   311,    -3,    40,    -3,    -1,    -1,    -1,   261,
   273,   274,   275,   276,   277,   281,   283,   282,   279,   278,
   280,    -1,    -1,    40,   125,   -10,   256,    -3,    -2,    -4,
    -3,    -3,    -3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   259,    -3,    -1,    41,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   -19,
    -1,    41,    59,   266,    41,   285,    40,   312,    41,   272,
    41,   -16,    -2,    -1,   -16,    -1,   -19,   -16,    -1,   264,
    59,    41,    41,   -16,    -2,   -16,    41,   -16 };
yytabelem yydef[]={

     2,    -2,     1,     4,     0,     3,     0,     6,     9,     0,
     8,     0,     0,     5,     0,    12,    16,    17,    18,     0,
     0,    21,     0,     0,     0,     0,     0,    36,    25,     0,
    30,    31,     0,     0,     0,     0,     0,     0,     0,    78,
    79,    80,    81,    -2,    -2,    -2,    95,     7,     0,    11,
    14,    19,    20,    22,    23,     0,    35,     0,     0,    56,
    57,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    24,     0,     0,    39,    40,    41,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    54,    55,    87,    10,    13,    15,     0,     0,    -2,
    34,     0,    37,     0,    59,    60,    61,    62,    63,    64,
    65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
    75,    76,    77,    93,     0,     0,    38,    42,    43,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,     0,
    86,     0,    35,     0,     0,     0,    87,    94,     0,     0,
    88,    26,     0,     0,    33,    58,     0,    32,    85,     0,
    35,     0,    89,    27,     0,    29,     0,    28 };
typedef struct
#ifdef __cplusplus
	yytoktype
#endif
{ char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"tNUMBER",	257,
	"tSTRING",	258,
	"tIDENTIFIER",	259,
	"tUNIMPL_KEYWORD",	666,
	"tASSIGN",	261,
	"tFUNCTION",	262,
	"tIF",	263,
	"tELSE",	264,
	"tFOR",	265,
	"tIN",	266,
	"tWHILE",	267,
	"tWITH",	268,
	"tBREAK",	269,
	"tCONTINUE",	270,
	"tRETURN",	271,
	"tCOMMA",	272,
	"tPLUSEQ",	273,
	"tMINUSEQ",	274,
	"tMULTIPLYEQ",	275,
	"tDIVIDEEQ",	276,
	"tMODEQ",	277,
	"tRSHIFTEQ",	278,
	"tLSHIFTEQ",	279,
	"tRSHIFTFILLEQ",	280,
	"tANDEQ",	281,
	"tXOREQ",	282,
	"tOREQ",	283,
	"tCONDTEST",	284,
	"tCONDSEP",	285,
	"tLOR",	286,
	"tLAND",	287,
	"tOR",	288,
	"tXOR",	289,
	"tAND",	290,
	"tEQ",	291,
	"tNE",	292,
	"tLT",	293,
	"tLE",	294,
	"tGE",	295,
	"tGT",	296,
	"tRSHIFT",	297,
	"tLSHIFT",	298,
	"tRSHIFTFILL",	299,
	"tPLUS",	300,
	"tMINUS",	301,
	"tMULTIPLY",	302,
	"tDIVIDE",	303,
	"tMOD",	304,
	"tNOT",	305,
	"tNEG",	306,
	"tONESCOMP",	307,
	"tINCREMENT",	308,
	"tDECREMENT",	309,
	"tDOT",	310,
	"tRIGHTBRACKET",	311,
	"tLEFTBRACKET",	312,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"script : funcs",
	"script : /* empty */",
	"funcs : funcs func",
	"funcs : func",
	"func : tFUNCTION bgnFunc '(' args ')' stmntblk",
	"bgnFunc : tIDENTIFIER",
	"args : args tCOMMA tIDENTIFIER",
	"args : tIDENTIFIER",
	"args : /* empty */",
	"stmntblk : '{' stmnts '}'",
	"stmntblk : '{' '}'",
	"stmntblk : stmnt",
	"stmnts : stmnts stmnt",
	"stmnts : stmnt",
	"stmnts : stmnts error",
	"stmnt : if",
	"stmnt : for",
	"stmnt : while",
	"stmnt : comma_expr ';'",
	"stmnt : return ';'",
	"stmnt : with",
	"stmnt : break ';'",
	"stmnt : continue ';'",
	"return : tRETURN comma_expr",
	"return : tRETURN",
	"if : tIF '(' comma_expr ')' stmntblk",
	"if : tIF '(' comma_expr ')' stmntblk tELSE stmntblk",
	"for : tFOR '(' opt_expr ';' opt_expr ';' opt_expr ')' stmntblk",
	"for : tFOR '(' var tIN expr ')' stmntblk",
	"break : tBREAK",
	"continue : tCONTINUE",
	"with : tWITH '(' expr ')' stmntblk",
	"while : tWHILE '(' comma_expr ')' stmntblk",
	"opt_expr : comma_expr",
	"opt_expr : /* empty */",
	"comma_expr : expr",
	"comma_expr : expr tCOMMA comma_expr",
	"expr : '(' comma_expr ')'",
	"expr : tMINUS expr",
	"expr : tNOT expr",
	"expr : tONESCOMP expr",
	"expr : leftvar tASSIGN expr",
	"expr : leftvar tPLUSEQ expr",
	"expr : leftvar tMINUSEQ expr",
	"expr : leftvar tMULTIPLYEQ expr",
	"expr : leftvar tDIVIDEEQ expr",
	"expr : leftvar tMODEQ expr",
	"expr : leftvar tANDEQ expr",
	"expr : leftvar tOREQ expr",
	"expr : leftvar tXOREQ expr",
	"expr : leftvar tLSHIFTEQ expr",
	"expr : leftvar tRSHIFTEQ expr",
	"expr : leftvar tRSHIFTFILLEQ expr",
	"expr : tINCREMENT expr",
	"expr : tDECREMENT expr",
	"expr : expr tINCREMENT",
	"expr : expr tDECREMENT",
	"expr : expr tCONDTEST expr tCONDSEP expr",
	"expr : expr tEQ expr",
	"expr : expr tNE expr",
	"expr : expr tLT expr",
	"expr : expr tLE expr",
	"expr : expr tGE expr",
	"expr : expr tGT expr",
	"expr : expr tLAND expr",
	"expr : expr tLOR expr",
	"expr : expr tPLUS expr",
	"expr : expr tMINUS expr",
	"expr : expr tMULTIPLY expr",
	"expr : expr tDIVIDE expr",
	"expr : expr tMOD expr",
	"expr : expr tAND expr",
	"expr : expr tOR expr",
	"expr : expr tXOR expr",
	"expr : expr tLSHIFT expr",
	"expr : expr tRSHIFT expr",
	"expr : expr tRSHIFTFILL expr",
	"expr : tSTRING",
	"expr : tNUMBER",
	"expr : objmethodcall",
	"expr : funccall",
	"expr : objmemberaccess",
	"expr : arrayderef",
	"expr : var",
	"params : params tCOMMA expr",
	"params : expr",
	"params : /* empty */",
	"funccall : tIDENTIFIER '(' params ')'",
	"objmethodcall : expr tDOT tIDENTIFIER '(' params ')'",
	"leftvar : objmemberaccess",
	"leftvar : arrayderef",
	"leftvar : var",
	"objmemberaccess : expr tDOT tIDENTIFIER",
	"arrayderef : expr tRIGHTBRACKET comma_expr tLEFTBRACKET",
	"var : tIDENTIFIER",
};
#endif /* YYDEBUG */
/* 
 *	Copyright 1987 Silicon Graphics, Inc. - All Rights Reserved
 */

/* #ident	"@(#)yacc:yaccpar	1.10" */
#ident	"$Revision: 1.14 $"

/*
** Skeleton parser driver for yacc output
*/
#include "stddef.h"

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	return(0)
#define YYABORT		return(1)
#ifdef __cplusplus
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( gettxt("uxlibc:78", "syntax error - cannot backup") );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#else
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( gettxt("uxlibc:78", "Syntax error - cannot backup") );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#endif
#define YYRECOVERING()	(!!yyerrflag)
#define YYNEW(type)	malloc(sizeof(type) * yynewmax)
#define YYCOPY(to, from, type) \
	(type *) memcpy(to, (char *) from, yynewmax * sizeof(type))
#define YYENLARGE( from, type) \
	(type *) realloc((char *) from, yynewmax * sizeof(type))
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-10000000)

/*
** global variables used by the parser
*/
YYSTYPE *yypv;			/* top of value stack */
int *yyps;			/* top of state stack */

int yystate;			/* current state */
int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */
int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */



/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
#if defined(__STDC__) || defined(__cplusplus)
int yyparse(void)
#else
int yyparse()
#endif
{
	register YYSTYPE *yypvt;	/* top of value stack for $vars */

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

#if YYMAXDEPTH <= 0
	if (yymaxdepth <= 0)
	{
		if ((yymaxdepth = YYEXPAND(0)) <= 0)
		{
#ifdef __cplusplus
			yyerror(gettxt("uxlibc:79", "yacc initialization error"));
#else
			yyerror(gettxt("uxlibc:79", "Yacc initialization error"));
#endif
			YYABORT;
		}
	}
#endif

	goto yystack;
	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	//yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			int yynewmax;
			ptrdiff_t yys_off;

			/* The following pointer-differences are safe, since
			 * yypvt, yy_pv, and yypv all are a multiple of
			 * sizeof(YYSTYPE) bytes from yyv.
			 */
			ptrdiff_t yypvt_off = yypvt - yyv;
			ptrdiff_t yy_pv_off = yy_pv - yyv;
			ptrdiff_t yypv_off = yypv - yyv;

			int *yys_base = yys;
#ifdef YYEXPAND
			yynewmax = YYEXPAND(yymaxdepth);
#else
			yynewmax = 2 * yymaxdepth;	/* double table size */
			if (yymaxdepth == YYMAXDEPTH)	/* first time growth */
			{
				void *newyys = YYNEW(int);
				void *newyyv = YYNEW(YYSTYPE);
				if (newyys != 0 && newyyv != 0)
				{
					yys = YYCOPY(newyys, yys, int);
					yyv = YYCOPY(newyyv, yyv, YYSTYPE);
				}
				else
					yynewmax = 0;	/* failed */
			}
			else				/* not first time */
			{
				yys = YYENLARGE(yys, int);
				yyv = YYENLARGE(yyv, YYSTYPE);
				if (yys == 0 || yyv == 0)
					yynewmax = 0;	/* failed */
			}
#endif
			if (yynewmax <= yymaxdepth)	/* tables not expanded */
			{
#ifdef __cplusplus
				yyerror( gettxt("uxlibc:80", "yacc stack overflow") );
#else
				yyerror( gettxt("uxlibc:80", "Yacc stack overflow") );
#endif
				YYABORT;
			}
			yymaxdepth = yynewmax;

			/* reset pointers into yys */
			yys_off = yys - yys_base;
			yy_ps = yy_ps + yys_off;
			yyps = yyps + yys_off;

			/* reset pointers into yyv */
			yypvt = yyv + yypvt_off;
			yy_pv = yyv + yy_pv_off;
			yypv = yyv + yypv_off;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			printf( "Received token " );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				printf( "Received token " );
				if ( yychar == 0 )
					printf( "end-of-file\n" );
				else if ( yychar < 0 )
					printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
#ifdef __cplusplus
				yyerror( gettxt("uxlibc:81", "syntax error") );
#else
				yyerror( gettxt("uxlibc:81", "Syntax error") );
#endif
				goto skip_init;
			//yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
				yynerrs++;
				/* FALLTHRU */
			skip_init:
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					printf( "Error recovery discards " );
					if ( yychar == 0 )
						printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 5:{ yypvt[-4].funcDef->endDefinition(yypvt[-0].stmntList); yyval.funcDef = yypvt[-4].funcDef; } break;
case 6:{ yyval.funcDef = VsParseTree::beginFunction(yypvt[-0].string); free((void *)yypvt[-0].string); } break;
case 7:{ VsFunctionDef::addArg(yypvt[-0].string); yyval.number = yypvt[-2].number + 1.; free((void *)yypvt[-0].string); } break;
case 8:{ VsFunctionDef::addArg(yypvt[-0].string); yyval.number = 1.; free((void *)yypvt[-0].string); } break;
case 9:{ yyval.number = 0.; } break;
case 10:{ yyval.stmntList = yypvt[-1].stmntList; } break;
case 11:{ yyval.stmntList = new VsStatementList; } break;
case 12:{ yyval.stmntList = new VsStatementList; if (yypvt[-0].stmnt) yyval.stmntList->append(yypvt[-0].stmnt); } break;
case 13:{ if (yypvt[-0].stmnt) yypvt[-1].stmntList->append(yypvt[-0].stmnt); yyval.stmntList = yypvt[-1].stmntList; } break;
case 14:{ yyval.stmntList = new VsStatementList; if (yypvt[-0].stmnt) yyval.stmntList->append(yypvt[-0].stmnt); } break;
case 15:{ yyval.stmntList = yypvt[-1].stmntList; } break;
case 16:{ yyval.stmnt = yypvt[-0].stmnt; } break;
case 17:{ yyval.stmnt = yypvt[-0].stmnt; } break;
case 18:{ yyval.stmnt = yypvt[-0].stmnt; } break;
case 19:{ yyval.stmnt = yypvt[-1].expr; } break;
case 20:{ yyval.stmnt = yypvt[-1].stmnt; } break;
case 21:{ yyval.stmnt = yypvt[-0].stmnt; } break;
case 22:{ yyval.stmnt = yypvt[-1].stmnt; } break;
case 23:{ yyval.stmnt = yypvt[-1].stmnt; } break;
case 24:{ yyval.stmnt = new VsReturn(yypvt[-0].expr); } break;
case 25:{ yyval.stmnt = new VsReturn(NULL); } break;
case 26:{ yyval.stmnt = new VsIf(yypvt[-2].expr,yypvt[-0].stmntList,NULL);} break;
case 27:{ yyval.stmnt = new VsIf(yypvt[-4].expr,yypvt[-2].stmntList,yypvt[-0].stmntList);} break;
case 28:{  yyval.stmnt = new VsFor(yypvt[-6].expr, yypvt[-4].expr, yypvt[-2].expr, yypvt[-0].stmntList); } break;
case 29:{ 
		yyerror("<for..in> statement not implemented yet"); 
		yyval.stmnt = new VsForIn(yypvt[-4].var, yypvt[-2].expr, yypvt[-0].stmntList); 
	    } break;
case 30:{ yyval.stmnt = new VsBreak(); } break;
case 31:{ yyval.stmnt = new VsContinue(); } break;
case 32:{ yyerror("<with> statement not implemented yet"); yyval.stmnt = new VsWith(yypvt[-2].expr, yypvt[-0].stmntList); } break;
case 33:{ yyval.stmnt = new VsWhile(yypvt[-2].expr, yypvt[-0].stmntList); } break;
case 34:{ yyval.expr = yypvt[-0].expr; } break;
case 35:{ yyval.expr = NULL; } break;
case 36:{ yyval.expr = yypvt[-0].expr; } break;
case 37:{ yyval.expr = new VsComma(yypvt[-2].expr, yypvt[-0].expr); } break;
case 38:{ yyval.expr = yypvt[-1].expr; } break;
case 39:{ yyval.expr = new VsUArithOp(yypvt[-0].expr, tMINUS); } break;
case 40:{ yyval.expr = new VsULogicOp(yypvt[-0].expr, tNOT); } break;
case 41:{ yyval.expr = new VsUArithOp(yypvt[-0].expr, tONESCOMP); } break;
case 42:{ yyval.expr = new VsAssign(yypvt[-2].var, yypvt[-0].expr); } break;
case 43:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tPLUS));} break;
case 44:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tMINUS)); } break;
case 45:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tMULTIPLY));} break;
case 46:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tDIVIDE)); } break;
case 47:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tMOD)); } break;
case 48:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tAND)); } break;
case 49:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tOR)); } break;
case 50:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tXOR)); } break;
case 51:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tLSHIFT)); } break;
case 52:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tRSHIFT)); } break;
case 53:{ yyval.expr = new VsAssign(yypvt[-2].var, new VsArith(yypvt[-2].var, yypvt[-0].expr, tRSHIFTFILL)); } break;
case 54:{ yyval.expr = new VsIncDec(yypvt[-0].expr, TRUE,  TRUE); } break;
case 55:{ yyval.expr = new VsIncDec(yypvt[-0].expr, FALSE, TRUE);} break;
case 56:{ yyval.expr = new VsIncDec(yypvt[-1].expr, TRUE,  FALSE); } break;
case 57:{ yyval.expr = new VsIncDec(yypvt[-1].expr, FALSE, FALSE); } break;
case 58:{ yyval.expr = new VsCondExpr(yypvt[-4].expr, yypvt[-2].expr, yypvt[-0].expr); } break;
case 59:{ yyval.expr = new VsLogicOp(yypvt[-2].expr, yypvt[-0].expr, tEQ); } break;
case 60:{ yyval.expr = new VsLogicOp(yypvt[-2].expr, yypvt[-0].expr, tNE); } break;
case 61:{ yyval.expr = new VsLogicOp(yypvt[-2].expr, yypvt[-0].expr, tLT); } break;
case 62:{ yyval.expr = new VsLogicOp(yypvt[-2].expr, yypvt[-0].expr, tLE); } break;
case 63:{ yyval.expr = new VsLogicOp(yypvt[-2].expr, yypvt[-0].expr, tGE); } break;
case 64:{ yyval.expr = new VsLogicOp(yypvt[-2].expr, yypvt[-0].expr, tGT); } break;
case 65:{ yyval.expr = new VsLogicOp(yypvt[-2].expr, yypvt[-0].expr, tLAND); } break;
case 66:{ yyval.expr = new VsLogicOp(yypvt[-2].expr, yypvt[-0].expr, tLOR); } break;
case 67:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tPLUS); } break;
case 68:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tMINUS); } break;
case 69:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tMULTIPLY); } break;
case 70:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tDIVIDE); } break;
case 71:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tMOD); } break;
case 72:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tAND); } break;
case 73:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tOR); } break;
case 74:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tXOR); } break;
case 75:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tLSHIFT); } break;
case 76:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tRSHIFT); } break;
case 77:{ yyval.expr = new VsArith(yypvt[-2].expr, yypvt[-0].expr, tRSHIFTFILL); } break;
case 78:{ yyval.expr = new VsConstant(yypvt[-0].string); } break;
case 79:{ yyval.expr = new VsConstant(yypvt[-0].number); } break;
case 80:{ yyval.expr = yypvt[-0].objMethodCall; } break;
case 81:{ yyval.expr = yypvt[-0].funcCall; } break;
case 82:{ yyval.expr = yypvt[-0].objMemberAccess; } break;
case 83:{ yyval.expr = yypvt[-0].arrayvar; } break;
case 84:{ yyval.expr = yypvt[-0].var; } break;
case 85:{ if (yypvt[-0].expr) yypvt[-2].exprList->append(yypvt[-0].expr); yyval.exprList = yypvt[-2].exprList; } break;
case 86:{ yyval.exprList = new VsExprList; if (yypvt[-0].expr) yyval.exprList->append(yypvt[-0].expr); } break;
case 87:{ yyval.exprList = new VsExprList; } break;
case 88:{ yyval.funcCall = NULL; 
                  VsFunctionDef *funcDef = VsParseTree::getCurrent()->findFunction(yypvt[-3].string);  
		  if (funcDef != NULL) {
		      yyval.funcCall = new VsFunctionCall( funcDef, *(yypvt[-1].exprList)); 
		  } else if (VsFunctionCall::isAnUnimplementedFunction(yypvt[-3].string)) {
		      char msg[256];

		      sprintf(msg, "Built-in function \'%s\' is not implemented yet", yypvt[-3].string);
		      yyerror(msg);
		  } else {
		      char msg[256];

		      sprintf(msg, "Function \'%s\' must be defined before it can be used", yypvt[-3].string);
		      yyerror(msg);
		  }
		  free((void *)yypvt[-3].string);
		} break;
case 89:{
		yyval.objMethodCall = NULL;
		if (yypvt[-5].expr == NULL) {
		    yyval.objMethodCall = new VsMethodCall (yypvt[-5].expr, yypvt[-3].string, *(yypvt[-1].exprList)); 
		} else {
		    char msg[256];

		    sprintf(msg, "Object method call \'%s\' is not implemented yet", yypvt[-3].string);
		    yyerror(msg);
		}
		free((void *)yypvt[-3].string); 
	    } break;
case 90:{ yyval.var = yypvt[-0].objMemberAccess; } break;
case 91:{ yyval.var = yypvt[-0].arrayvar; } break;
case 92:{ yyval.var = yypvt[-0].var; } break;
case 93:{ 
		yyval.objMemberAccess = NULL;
		if (yypvt[-2].expr == NULL) {
		    yyval.objMemberAccess = new VsMemberAccess (yypvt[-2].expr, yypvt[-0].string); 
		} else {
		    char msg[256];

		    sprintf(msg, "Access to object member \'%s\' is not implemented yet", yypvt[-0].string);
		    yyerror(msg);
		}
		free((void *)yypvt[-0].string); 
	    } break;
case 94:{ yyval.arrayvar = new VsArrayVar(yypvt[-3].expr, yypvt[-1].expr); } break;
case 95:{ 
	    yyval.var = NULL;
	    if (strcmp(yypvt[-0].string, "Math") != 0) {
    		yyval.var = VsFunctionDef::findIdentifier(yypvt[-0].string); 
	    }
	    free((void *)yypvt[-0].string); } break;
	}
	goto yystack;		/* reset registers in driver code */
}
