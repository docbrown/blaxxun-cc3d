/*
 * VrmlField_stub.h
 *
 *      Declaration of classes:
 *        VrmlField
 *        VrmlSField
 *        VrmlMField
 *        VrmlEventIn
 *
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 *
 */


#ifndef  _VRML_FIELD_
#define  _VRML_FIELD_

#include "VbBasic.h"

// Support typing for Java and for type checking when parsing routes.
enum FieldType {
        UnknownType = 0,
        SFBOOL,     SFIMAGE,     SFTIME,
        SFCOLOR,    MFCOLOR,     SFFLOAT,     MFFLOAT,
        SFINT32,    MFINT32,     SFNODE,      MFNODE,
        SFROTATION, MFROTATION,  SFSTRING,    MFSTRING,
        SFVEC2F,    MFVEC2F,     SFVEC3F,     MFVEC3F
};

//////////////////////////////////////////////////////////////////////////////
class AFX_EXT_CLASS VrmlField {
  public:
    VrmlField();
    ~VrmlField();

    // Returns type of this field.
    enum FieldType      getType() const
                            { return ((enum FieldType) flags.fieldType); }

    void		setHasBeenSet(VbBool value)
			    { flags.hasBeenSet = value; }

  protected:
    struct {
        // First two bits are for "breaking loops" during their associated ops.
        unsigned int fieldType          : 5; // E.g., SFIMAGE, SFTIME, ...
	unsigned int hasBeenSet		: 1; // Scripts notify, may not setValue()
    }                        flags;
};


//////////////////////////////////////////////////////////////////////////////
class AFX_EXT_CLASS VrmlSField : public VrmlField {
  public:
    VrmlSField();
    ~VrmlSField();
};


//////////////////////////////////////////////////////////////////////////////
class AFX_EXT_CLASS VrmlMField : public VrmlField {
  public:
    VrmlMField();
    ~VrmlMField();

    int getNum() { return 0; }
};


class AFX_EXT_CLASS VrmlEventIn {
  public:
    VrmlEventIn();
    ~VrmlEventIn();
};

#endif /* _VRML_FIELD_ */
