/*
 * VrmlFields_stub.h
 *
 *      Include all the field headers
 *
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 *
 */

#ifndef  _VRML_FIELDS_
#define  _VRML_FIELDS_

#include "system.h"
#include "vbbasic.h"
#include "vbcolor.h"
#include "vblinear.h"
#include "vbtime.h"
#include "vrmlfield_stub.h"

class VrmlNode {
    VrmlNode() {}
    ~VrmlNode() {}
};

class VrmlMFColor: public VrmlMField {
  public:
    VrmlMFColor();
    void setValues(int, int, const VbColor *) {}
    void set1Value(int, VbColor) {}
    const VbColor *getValues(int) { return NULL; }
};

class VrmlMFFloat: public VrmlMField { 
  public:
    VrmlMFFloat();
    void setValues(int, int, const float *) {}
    void set1Value(int, float) {}
    const float *getValues(int) { return NULL; }
};

class VrmlMFInt32: public VrmlMField { 
  public:
    VrmlMFInt32();
    void setValues(int, int, const int32_t *) {}
    void set1Value(int, int32_t) {}
    const int32_t *getValues(int) { return NULL; }
};

class VrmlMFNode: public VrmlMField { 
  public:
    VrmlMFNode();
    void setValues(int, int, const VrmlNode **) {}
    void set1Value(int, VrmlNode *) {}
    const VrmlNode **getValues(int) { return NULL; }
};

class VrmlMFRotation: public VrmlMField { 
  public:
    VrmlMFRotation();
    void setValues(int, int, const VbRotation *) {}
    void set1Value(int, VbRotation) {}
    const VbRotation *getValues(int) { return NULL; }
};

class VrmlMFString: public VrmlMField { 
  public:
    VrmlMFString();
    void setValues(int, int, const VbString *) {}
    void set1Value(int, VbString) {}
    const VbString *getValues(int) { return NULL; }
};

class VrmlMFVec2f: public VrmlMField { 
  public:
    VrmlMFVec2f();
    void setValues(int, int, const VbVec2f *) {}
    void set1Value(int, VbVec2f) {}
    const VbVec2f *getValues(int) { return NULL; }
};

class VrmlMFVec3f: public VrmlMField { 
  public:
    VrmlMFVec3f();
    void setValues(int, int, const VbVec3f *) {}
    void set1Value(int, VbVec3f) {}
    const VbVec3f *getValues(int) { return NULL; }
};

class VrmlSFBool: public VrmlSField { 
  public:
    VrmlSFBool();
    void setValue(const VbBool& v) { value = v; }
    const VbBool& getValue() { return value; }

  private:
    VbBool value;
};

class VrmlSFColor: public VrmlSField { 
  public:
    VrmlSFColor();
    void setValue(const VbColor& v) { value = v; }
    const VbColor& getValue() { return value; }

  private:
    VbColor value;
};

class VrmlSFFloat: public VrmlSField { 
  public:
    VrmlSFFloat();
    void setValue(float v) { value = v; }
    float getValue() { return value; }

  private:
    float value;
};

class VrmlSFImage: public VrmlSField { 
  public:
    VrmlSFImage();
    void setValue(void * v) { value = v; }
    void * getValue() { return value; }

  private:
    void *value;
};

class VrmlSFInt32: public VrmlSField { 
  public:
    VrmlSFInt32();
    void setValue(int32_t v) { value = v; }
    int32_t getValue() { return value; }

  private:
    int32_t value;
};

class VrmlSFNode: public VrmlSField { 
  public:
    VrmlSFNode();
    void setValue(VrmlNode * v) { value = v; }
    VrmlNode *getValue() { return value; }

  private:
    VrmlNode *value;
};

class VrmlSFRotation: public VrmlSField { 
  public:
    VrmlSFRotation();
    void setValue(const VbRotation& v) { value = v; }
    const VbRotation& getValue() { return value; }

  private:
    VbRotation value;
};

class VrmlSFString: public VrmlSField { 
  public:
    VrmlSFString();
    void setValue(const VbString& v) { value = v; }
    const VbString& getValue() { return value; }

  private:
    VbString value;
};

class VrmlSFTime: public VrmlSField { 
  public:
    VrmlSFTime();
    void setValue(const VbTime& v) { value = v; }
    const VbTime& getValue() { return value; }

  private:
    VbTime value;
};

class VrmlSFVec2f: public VrmlSField { 
  public:
    VrmlSFVec2f();
    void setValue(const VbVec2f& v) { value = v; }
    const VbVec2f& getValue() { return value; }

  private:
    VbVec2f value;
};

class VrmlSFVec3f: public VrmlSField { 
  public:
    VrmlSFVec3f();
    void setValue(const VbVec3f& v) { value = v; }
    const VbVec3f& getValue() { return value; }

  private:
    VbVec3f value;
};

#endif /* _VRML_FIELDS_ */
