/*
 * VsFields.h
 *
 *      Declaration of classes:
 *	  VsField
 *	  VsSFInt   (takes care of SFInt32 and SFBool)
 *        VsSFFloat (takes care of SFFloat and SFTime)
 *	  VsSFFloatArray (takes care of SFVec2F, SFVec3F, SFColor, SFRotation)
 *	  VsMFInt   (takes care of MFInt32)
 *	  VsMFFloat   (takes care of MFFloat)
 *	  VsSFString
 *	  VsMFString
 *	  VsSFVoid
 *	  VsMFVoid
 *
 * Subclasses of VsVar that take care of interfacing with VRML
 * fields/eventOuts.
 * 
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 */
#ifndef _VS_VAR_
#define _VS_VAR_

#include "vsexpr.h"

#include "vrmlfield_stub.h"

//
// Classes for fields/eventOuts of various sorts:
//

// Base class

class VsField : public VsVar {
  public:
    enum Permission {
	RW, // For eventOuts/fields
        RO, // For eventIns
    };

    // Creation method, given a field type Does The Right
    // Thing.
    static VsField *	create(FieldType t, Permission p);

    virtual void	setField(VrmlField *f) = 0;

  protected:
    Permission permission;
};


class VsSFInt : public VsField {
  public:
    VsSFInt(FieldType t);

    virtual VsValue		evaluate(VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, VsFunctionCall *);

    virtual void  		setField(VrmlField *f);

  protected:
    virtual ~VsSFInt();
  private:
    FieldType type;
    VrmlField *field;
    VsValue myValue;
};

class VsSFFloat : public VsField {
  public:
    VsSFFloat(FieldType t);

    virtual VsValue		evaluate(VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, VsFunctionCall *);

    virtual void 		setField(VrmlField *f);
  
  protected:
    virtual ~VsSFFloat();
  private:
    FieldType type;
    VrmlField *field;
    VsValue myValue;
};

class VsSFFloatArray : public VsField {
  public:
    VsSFFloatArray(FieldType t);

    virtual VsValue		evaluate(VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, int32_t index, VsFunctionCall *);
    virtual void 		setField(VrmlField *f);
  
  protected:
    virtual ~VsSFFloatArray();
  private:
    FieldType type;
    VrmlField *field;
    VsValue myValue;
};

class VsSFVoid : public VsField {
  public:
    VsSFVoid(FieldType t);
    virtual ~VsSFVoid();

    virtual VsValue		evaluate(VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, VsFunctionCall *);

    virtual void 		setField(VrmlField *f);

  private:
    FieldType type;
    VrmlField *field;
    VsValue myValue;
};

class VsSFString : public VsField {
  public:
    VsSFString(FieldType t);
    virtual ~VsSFString();

    virtual VsValue		evaluate(VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, VsFunctionCall *);

    virtual void 		setField(VrmlField *f);

  private:
    FieldType type;
    VrmlField *field;
    VsValue myValue;
};

class VsMFInt : public VsField {
  public:
    VsMFInt(FieldType t);

    virtual VsValue		evaluate(VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, int32_t index, VsFunctionCall *);

    virtual void  		setField(VrmlField *f);

  protected:
    virtual ~VsMFInt();
  private:
    FieldType type;
    VrmlField *field;
    VsValue myValue;
};

class VsMFFloat : public VsField {
  public:
    VsMFFloat(FieldType t);

    virtual VsValue		evaluate(VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, int32_t index, VsFunctionCall *);

    virtual void  		setField(VrmlField *f);

  protected:
    virtual ~VsMFFloat();
  private:
    FieldType type;
    VrmlField *field;
    VsValue myValue;
};

class VsMFVoid : public VsField {
  public:
    VsMFVoid(FieldType t);

    virtual VsValue		evaluate(VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, int32_t index, VsFunctionCall *);

    virtual void  		setField(VrmlField *f);

  protected:
    virtual ~VsMFVoid();
  private:
    FieldType type;
    VrmlField *field;
    VsValue myValue;
};

class VsMFString : public VsField {
  public:
    VsMFString(FieldType t);

    virtual VsValue		evaluate(VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, VsFunctionCall *);
    virtual VsValue		assign(const VsValue &, int32_t index, VsFunctionCall *);

    virtual void  		setField(VrmlField *f);

  protected:
    virtual ~VsMFString();
  private:
    FieldType type;
    VrmlField *field;
    VsValue myValue;
};

#endif /* _VS_VAR_ */
