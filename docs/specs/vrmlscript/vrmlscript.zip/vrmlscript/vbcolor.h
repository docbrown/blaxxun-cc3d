/*
 * Copyright (C) 1996   Silicon Graphics, Inc.
 *
 _______________________________________________________________________
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 |
 |   $Revision: 1.3 $
 |
 |   Description:
 |	This file contains the VbColor class definition.
 |
 |   Author(s)	: Alain Dumesny
 |		    (PC version) Alan Norton
 |
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 _______________________________________________________________________
 */

#ifndef  _VB_COLOR_H_
#define  _VB_COLOR_H_

#include "system.h"

#include "VbLinear.h"


//////////////////////////////////////////////////////////////////////////////
//
//  Class: VbColor
//
//  3D vector used to represent an RGB color. Each component of the vector is 
// a floating-point number between 0.0 and 1.0 .
//
//////////////////////////////////////////////////////////////////////////////

class VbColor;



class AFX_EXT_CLASS VbColor : public VbVec3f {
  public:
    // Default constructor
    VbColor();

    // Constructor given an VbVec3f
    VbColor(const VbVec3f vec3f) { setValue(vec3f.getValue()); }

    // Constructor given an array of 3 components
    VbColor(const float rgb[3])				{ setValue(rgb); }

    // Constructor given 3 individual components
    VbColor(float r, float g, float b)			{ setValue(r, g, b); }


    //
    // HSV routines. Those are 3 floats containing the Hue, Saturation and
    // Value (same as brightness) of the color.
    //

    // Sets value of color vector from 3 hsv components
    VbColor &	setHSVValue(float h, float s, float v);

    // Sets value of color vector from array of 3 hsv components
    VbColor &	setHSVValue(const float hsv[3])
			{ return setHSVValue(hsv[0], hsv[1], hsv[2]); }

    // Returns 3 individual hsv components
    void	getHSVValue(float &h, float &s, float &v) const;

    // Returns an array of 3 hsv components
    void	getHSVValue(float hsv[3]) const
 			{ getHSVValue(hsv[0], hsv[1], hsv[2]); }

    void	matchRamp(VbColor& rampColor) const;

    static void	setPalette(VbBool param) 
	{usePalette = param;}
    static VbBool useColorPalette() {return usePalette;}

    //Produce a 16-bit representation of color:
    unsigned short       make16();
    
  private:
      static VbBool usePalette;
};

#endif /* _VB_COLOR_H_ */

