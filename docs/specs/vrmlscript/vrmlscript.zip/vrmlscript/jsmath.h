/*
 * JsMath.h
 *
 *      Declaration of classes:
 *        JsMath
 *
 * Function support
 * 
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 */
 
#ifndef _JS_MATH_
#define _JS_MATH_

#include <math.h>
#include <stdlib.h>

#ifdef WIN32
#undef max
#undef min
#endif

// Class that implements the JavaScript Math object

class JsMath {
  public:
    static double abs(double x)			{ return ::fabs(x); }
    static double acos(double x)		{ return ::acos(x); }
    static double asin(double x)		{ return ::asin(x); }
    static double atan(double x)		{ return ::atan(x); }
    static double ceil(double x)		{ return ::ceil(x); }
    static double cos(double x)			{ return ::cos(x); }    
    static double exp(double x)			{ return ::exp(x); }
    static double floor(double x)		{ return ::floor(x); }
    static double log(double x)			{ return ::log(x); }
    static double max(double x, double y)	{ if (x>y) 
						    return x;
						  else
						    return y;
						}
    static double min(double x, double y)	{ if (x<y)
						    return x;
						  else
						    return y;
						}
    static double pow(double base, double exp)	{ return ::pow(base, exp); }
#ifdef WIN32
    static double random()			{ return ((double)::rand()) / RAND_MAX; }
#else
    static double random()			{ return ::drand48(); }
#endif
    static double round(double x)		{ if ((x - (long)x) < 0.5) 
						    return ::floor(x);
						  else
						    return ::ceil(x);
						}
    static double sin(double x)			{ return ::sin(x); }
    static double sqrt(double x)		{ return ::sqrt(x); }
    static double tan(double x)			{ return ::tan(x); }
    
    static double E;
    static double LN10;
    static double LN2;
    static double PI;
    static double SQRT1_2;
    static double SQRT2;
};    

#endif /* _JS_MATH_ */
