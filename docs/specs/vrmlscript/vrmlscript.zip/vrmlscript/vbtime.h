//  -*- C++ -*-

/*
 * Copyright (C) 1996   Silicon Graphics, Inc.
 *
 _______________________________________________________________________
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 |
 |   $Revision: 1.3 $
 |
 |   Description:
 |	This file defines the VbTime class for manipulating times
 |
 |   Classes:
 |	VbTime
 |
 |   Author(s)		: Nick Thompson
 |			    Alan Norton (PC version)
 |
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 _______________________________________________________________________
 */

#ifndef _SB_TIME_
#define _SB_TIME_

#include "system.h"

#include <Time.h>
#include <math.h>
#include "VbBasic.h"
#include "VbString.h"



//////////////////////////////////////////////////////////////////////////////
//
//  Class: VbTime
//
//  Representation of a time.  Some parts are not adequately debugged:
//  for example, it is not clear when it is legal to have negative
//  values.
//
//////////////////////////////////////////////////////////////////////////////

class AFX_EXT_CLASS VbTime {
  public:

    // Default constructor
    VbTime()					{}

    // Constructor taking a double (in seconds)
    VbTime(double sec)
	{ t = sec; }

    // Constructor taking seconds + microseconds
    VbTime(long sec, long usec)		
	{ t = sec + 1.e-6 * usec; }


    // Get the current time (seconds since Jan 1, 1970)
    static VbTime		getTimeOfDay();

    // Set to the current time (seconds since Jan 1, 1970)
    void			setToTimeOfDay();

    // Get a zero time
    static VbTime		zero()
	{ return VbTime(0.0); }

    // Get a time far, far into the future
    static VbTime		maxTime()
	{ return VbTime(2.0e9); }

    // Set time from a double (in seconds)
    void		setValue(double sec)
	{ t = sec; }

    // Set time from seconds + microseconds
    void		setValue(long sec, long usec)  	// System long
	{ t= sec + 1.0e-6 * usec; }

    // Get time in seconds as a double
    double		getValue() const
	{ return t; }

    // Get time in seconds & microseconds
    void		getValue(long &sec, long &usec) const  // System long
	{ sec = (long)t; usec = (long)(t * 1.0-6); }

    // Get time in milliseconds (for Xt)
    unsigned long	getMsecValue() const			// System long
	{ return (unsigned long) (t* 1000.0); }

    // Convert to a string.  The default format is seconds with
    // 3 digits of fraction precision.  See the SbTime man page for
    // explanation of the format string.
    VbString			format(const char *fmt = "%S.%i") const;

    // Addition
    friend VbTime AFX_EXT_CLASS operator +(const VbTime &t0, const VbTime &t1);

    // Subtraction
    friend VbTime AFX_EXT_CLASS operator -(const VbTime &t0, const VbTime &t1);

    // Destructive addition
    VbTime &			operator +=(const VbTime &tm)
	{ return (*this = *this + tm); }

    // Destructive subtraction
    VbTime &			operator -=(const VbTime &tm)
	{ return (*this = *this - tm); }

    // Unary negation
    VbTime			operator -() const
	{ return VbTime(-t); }

    // multiplication by scalar
    friend VbTime AFX_EXT_CLASS operator *(const VbTime &tm, double s);

    friend VbTime		operator *(double s, const VbTime &tm)
	{ return tm * s; }

    // destructive multiplication by scalar
    VbTime &			operator *=(double s)
	{ *this = *this * s; return *this; }

    // division by scalar
    friend VbTime AFX_EXT_CLASS operator /(const VbTime &tm, double s);

    // destructive division by scalar
    VbTime &			operator /=(double s)
	{ return (*this = *this / s); }

    // division by another time
    double			operator /(const VbTime &tm) const
	{ return getValue() / tm.getValue(); }

    // modulus for two times
    VbTime			operator %(const VbTime &tm) const
	{ return *this - tm * floor(*this / tm); }

    // equality operators
    int				operator ==(const VbTime &tm) const
	{ return (t == tm.t); }

    int				operator !=(const VbTime &tm) const
	{ return ! (*this == tm); }

    // relational operators
    inline VbBool		operator <(const VbTime &tm) const;
    inline VbBool		operator >(const VbTime &tm) const;
    inline VbBool		operator <=(const VbTime &tm) const;
    inline VbBool		operator >=(const VbTime &tm) const;

  private:
    double		t;
};


inline VbBool
VbTime::operator <(const VbTime &tm) const
{
    if (t < tm.t)
	return TRUE;
    else
	return FALSE;
}

inline VbBool
VbTime::operator >(const VbTime &tm) const
{
    if (t > tm.t)
	return TRUE;
    else
	return FALSE;
}

inline VbBool
VbTime::operator <=(const VbTime &tm) const
{
    if (t <= tm.t)
	return TRUE;
    else
	return FALSE;
}

inline VbBool
VbTime::operator >=(const VbTime &tm) const
{
    if (t >= tm.t)
	return TRUE;
    else
	return FALSE;
}



#endif /* _VB_TIME_ */
