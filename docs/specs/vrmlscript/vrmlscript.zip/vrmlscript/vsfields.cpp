/*
 * VsFields.cpp
 *
 *     Implementation of classes:
 *        VsSFInt
 *	  VsFFloat
 *	  VsSFVec3f
 *
 * Subclasses of VsVar that take care of interfacing with VRML
 * fields/eventOuts.
 * 
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 */

#include <assert.h>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>
#include "vsfields.h"

#include "vrmlfields_stub.h"

VsField *
VsField::create(FieldType t, Permission p)
{
    VsField *result = NULL;
    switch(t) {
      case SFINT32:
      case SFBOOL:
	result = new VsSFInt(t);
	break;
      case SFFLOAT:
      case SFTIME:
	result = new VsSFFloat(t);
	break;
      case SFVEC2F:
      case SFVEC3F:
      case SFCOLOR:
      case SFROTATION:
	result = new VsSFFloatArray(t);
	break;
      case SFSTRING:
	result = new VsSFString(t);
	break;
      case SFNODE:
	result = new VsSFVoid(t);
	break;
      case MFINT32:
	result = new VsMFInt(t);
	break;
      case MFFLOAT:
	result = new VsMFFloat(t);
	break;
      case MFSTRING:
	result = new VsMFString(t);
	break;
      case MFNODE:
	result = new VsMFVoid(t);
	break;
    }
    if (result)
        result->permission = p;
    return result;
}


// VsSFInt handles SFInt32 and SFBool fields

VsSFInt::VsSFInt(FieldType t)
{
    type = t;
}

VsSFInt::~VsSFInt()
{
} 

VsValue
VsSFInt::evaluate(VsFunctionCall *)
{
    return myValue;
}

VsValue
VsSFInt::assign(const VsValue &v, VsFunctionCall *)
{
    int n;

    switch (v.type) {
      case VsValue::vNUMBER:
	if (type == SFBOOL)
	    n = (v.number != 0.0);
	else
	    n = (int) v.number;
	break;
    
    case VsValue::vSTRING:
	if (type == SFBOOL)
	    n = (v.string != NULL && strlen(v.string) != 0);
	else
	    n = (int) atof(v.string);
	break;

      default:
	// ??? Warn if other types ???
	break;
    }

    if (permission == VsField::RW) {
	myValue.number = n;

	field->setHasBeenSet((VbBool) TRUE);
	if (type == SFBOOL) {
	    ((VrmlSFBool *)field)->setValue(n);
	} else {
	    ((VrmlSFInt32 *)field)->setValue(n);
	}
    }

    return myValue;
}

void
VsSFInt::setField(VrmlField *f)
{
    _ASSERT(f->getType() == type);

    field = f;
    myValue.type = VsValue::vNUMBER;

    if (type == SFBOOL) {
	myValue.number = ((VrmlSFBool *)f)->getValue();
    }
    else {
	myValue.number = ((VrmlSFInt32 *)f)->getValue();
    }
}


// VsSFFloat handles SFFloat and SFTime fields 

VsSFFloat::VsSFFloat(FieldType t)
{
    _ASSERT(t == SFFLOAT || t == SFTIME);
    type = t;
}

VsSFFloat::~VsSFFloat()
{
}

VsValue
VsSFFloat::evaluate(VsFunctionCall *)
{
    return myValue;
}

VsValue
VsSFFloat::assign(const VsValue &v, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vNUMBER:
	    myValue.number = (float)v.number;
	    break;

	  case VsValue::vSTRING:
	    // ??? Use strotod and complain if not completely converted ???
	    myValue.number = (float)atof(v.string);
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
	if (type == SFFLOAT) {
	    ((VrmlSFFloat *)field)->setValue((float)myValue.number);
	} else {
	    ((VrmlSFTime *)field)->setValue(myValue.number);
	}
    }

    return myValue;
}

void
VsSFFloat::setField(VrmlField *f)
{
    _ASSERT(f->getType() == type);

    field = f;
    myValue.type = VsValue::vNUMBER;
    if (type == SFFLOAT)
        myValue.number = ((VrmlSFFloat *)field)->getValue();
    else
	myValue.number = ((VrmlSFTime *)field)->getValue().getValue();
}


// VsSFFloatArray handles SFVec2f, SFVec3f, SFColor and SFRotation fields 

VsSFFloatArray::VsSFFloatArray(FieldType t)
{
    _ASSERT(t == SFVEC2F || t == SFVEC3F || t == SFCOLOR || t == SFROTATION);
    type = t;

    myValue.floatArray = NULL;
}

VsSFFloatArray::~VsSFFloatArray()
{
    if (myValue.floatArray != NULL) {
	delete myValue.floatArray;
	myValue.floatArray = NULL;
    }
}

VsValue
VsSFFloatArray::evaluate(VsFunctionCall *)
{
    return myValue;
}

VsValue
VsSFFloatArray::assign(const VsValue &v, VsFunctionCall *)
{
    int i;

    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vFLOAT_ARRAY:
	    _ASSERT(myValue.floatArray->length == v.floatArray->length);
	    for (i=0; i<myValue.floatArray->length; i++) {
		myValue.floatArray->array[i] = v.floatArray->array[i];
	    }
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);

	switch (type) {
	  case SFVEC2F:
	    ((VrmlSFVec2f *)field)->setValue((float *)myValue.floatArray->array);
	    break;
	  case SFVEC3F:
	    ((VrmlSFVec3f *)field)->setValue((float *)myValue.floatArray->array);
	    break;
	  case SFCOLOR:
	    ((VrmlSFColor *)field)->setValue((float *)myValue.floatArray->array);
	    break;
	  case SFROTATION:
	    ((VrmlSFRotation *)field)->setValue((float *)myValue.floatArray->array);
	    break;
	  default:
	    break;
	}
    }

    return myValue;
}

VsValue
VsSFFloatArray::assign(const VsValue &v, int32_t index, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	if (myValue.floatArray->length <= index) {
	    return myValue;
	}

	switch (v.type) {
	  case VsValue::vNUMBER:
	      myValue.floatArray->array[index] = (float)v.number;
	      break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
	switch (type) {
	  case SFVEC2F:
	    ((VrmlSFVec2f *)field)->setValue((float *)myValue.floatArray->array);
	    break;
	  case SFVEC3F:
	    ((VrmlSFVec3f *)field)->setValue((float *)myValue.floatArray->array);
	    break;
	  case SFCOLOR:
	    ((VrmlSFColor *)field)->setValue((float *)myValue.floatArray->array);
	    break;
	  case SFROTATION:
	    ((VrmlSFRotation *)field)->setValue((float *)myValue.floatArray->array);
	    break;
	  default:
	    break;
	}
    }

    return myValue;
}

void
VsSFFloatArray::setField(VrmlField *f)
{
    _ASSERT(f->getType() == type);

    field = f;
    myValue.type = VsValue::vFLOAT_ARRAY;

    myValue.floatArray = new FloatArray;

    switch (type) {
      case SFVEC2F:
	myValue.floatArray->length = 2;
	myValue.floatArray->array = (float *)(((VrmlSFVec2f *)field)->getValue()).getValue();
	break;
      case SFVEC3F:
	myValue.floatArray->length = 3;
	myValue.floatArray->array = (float *)(((VrmlSFVec3f *)field)->getValue()).getValue();
	break;
      case SFCOLOR:
	myValue.floatArray->length = 3;
	myValue.floatArray->array = (float *)(((VrmlSFColor *)field)->getValue()).getValue();
	break;
      case SFROTATION:
	myValue.floatArray->length = 4;
	myValue.floatArray->array = (float *)(((VrmlSFRotation *)field)->getValue()).getValue();
	break;
      default:
	break;
    }
}


// VsSFVoid handles SFNode fields 

VsSFVoid::VsSFVoid(FieldType t)
{
    _ASSERT(t == SFNODE);
    type = t;
}

VsSFVoid::~VsSFVoid()
{
}

VsValue
VsSFVoid::evaluate(VsFunctionCall *)
{
    return myValue;
}

VsValue
VsSFVoid::assign(const VsValue &v, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vVOID:
	    myValue.data = v.data;
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
	if (type == SFNODE) {
	    ((VrmlSFNode *)field)->setValue((VrmlNode *)myValue.data);
	} 
    }

    return myValue;
}

void
VsSFVoid::setField(VrmlField *f)
{
    _ASSERT(f->getType() == type);

    field = f;

    if (type == SFNODE) {
	myValue.type = VsValue::vVOID;
        myValue.data = ((VrmlSFNode *)field)->getValue();
    }
}

// VsSFString handles SFString fields 

VsSFString::VsSFString(FieldType t)
{
    _ASSERT(t == SFSTRING);
    type = t;
}

VsSFString::~VsSFString()
{
}

VsValue
VsSFString::evaluate(VsFunctionCall *)
{
    return myValue;
}

VsValue
VsSFString::assign(const VsValue &v, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vSTRING:
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
	if (type == SFSTRING) {
	    ((VrmlSFString *)field)->setValue(v.string);
	} 
    }

    return myValue;
}

void
VsSFString::setField(VrmlField *f)
{
    _ASSERT(f->getType() == type);

    field = f;

    if (type == SFSTRING) {
	myValue.type = VsValue::vSTRING;
        myValue.string = (char *)(((VrmlSFString *)field)->getValue().getString());
    }
}


// VsMFInt handles MFInt32 fields

VsMFInt::VsMFInt(FieldType t)
{
    _ASSERT(t == MFINT32);
    type = t;

    myValue.int32Array = NULL;
}

VsMFInt::~VsMFInt()
{
    if (myValue.int32Array != NULL) {
	delete myValue.int32Array;
	myValue.int32Array = NULL;
    }
}

VsValue
VsMFInt::evaluate(VsFunctionCall *)
{
    return myValue;
}

VsValue
VsMFInt::assign(const VsValue &v, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vINT32_ARRAY:
	    myValue.int32Array->length = v.int32Array->length;
	    ((VrmlMFInt32 *)field)->setValues(0, v.int32Array->length, (int32_t *)v.int32Array->array);
	    myValue.int32Array->array = (int32_t *)((VrmlMFInt32 *)field)->getValues(0);
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
    }

    return myValue;
}

VsValue
VsMFInt::assign(const VsValue &v, int32_t index, VsFunctionCall *)
{
    if (permission == VsField::RW) {

	switch (v.type) {
	  case VsValue::vNUMBER:
	      if (index+1 > myValue.int32Array->length) {
		  myValue.int32Array->length = index+1;
	      }
	      ((VrmlMFInt32 *)field)->set1Value(index, (int32_t)v.number);
	      myValue.int32Array->array = (int32_t *)((VrmlMFInt32 *)field)->getValues(0);

	      break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
    }

    return myValue;
}

void
VsMFInt::setField(VrmlField *f)
{
    _ASSERT(f->getType() == type);

    VrmlMFInt32 *mfIntField = (VrmlMFInt32 *)f;

    field = f;
    myValue.type = VsValue::vINT32_ARRAY;

    myValue.int32Array = new Int32Array;

    switch (type) {
      case MFINT32:
	myValue.int32Array->length = mfIntField->getNum();
	myValue.int32Array->array = (int32_t *)mfIntField->getValues(0);
	break;
      default:
	break;
    }
}


// VsMFFloat handles MFFloat fields

VsMFFloat::VsMFFloat(FieldType t)
{
    _ASSERT(t == MFFLOAT);
    type = t;

    myValue.floatArray = NULL;
}

VsMFFloat::~VsMFFloat()
{
    if (myValue.floatArray != NULL) {
	delete myValue.floatArray;
	myValue.floatArray = NULL;
    }
}

VsValue
VsMFFloat::evaluate(VsFunctionCall *)
{
    return myValue;
}

VsValue
VsMFFloat::assign(const VsValue &v, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vFLOAT_ARRAY:
	    myValue.floatArray->length = v.floatArray->length;
	    ((VrmlMFFloat *)field)->setValues(0, v.floatArray->length, (float *)v.floatArray->array);
	    myValue.floatArray->array = (float *)((VrmlMFFloat *)field)->getValues(0);	    	    
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
    }

    return myValue;
}

VsValue
VsMFFloat::assign(const VsValue &v, int32_t index, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vNUMBER:
	      if (index+1 > myValue.floatArray->length) {
		  myValue.floatArray->length = index+1;
	      }
	      ((VrmlMFFloat *)field)->set1Value(index, (float)v.number);
	      myValue.floatArray->array = (float *)((VrmlMFFloat *)field)->getValues(0);	      
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
    }

    return myValue;
}

void
VsMFFloat::setField(VrmlField *f)
{
    _ASSERT(f->getType() == type);

    VrmlMFFloat* mfFloatField = (VrmlMFFloat *)f;

    field = f;
    myValue.type = VsValue::vFLOAT_ARRAY;

    myValue.floatArray = new FloatArray;

    switch (type) {
      case MFFLOAT:
	myValue.floatArray->length = mfFloatField->getNum();
	myValue.floatArray->array = (float *)mfFloatField->getValues(0);
	break;
      default:
	break;
    }
}

// VsMFVoid handles MFNode fields

VsMFVoid::VsMFVoid(FieldType t)
{
    _ASSERT(t == MFNODE);

    type = t;

    myValue.voidArray = NULL;
}

VsMFVoid::~VsMFVoid()
{
    if (myValue.voidArray != NULL) {
	delete myValue.voidArray;
	myValue.voidArray = NULL;
    }
}

VsValue
VsMFVoid::evaluate(VsFunctionCall *)
{
    return myValue;
}

VsValue
VsMFVoid::assign(const VsValue &v, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vVOID_ARRAY:
	    myValue.voidArray->length = v.voidArray->length;
	    ((VrmlMFNode *)field)->setValues(0, v.voidArray->length, (const VrmlNode **)v.voidArray->array);
	    myValue.voidArray->array = (void **)((VrmlMFNode *)field)->getValues(0);	    	    
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
    }

    return myValue;
}

VsValue
VsMFVoid::assign(const VsValue &v, int32_t index, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vVOID:
	      if (index+1 > myValue.voidArray->length) {
		  myValue.voidArray->length = index+1;
	      }
	      ((VrmlMFNode *)field)->set1Value(index, (VrmlNode *)v.data);
	      myValue.voidArray->array = (void **)((VrmlMFNode *)field)->getValues(0);	      
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
    }

    return myValue;
}

void
VsMFVoid::setField(VrmlField *f)
{
    _ASSERT(f->getType() == type);

    VrmlMFNode* mfNodeField = (VrmlMFNode *)f;

    field = f;
    myValue.type = VsValue::vVOID_ARRAY;

    myValue.voidArray = new VoidArray;

    switch (type) {
      case MFNODE:
	myValue.voidArray->length = mfNodeField->getNum();
	myValue.voidArray->array = (void **)mfNodeField->getValues(0);
	break;
      default:
	break;
    }
}


// VsMFString handles MFString fields

VsMFString::VsMFString(FieldType t)
{
    _ASSERT(t == MFSTRING);

    type = t;

    myValue.stringArray = NULL;
}

VsMFString::~VsMFString()
{
    if (myValue.stringArray != NULL) {
	delete myValue.stringArray;
	myValue.stringArray = NULL;
    }
}

VsValue
VsMFString::evaluate(VsFunctionCall *)
{
    return myValue;
}

VsValue
VsMFString::assign(const VsValue &v, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vSTRING_ARRAY:
	    myValue.stringArray->length = v.stringArray->length;
	    ((VrmlMFString *)field)->setValues(0, v.stringArray->length, v.stringArray->array);
	    myValue.stringArray->array = (VbString *)((VrmlMFString *)field)->getValues(0);	    	    
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
    }

    return myValue;
}

VsValue
VsMFString::assign(const VsValue &v, int32_t index, VsFunctionCall *)
{
    if (permission == VsField::RW) {
	switch (v.type) {
	  case VsValue::vSTRING:
	      if (index+1 > myValue.stringArray->length) {
		  myValue.stringArray->length = index+1;
	      }
	      ((VrmlMFString *)field)->set1Value(index, v.string);
	      myValue.stringArray->array = (VbString *)((VrmlMFString *)field)->getValues(0);	      
	    break;

	  default:
	    // ??? Warn if other types ???
	    break;
	}

	field->setHasBeenSet((VbBool) TRUE);
    }

    return myValue;
}

void
VsMFString::setField(VrmlField *f)
{
    _ASSERT(f->getType() == type);

    VrmlMFString* mfStringField = (VrmlMFString *)f;

    field = f;
    myValue.type = VsValue::vSTRING_ARRAY;

    myValue.stringArray = new StringArray;

    switch (type) {
      case MFSTRING:
	myValue.stringArray->length = mfStringField->getNum();
	myValue.stringArray->array = (VbString *)mfStringField->getValues(0);
	break;
      default:
	break;
    }
}










