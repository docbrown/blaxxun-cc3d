/*
 * VrmlFields_stub.cpp
 *
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 *
 */

#include "vrmlfields_stub.h"

VrmlMFColor::VrmlMFColor() { flags.fieldType = MFCOLOR; }
VrmlMFFloat::VrmlMFFloat() { flags.fieldType = MFFLOAT; }
VrmlMFInt32::VrmlMFInt32() { flags.fieldType = MFINT32; }
VrmlMFNode::VrmlMFNode() { flags.fieldType = MFNODE; }
VrmlMFRotation::VrmlMFRotation() { flags.fieldType = MFROTATION; }
VrmlMFString::VrmlMFString() { flags.fieldType = MFSTRING; }
VrmlMFVec2f::VrmlMFVec2f() { flags.fieldType = MFVEC2F; }
VrmlMFVec3f::VrmlMFVec3f() { flags.fieldType = MFVEC3F; }
VrmlSFBool::VrmlSFBool() { flags.fieldType = SFBOOL; }
VrmlSFColor::VrmlSFColor() { flags.fieldType = SFCOLOR; }
VrmlSFFloat::VrmlSFFloat() { flags.fieldType = SFFLOAT; }
VrmlSFImage::VrmlSFImage() { flags.fieldType = SFIMAGE; }
VrmlSFInt32::VrmlSFInt32() { flags.fieldType = SFINT32; }
VrmlSFNode::VrmlSFNode() { flags.fieldType = SFNODE; }
VrmlSFRotation::VrmlSFRotation() { flags.fieldType = SFROTATION; }
VrmlSFString::VrmlSFString() { flags.fieldType = SFSTRING; }
VrmlSFTime::VrmlSFTime() { flags.fieldType = SFTIME; }
VrmlSFVec2f::VrmlSFVec2f() { flags.fieldType = SFVEC2F; }
VrmlSFVec3f::VrmlSFVec3f() { flags.fieldType = SFVEC3F; }
