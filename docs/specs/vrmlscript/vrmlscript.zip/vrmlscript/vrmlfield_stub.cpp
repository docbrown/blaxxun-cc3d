/*
 * VrmlField_stub.cpp
 *
 *      Declaration of classes:
 *        VrmlField
 *        VrmlSField
 *        VrmlMField
 *        VrmlEventIn
 *
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 *
 */

#include "VrmlField_stub.h"

VrmlField::VrmlField() { flags.fieldType = 0; flags.hasBeenSet = TRUE; }
VrmlField::~VrmlField() {}
VrmlSField::VrmlSField() {}
VrmlSField::~VrmlSField() {}
VrmlMField::VrmlMField() {}
VrmlMField::~VrmlMField() {}
VrmlEventIn::VrmlEventIn() {}
VrmlEventIn::~VrmlEventIn() {}
