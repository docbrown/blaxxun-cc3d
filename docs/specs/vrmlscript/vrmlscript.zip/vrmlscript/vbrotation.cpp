/*
 * Copyright (C) 1996   Silicon Graphics, Inc.
 *
 _______________________________________________________________________
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 |
 |   $Revision: 1.8 $
 |
 |   Classes:
 |	VbRotation
 |
 |   Author(s)		: Nick Thompson
 |      (for the PC)    : Jim Kent, Daniel Woods
 |
 |   Heavily based on code by Ken Shoemake and code by Gavin Bell
 |
 ______________  S I L I C O N   G R A P H I C S   I N C .  ____________
 _______________________________________________________________________
 */

#include "vblinear.h"

// amount squared to figure if two floats are equal
#define DELTA 1e-6

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Returns 4 individual components of rotation quaternion.
//
// Use: public

void
VbRotation::getValue(float &q0, float &q1, float &q2, float &q3) const
//
////////////////////////////////////////////////////////////////////////
{
    q0 = quat[0];
    q1 = quat[1];
    q2 = quat[2];
    q3 = quat[3];
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Returns corresponding 3D rotation axis vector and angle in radians.
//
// Use: public

void
VbRotation::getValue(VbVec3f &axis, float &radians) const
//
////////////////////////////////////////////////////////////////////////
{
    float	len;
    VbVec3f	q;

    q[0] = quat[0];
    q[1] = quat[1];
    q[2] = quat[2];

    if ((len = q.length()) > 0.00001f) {
	axis	= q * (1.0f / len);
	radians	= (float)(2.0 * acos(quat[3]));
    }

    else {
	axis.setValue(0.0f, 0.0f, 1.0f);
	radians = 0.0f;
    }
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Changes a rotation to be its inverse.
//
// Use: public

VbRotation &
VbRotation::invert()
//
////////////////////////////////////////////////////////////////////////
{
    float invNorm = 1.0f / norm();

    quat[0] = -quat[0] * invNorm;
    quat[1] = -quat[1] * invNorm;
    quat[2] = -quat[2] * invNorm;
    quat[3] =  quat[3] * invNorm;

    return *this;
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Sets value of rotation from array of 4 components of a
//    quaternion.
//
// Use: public

VbRotation &
VbRotation::setValue(const float q[4])
//
////////////////////////////////////////////////////////////////////////
{
    quat[0] = q[0];
    quat[1] = q[1];
    quat[2] = q[2];
    quat[3] = q[3];
    normalize();

    return (*this);
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Sets value of rotation from 4 individual components of a
//    quaternion.
//
// Use: public

VbRotation &
VbRotation::setValue(float q0, float q1, float q2, float q3)
//
////////////////////////////////////////////////////////////////////////
{
    quat[0] = q0;
    quat[1] = q1;
    quat[2] = q2;
    quat[3] = q3;
    normalize();

    return (*this);
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Sets value of rotation from 3D rotation axis vector and angle in
//    radians.
//
// Use: public

VbRotation &
VbRotation::setValue(const VbVec3f &axis, float radians)
//
////////////////////////////////////////////////////////////////////////
{
    VbVec3f	q;

    q = axis;
    q.normalize();

    q *= (float)sin(radians / 2.0f);

    quat[0] = q[0];
    quat[1] = q[1];
    quat[2] = q[2];

    quat[3] = (float)cos(radians / 2.0f);

    return(*this);
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Sets rotation to rotate one direction vector to another.
//
// Use: public

VbRotation &
VbRotation::setValue(const VbVec3f &rotateFrom, const VbVec3f &rotateTo)
//
////////////////////////////////////////////////////////////////////////
{
    VbVec3f	from = rotateFrom;
    VbVec3f	to = rotateTo;
    VbVec3f	axis;
    float	cost;

    from.normalize();
    to.normalize();
    cost = from.dot(to);

    // check for degeneracies
    if (cost > 0.99999f) {		// vectors are parallel
	quat[0] = quat[1] = quat[2] = 0.0f;
	quat[3] = 1.0f;
	return *this;
    }
    else if (cost < -0.99999f) {		// vectors are opposite
	// find an axis to rotate around, which should be
	// perpendicular to the original axis
	// Try cross product with (1,0,0) first, if that's one of our
	// original vectors then try  (0,1,0).
	VbVec3f tmp = from.cross(VbVec3f(1.0f, 0.0f, 0.0f));
	if (tmp.length() < 0.00001f)
	    tmp = from.cross(VbVec3f(0.0f, 1.0f, 0.0f));

	tmp.normalize();
	setValue(tmp[0], tmp[1], tmp[2], 0.0f);
	return *this;
    }

    axis = rotateFrom.cross(rotateTo);
    axis.normalize();

    // use half-angle formulae
    // sin^2 t = ( 1 - cos (2t) ) / 2
    axis *= (float)sqrt(0.5f * (1.0f - cost));

    // scale the axis by the sine of half the rotation angle to get
    // the normalized quaternion
    quat[0] = axis[0];
    quat[1] = axis[1];
    quat[2] = axis[2];

    // cos^2 t = ( 1 + cos (2t) ) / 2
    // w part is cosine of half the rotation angle
    quat[3] = (float)sqrt(0.5f * (1.0f + cost));

    return (*this);
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Multiplies by another rotation.
//
// Use: public

VbRotation &
VbRotation::operator *=(const VbRotation &q)
//
////////////////////////////////////////////////////////////////////////
{
    float p0, p1, p2, p3;

    p0 = (q.quat[3] * quat[0] + q.quat[0] * quat[3] +
	  q.quat[1] * quat[2] - q.quat[2] * quat[1]);
    p1 = (q.quat[3] * quat[1] + q.quat[1] * quat[3] +
	  q.quat[2] * quat[0] - q.quat[0] * quat[2]);
    p2 = (q.quat[3] * quat[2] + q.quat[2] * quat[3] +
	  q.quat[0] * quat[1] - q.quat[1] * quat[0]);
    p3 = (q.quat[3] * quat[3] - q.quat[0] * quat[0] -
	  q.quat[1] * quat[1] - q.quat[2] * quat[2]);
    quat[0] = p0;
    quat[1] = p1;
    quat[2] = p2;
    quat[3] = p3;

    normalize();

    return(*this);
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Equality comparison operator.
//
// Use: public

int
operator ==(const VbRotation &q1, const VbRotation &q2)
//
////////////////////////////////////////////////////////////////////////
{
    return (q1.quat[0] == q2.quat[0] &&
	    q1.quat[1] == q2.quat[1] &&
	    q1.quat[2] == q2.quat[2] &&
	    q1.quat[3] == q2.quat[3]);
}


////////////////////////////////////////////////////////////////////////
//
// Description:
//    Equality comparison operator within given tolerance - the square
//    of the length of the maximum distance between the two vectors.
//
// Use: public

VbBool
VbRotation::equals(const VbRotation &r, float tolerance) const
//
////////////////////////////////////////////////////////////////////////
{
    float sum = 0.0f;
    for (int i = 0; i < 4; i++) {
	float diff = quat[i]-r.quat[i];
	sum += diff*diff;
    }
    return (sum <= tolerance);
}


////////////////////////////////////////////////////////////////////////
//
// Description:
//    Binary multiplication operator.
//
// Use: public

VbRotation
operator *(const VbRotation &q1, const VbRotation &q2)
//
////////////////////////////////////////////////////////////////////////
{
    VbRotation q(q2.quat[3] * q1.quat[0] + q2.quat[0] * q1.quat[3] +
		  q2.quat[1] * q1.quat[2] - q2.quat[2] * q1.quat[1],

		  q2.quat[3] * q1.quat[1] + q2.quat[1] * q1.quat[3] +
		  q2.quat[2] * q1.quat[0] - q2.quat[0] * q1.quat[2],

		  q2.quat[3] * q1.quat[2] + q2.quat[2] * q1.quat[3] +
		  q2.quat[0] * q1.quat[1] - q2.quat[1] * q1.quat[0],

		  q2.quat[3] * q1.quat[3] - q2.quat[0] * q1.quat[0] -
		  q2.quat[1] * q1.quat[1] - q2.quat[2] * q1.quat[2]);
    q.normalize();

    return (q);
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Keep the axis the same. Multiply the angle of rotation by
//    the amount 'scaleFactor'
//
// Use: public

void
VbRotation::scaleAngle(float scaleFactor )
//
////////////////////////////////////////////////////////////////////////
{
    VbVec3f myAxis;
    float   myAngle;

    // Get the Axis and angle.
    getValue( myAxis, myAngle );

    setValue( myAxis, (myAngle * scaleFactor) );
}

//
// 
//
////////////////////////////////////////////////////////////////////////
//
// Description:
//    Spherical linear interpolation: as t goes from 0 to 1, returned
//    value goes from rot0 to rot1.
//
// Use: public

VbRotation
VbRotation::slerp(const VbRotation &rot0, const VbRotation &rot1, float t)
//
////////////////////////////////////////////////////////////////////////
{
        const float*    r1q = rot1.getValue();

        VbRotation      rot;
        float           rot1q[4];
        double          omega, cosom, sinom;
        double          scalerot0, scalerot1;
        int             i;

        // Calculate the cosine
        cosom = rot0.quat[0]*rot1.quat[0] + rot0.quat[1]*rot1.quat[1]
                + rot0.quat[2]*rot1.quat[2] + rot0.quat[3]*rot1.quat[3];

        // adjust signs if necessary
        if ( cosom < 0.0 ) {
                cosom = -cosom;
                for ( int j = 0; j < 4; j++ )
                        rot1q[j] = -r1q[j];
        } else  {
                for ( int j = 0; j < 4; j++ )
                        rot1q[j] = r1q[j];
        }

        // calculate interpolating coeffs
        if ( (1.0 - cosom) > 0.00001 ) {
                // standard case
                omega = acos(cosom);
                sinom = sin(omega);
                scalerot0 = sin((1.0 - t) * omega) / sinom;
                scalerot1 = sin(t * omega) / sinom;
        } else {        
                // rot0 and rot1 very close - just do linear interp.
                scalerot0 = 1.0 - t;
                scalerot1 = t;
        }

        // build the new quarternion
        for (i = 0; i <4; i++)
                rot.quat[i] = (float)(scalerot0 * rot0.quat[i] + scalerot1 * rot1q[i]);

        return rot;
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Returns the norm (square of the 4D length) of the quaternion
//    defining the rotation.
//
// Use: private

float
VbRotation::norm() const
//
////////////////////////////////////////////////////////////////////////
{
    return (quat[0] * quat[0] +
	    quat[1] * quat[1] +
	    quat[2] * quat[2] +
	    quat[3] * quat[3]);
}

////////////////////////////////////////////////////////////////////////
//
// Description:
//    Normalizes a rotation quaternion to unit 4D length.
//
// Use: private

void
VbRotation::normalize()
//
////////////////////////////////////////////////////////////////////////
{
    float	dist = (float)(1.0 / sqrt(norm()));

    quat[0] *= dist;
    quat[1] *= dist;
    quat[2] *= dist;
    quat[3] *= dist;
}


