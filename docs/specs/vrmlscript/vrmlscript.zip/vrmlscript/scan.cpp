# include "stdio.h"
# define U(x) ((unsigned char)(x))
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 2048
# define output(c) (void)putc(c,yyout)
#if defined(__cplusplus) || defined(__STDC__)

#ifdef __cplusplus
extern "C" {
#endif
	int yylex(void);
	int yyback(int *, int);
	int yyinput(void);
	int yylook(void);
	void yyoutput(int);
	int yyracc(int);
	int yyreject(void);
	void yyunput(int);
#ifndef yyless
	void yyless(long int);
#endif
#ifndef yywrap
	int yywrap(void);
#endif
#ifdef __cplusplus
}
#endif

#endif

# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO (void)fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;

/* 
 *	Vs Lexical Analyzer (scanner)
 */

#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#undef input
#undef unput

#include "vsexpr.h"
#include "vsfunction.h"
#include "vsstatement.h"
#include "vsparse.h"

#include "y.tab.h"

// Lex and YACC are hard-coded for these routine names:
#define input() VsParseTree::input()
#define unput(_char) VsParseTree::unput(_char)
#define yyerror(_error) VsParseTree::yyerror(_error)

static int curStringLength = 0;


/* debugging macros */

int lldebug = 0;

#ifdef _DEBUG
#define RET(x)	{ \
		    if (lldebug) printf("lex %hu [%s]\n", (int) x, yytext); \
		    return(x); \
		}
#else
#define RET(x)	return(x)
#endif


/* forward references defined in this module */
void skipSlashStarComments(void);
char *getStringConstant(char delimiter);

# define YYNEWLINE 10
yylex(void){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
/*yyfussy:*/ switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:

		{ ; }
break;
case 2:

{ skipSlashStarComments(); }
break;
case 3:

{ while (input() != '\n'); }
break;
case 4:

	{
/* single and double quote enclosed string constants */
		    char *string = getStringConstant('\"');

		    yylval.string = string;

		    RET(tSTRING);
		}
break;
case 5:

	{
/* single and double quote enclosed string constants */
		    char *string = getStringConstant('\'');

		    yylval.string = string;

		    RET(tSTRING);
		}
break;
case 6:

	    { yylval.number = strtol(yytext, NULL, 0); RET(tNUMBER); }
break;
case 7:

    { yylval.number = strtol(yytext, NULL, 0); RET(tNUMBER); }
break;
case 8:

 { yylval.number = atof(yytext); RET(tNUMBER); }
break;
case 9:

	    { RET(tCOMMA); }
break;
case 10:

	    { RET(tGT); }
break;
case 11:

	    { RET(tGE); }
break;
case 12:

	    { RET(tEQ); }
break;
case 13:

	    { RET(tLT); }
break;
case 14:

	    { RET(tLE); }
break;
case 15:

	    { RET(tNE); }
break;
case 16:

	    { RET(tRSHIFT); }
break;
case 17:

	    { RET(tLSHIFT); }
break;
case 18:

	    { RET(tRSHIFTFILL); }
break;
case 19:

	    { RET(tLAND); }
break;
case 20:

	    { RET(tLOR); }
break;
case 21:

	    { RET(tASSIGN); }
break;
case 22:

	    { RET(tOR); }
break;
case 23:

	    { RET(tAND); }
break;
case 24:

	    { RET(tXOR); }
break;
case 25:

	    { RET(tPLUS); }
break;
case 26:

	    { RET(tMINUS); }
break;
case 27:

	    { RET(tMULTIPLY); }
break;
case 28:

	    { RET(tDIVIDE); }
break;
case 29:

	    { RET(tMOD); }
break;
case 30:

	    { RET(tNOT); }
break;
case 31:

	    { RET(tDOT); }
break;
case 32:

	    { RET(tRIGHTBRACKET); }
break;
case 33:

	    { RET(tLEFTBRACKET); }
break;
case 34:

	    { RET(tPLUSEQ); }
break;
case 35:

	    { RET(tMINUSEQ); }
break;
case 36:

	    { RET(tMULTIPLYEQ); }
break;
case 37:

	    { RET(tDIVIDEEQ); }
break;
case 38:

	    { RET(tMODEQ); }
break;
case 39:

	    { RET(tLSHIFTEQ); }
break;
case 40:

	    { RET(tRSHIFTEQ); }
break;
case 41:

	    { RET(tRSHIFTFILLEQ); }
break;
case 42:

	    { RET(tANDEQ); }
break;
case 43:

	    { RET(tXOREQ); }
break;
case 44:

	    { RET(tOREQ); }
break;
case 45:

	    { RET(tCONDTEST); }
break;
case 46:

	    { RET(tCONDSEP); }
break;
case 47:

	    { RET(tONESCOMP); }
break;
case 48:

	    { RET(tINCREMENT); }
break;
case 49:

	    { RET(tDECREMENT); }
break;
case 50:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 51:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 52:

	    { RET(tBREAK); }
break;
case 53:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 54:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 55:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 56:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 57:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 58:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 59:

	    { RET(tCONTINUE); }
break;
case 60:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 61:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 62:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 63:

	    { RET(tELSE); }
break;
case 64:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 65:

	    { yylval.number = 0.0; RET(tNUMBER); }
break;
case 66:

	    { yylval.number = 0.0; RET(tNUMBER); }
break;
case 67:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 68:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 69:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 70:

	    { RET(tFOR); }
break;
case 71:

	    { RET(tFUNCTION); }
break;
case 72:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 73:

	    { RET(tIF); }
break;
case 74:

    { RET(tUNIMPL_KEYWORD); }
break;
case 75:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 76:

	    { RET(tIN); }
break;
case 77:

    { RET(tUNIMPL_KEYWORD); }
break;
case 78:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 79:

    { RET(tUNIMPL_KEYWORD); }
break;
case 80:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 81:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 82:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 83:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 84:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 85:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 86:

    { RET(tUNIMPL_KEYWORD); }
break;
case 87:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 88:

	    { RET(tRETURN); }
break;
case 89:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 90:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 91:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 92:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 93:

    { RET(tUNIMPL_KEYWORD); }
break;
case 94:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 95:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 96:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 97:

    { RET(tUNIMPL_KEYWORD); }
break;
case 98:

	    { yylval.number = 1.0; RET(tNUMBER); }
break;
case 99:

	    { yylval.number = 1.0; RET(tNUMBER); }
break;
case 100:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 101:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 102:

	    { RET(tUNIMPL_KEYWORD); }
break;
case 103:

	    { RET(tWHILE); }
break;
case 104:

	    { RET(tWITH); }
break;
case 105:

{ yylval.string = strdup(yytext); RET(tIDENTIFIER); }
break;
case 106:

	RET (yytext[0]);
break;
case -1:
break;
default:
(void)fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */


/* 
 *   Skip comments enclosed in slash-star ... star-slash pairs
 */

static void skipSlashStarComments(void)

{
    char cChar;

    for ( ; ; )
    {
	while ((cChar = input()) != '*') ;
	if (input() != '/') 
	{
	    unput(yytext[yyleng-1]);
	}
	else return;
    }
}

static char *getStringConstant(char delimiter)
{
    // READ IN A STRING CONSTANT
    // THIS GOES "OUTSIDE" OF THE LEXER SINCE NO RULES
    // SHOULD FIRE UNTIL CLOSING delimiter IS READ
    // read in the string until the matching delimiter
    int len = 0;
    int maxlen = 64;
    char cChar;
    char *startChar = new char[maxlen];
    while ((cChar = input()) != delimiter) { 
	if (len == maxlen) {
	    char* tmpStr = new char[2*maxlen];

	    for (int i=0; i<maxlen; i++) {
		tmpStr[i] = startChar[i];
	    }
	    maxlen *= 2;
	    delete startChar;
	    startChar = tmpStr;
	}
	startChar[len++] = cChar;
    }
    startChar[len] = '\0';

    return startChar;
}

int yyvstop[] = {
0,

106,
0,

1,
106,
0,

1,
0,

30,
106,
0,

4,
106,
0,

29,
106,
0,

23,
106,
0,

5,
106,
0,

27,
106,
0,

25,
106,
0,

9,
106,
0,

26,
106,
0,

31,
106,
0,

28,
106,
0,

6,
8,
106,
0,

8,
106,
0,

46,
106,
0,

13,
106,
0,

21,
106,
0,

10,
106,
0,

45,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

32,
106,
0,

33,
106,
0,

24,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

105,
106,
0,

22,
106,
0,

47,
106,
0,

15,
0,

38,
0,

19,
0,

42,
0,

36,
0,

48,
0,

34,
0,

49,
0,

35,
0,

8,
0,

2,
0,

3,
0,

37,
0,

8,
0,

6,
8,
0,

8,
0,

17,
0,

14,
0,

12,
0,

11,
0,

16,
0,

105,
0,

105,
0,

105,
0,

43,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

61,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

73,
105,
0,

105,
0,

76,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

44,
0,

20,
0,

8,
0,

7,
0,

39,
0,

40,
0,

18,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

70,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

78,
105,
0,

105,
0,

105,
0,

82,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

100,
105,
0,

101,
105,
0,

105,
0,

105,
0,

105,
0,

41,
0,

105,
0,

99,
105,
0,

105,
0,

105,
0,

105,
0,

53,
105,
0,

54,
105,
0,

105,
0,

56,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

63,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

72,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

80,
105,
0,

105,
0,

83,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

94,
105,
0,

105,
0,

105,
0,

98,
105,
0,

102,
105,
0,

105,
0,

104,
105,
0,

66,
105,
0,

105,
0,

105,
0,

52,
105,
0,

55,
105,
0,

57,
105,
0,

58,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

65,
105,
0,

67,
105,
0,

69,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

89,
105,
0,

105,
0,

91,
105,
0,

105,
0,

105,
0,

95,
105,
0,

105,
0,

103,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

62,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

75,
105,
0,

105,
0,

105,
0,

81,
105,
0,

105,
0,

105,
0,

105,
0,

87,
105,
0,

88,
105,
0,

90,
105,
0,

92,
105,
0,

105,
0,

96,
105,
0,

105,
0,

105,
0,

51,
105,
0,

105,
0,

60,
105,
0,

64,
105,
0,

68,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

84,
105,
0,

85,
105,
0,

105,
0,

105,
0,

105,
0,

50,
105,
0,

59,
105,
0,

71,
105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

105,
0,

79,
105,
0,

86,
105,
0,

105,
0,

97,
105,
0,

74,
105,
0,

77,
105,
0,

105,
0,

105,
0,

93,
105,
0,
0};
# define YYTYPE int
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,4,	1,5,	
0,0,	4,5,	4,5,	0,0,	
4,5,	4,5,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,6,	1,7,	
4,5,	0,0,	1,8,	1,9,	
1,10,	0,0,	0,0,	1,11,	
1,12,	1,13,	1,14,	1,15,	
1,16,	1,17,	1,18,	1,18,	
1,18,	1,18,	1,18,	1,18,	
1,18,	1,18,	9,50,	1,19,	
12,53,	1,20,	1,21,	1,22,	
1,23,	6,48,	1,24,	8,49,	
11,52,	21,68,	1,24,	1,25,	
1,24,	25,72,	14,55,	20,66,	
20,67,	16,58,	12,54,	22,69,	
22,70,	9,51,	16,59,	26,73,	
29,74,	1,26,	66,120,	72,123,	
46,115,	1,24,	14,56,	73,124,	
1,27,	0,0,	1,28,	1,29,	
16,60,	0,0,	1,30,	1,31,	
1,32,	1,33,	1,34,	1,35,	
1,36,	30,75,	1,37,	41,103,	
33,83,	1,38,	34,85,	1,39,	
77,127,	1,40,	36,92,	1,41,	
1,42,	1,43,	33,84,	1,44,	
1,45,	31,76,	34,86,	38,96,	
31,77,	1,46,	43,109,	1,47,	
2,6,	2,7,	75,125,	31,78,	
2,8,	2,9,	2,10,	76,126,	
43,110,	2,11,	78,128,	2,13,	
2,14,	2,15,	2,16,	80,131,	
2,18,	2,18,	2,18,	2,18,	
2,18,	2,18,	2,18,	46,116,	
37,93,	2,19,	81,132,	2,20,	
2,21,	2,22,	2,23,	37,94,	
37,95,	45,113,	45,114,	44,111,	
82,133,	2,25,	15,57,	15,57,	
15,57,	15,57,	15,57,	15,57,	
15,57,	15,57,	15,57,	15,57,	
32,79,	44,112,	83,134,	2,26,	
57,64,	39,97,	40,100,	32,80,	
84,135,	39,98,	2,27,	32,81,	
2,28,	2,29,	32,82,	85,136,	
2,30,	2,31,	2,32,	2,33,	
2,34,	2,35,	2,36,	40,101,	
2,37,	39,99,	40,102,	2,38,	
86,137,	2,39,	87,138,	2,40,	
88,139,	2,41,	2,42,	2,43,	
57,64,	2,44,	2,45,	70,121,	
70,122,	79,129,	79,130,	2,46,	
17,61,	2,47,	17,62,	17,62,	
17,62,	17,62,	17,62,	17,62,	
17,62,	17,62,	17,63,	17,63,	
62,62,	62,62,	62,62,	62,62,	
62,62,	62,62,	62,62,	62,62,	
89,140,	90,141,	18,61,	17,64,	
18,63,	18,63,	18,63,	18,63,	
18,63,	18,63,	18,63,	18,63,	
18,63,	18,63,	91,142,	92,143,	
35,87,	94,144,	95,145,	95,146,	
96,147,	97,148,	17,65,	98,149,	
35,88,	18,64,	99,150,	35,89,	
100,151,	102,154,	35,90,	101,152,	
103,155,	104,156,	105,157,	17,64,	
35,91,	101,153,	106,158,	107,159,	
108,160,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	111,166,	
112,167,	113,168,	17,65,	114,169,	
122,170,	18,64,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
123,171,	124,172,	125,173,	126,174,	
24,71,	127,175,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
24,71,	24,71,	24,71,	24,71,	
42,104,	61,61,	61,61,	61,61,	
61,61,	61,61,	61,61,	61,61,	
61,61,	61,61,	61,61,	128,176,	
42,105,	42,106,	129,177,	42,107,	
130,178,	42,108,	64,117,	131,179,	
64,117,	132,180,	61,64,	64,118,	
64,118,	64,118,	64,118,	64,118,	
64,118,	64,118,	64,118,	64,118,	
64,118,	133,181,	133,182,	134,183,	
135,184,	136,185,	65,119,	65,119,	
65,119,	65,119,	65,119,	65,119,	
65,119,	65,119,	65,119,	65,119,	
110,163,	137,186,	138,187,	139,188,	
109,161,	140,189,	61,64,	65,119,	
65,119,	65,119,	65,119,	65,119,	
65,119,	109,162,	142,190,	143,191,	
144,192,	145,194,	146,195,	144,193,	
110,164,	147,196,	148,197,	150,198,	
110,165,	117,118,	117,118,	117,118,	
117,118,	117,118,	117,118,	117,118,	
117,118,	117,118,	117,118,	151,199,	
152,200,	153,201,	154,202,	65,119,	
65,119,	65,119,	65,119,	65,119,	
65,119,	155,203,	156,204,	157,205,	
158,206,	159,207,	160,208,	161,209,	
162,210,	163,211,	164,212,	167,213,	
168,214,	169,215,	171,216,	173,217,	
174,218,	175,219,	178,220,	180,221,	
181,222,	182,223,	183,224,	184,225,	
186,226,	187,227,	188,228,	189,229,	
190,230,	192,231,	193,232,	194,233,	
195,234,	197,235,	199,236,	200,237,	
201,238,	202,239,	203,240,	204,241,	
205,242,	206,243,	207,244,	208,245,	
210,246,	211,247,	214,248,	217,249,	
218,250,	223,251,	224,252,	225,253,	
226,254,	228,255,	230,256,	231,257,	
232,258,	233,259,	234,260,	235,261,	
236,262,	237,263,	238,264,	239,265,	
240,266,	242,267,	244,268,	245,269,	
246,270,	247,271,	249,272,	250,273,	
251,274,	252,275,	254,276,	255,277,	
256,278,	257,279,	259,280,	260,281,	
262,282,	263,283,	264,284,	269,285,	
271,286,	272,287,	274,288,	278,289,	
279,290,	280,291,	281,292,	284,293,	
285,294,	286,295,	290,296,	291,297,	
292,298,	293,299,	294,300,	295,301,	
296,302,	297,303,	300,304,	304,305,	
305,306,	0,0,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-95,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+4,	0,		yyvstop+3,
yycrank+0,	yysvec+4,	yyvstop+6,
yycrank+4,	0,		yyvstop+8,
yycrank+0,	0,		yyvstop+11,
yycrank+6,	0,		yyvstop+14,
yycrank+20,	0,		yyvstop+17,
yycrank+0,	0,		yyvstop+20,
yycrank+7,	0,		yyvstop+23,
yycrank+17,	0,		yyvstop+26,
yycrank+0,	0,		yyvstop+29,
yycrank+29,	0,		yyvstop+32,
yycrank+118,	0,		yyvstop+35,
yycrank+35,	0,		yyvstop+38,
yycrank+174,	0,		yyvstop+41,
yycrank+196,	0,		yyvstop+45,
yycrank+0,	0,		yyvstop+48,
yycrank+15,	0,		yyvstop+51,
yycrank+8,	0,		yyvstop+54,
yycrank+18,	0,		yyvstop+57,
yycrank+0,	0,		yyvstop+60,
yycrank+233,	0,		yyvstop+63,
yycrank+8,	yysvec+24,	yyvstop+66,
yycrank+1,	yysvec+24,	yyvstop+69,
yycrank+0,	0,		yyvstop+72,
yycrank+0,	0,		yyvstop+75,
yycrank+23,	0,		yyvstop+78,
yycrank+7,	yysvec+24,	yyvstop+81,
yycrank+10,	yysvec+24,	yyvstop+84,
yycrank+79,	yysvec+24,	yyvstop+87,
yycrank+7,	yysvec+24,	yyvstop+90,
yycrank+2,	yysvec+24,	yyvstop+93,
yycrank+159,	yysvec+24,	yyvstop+96,
yycrank+3,	yysvec+24,	yyvstop+99,
yycrank+50,	yysvec+24,	yyvstop+102,
yycrank+12,	yysvec+24,	yyvstop+105,
yycrank+84,	yysvec+24,	yyvstop+108,
yycrank+85,	yysvec+24,	yyvstop+111,
yycrank+6,	yysvec+24,	yyvstop+114,
yycrank+252,	yysvec+24,	yyvstop+117,
yycrank+22,	yysvec+24,	yyvstop+120,
yycrank+66,	yysvec+24,	yyvstop+123,
yycrank+57,	yysvec+24,	yyvstop+126,
yycrank+27,	0,		yyvstop+129,
yycrank+0,	0,		yyvstop+132,
yycrank+0,	0,		yyvstop+135,
yycrank+0,	0,		yyvstop+137,
yycrank+0,	0,		yyvstop+139,
yycrank+0,	0,		yyvstop+141,
yycrank+0,	0,		yyvstop+143,
yycrank+0,	0,		yyvstop+145,
yycrank+0,	0,		yyvstop+147,
yycrank+0,	0,		yyvstop+149,
yycrank+0,	0,		yyvstop+151,
yycrank+111,	yysvec+15,	yyvstop+153,
yycrank+0,	0,		yyvstop+155,
yycrank+0,	0,		yyvstop+157,
yycrank+0,	0,		yyvstop+159,
yycrank+309,	0,		yyvstop+161,
yycrank+184,	yysvec+18,	yyvstop+163,
yycrank+0,	yysvec+18,	yyvstop+166,
yycrank+331,	0,		0,	
yycrank+346,	0,		0,	
yycrank+25,	0,		yyvstop+168,
yycrank+0,	0,		yyvstop+170,
yycrank+0,	0,		yyvstop+172,
yycrank+0,	0,		yyvstop+174,
yycrank+154,	0,		yyvstop+176,
yycrank+0,	yysvec+24,	yyvstop+178,
yycrank+11,	yysvec+24,	yyvstop+180,
yycrank+6,	yysvec+24,	yyvstop+182,
yycrank+0,	0,		yyvstop+184,
yycrank+15,	yysvec+24,	yyvstop+186,
yycrank+24,	yysvec+24,	yyvstop+188,
yycrank+11,	yysvec+24,	yyvstop+190,
yycrank+22,	yysvec+24,	yyvstop+192,
yycrank+102,	yysvec+24,	yyvstop+194,
yycrank+46,	yysvec+24,	yyvstop+196,
yycrank+57,	yysvec+24,	yyvstop+198,
yycrank+54,	yysvec+24,	yyvstop+200,
yycrank+76,	yysvec+24,	yyvstop+202,
yycrank+67,	yysvec+24,	yyvstop+204,
yycrank+76,	yysvec+24,	yyvstop+207,
yycrank+88,	yysvec+24,	yyvstop+209,
yycrank+98,	yysvec+24,	yyvstop+211,
yycrank+98,	yysvec+24,	yyvstop+213,
yycrank+129,	yysvec+24,	yyvstop+215,
yycrank+127,	yysvec+24,	yyvstop+217,
yycrank+144,	yysvec+24,	yyvstop+219,
yycrank+139,	yysvec+24,	yyvstop+221,
yycrank+0,	yysvec+24,	yyvstop+223,
yycrank+145,	yysvec+24,	yyvstop+226,
yycrank+143,	yysvec+24,	yyvstop+228,
yycrank+150,	yysvec+24,	yyvstop+231,
yycrank+145,	yysvec+24,	yyvstop+233,
yycrank+144,	yysvec+24,	yyvstop+235,
yycrank+158,	yysvec+24,	yyvstop+237,
yycrank+169,	yysvec+24,	yyvstop+239,
yycrank+166,	yysvec+24,	yyvstop+241,
yycrank+171,	yysvec+24,	yyvstop+243,
yycrank+156,	yysvec+24,	yyvstop+245,
yycrank+162,	yysvec+24,	yyvstop+247,
yycrank+177,	yysvec+24,	yyvstop+249,
yycrank+166,	yysvec+24,	yyvstop+251,
yycrank+174,	yysvec+24,	yyvstop+253,
yycrank+170,	yysvec+24,	yyvstop+255,
yycrank+303,	yysvec+24,	yyvstop+257,
yycrank+307,	yysvec+24,	yyvstop+259,
yycrank+177,	yysvec+24,	yyvstop+261,
yycrank+187,	yysvec+24,	yyvstop+263,
yycrank+188,	yysvec+24,	yyvstop+265,
yycrank+179,	yysvec+24,	yyvstop+267,
yycrank+0,	0,		yyvstop+269,
yycrank+0,	0,		yyvstop+271,
yycrank+381,	0,		0,	
yycrank+0,	yysvec+117,	yyvstop+273,
yycrank+0,	yysvec+65,	yyvstop+275,
yycrank+0,	0,		yyvstop+277,
yycrank+0,	0,		yyvstop+279,
yycrank+235,	0,		yyvstop+281,
yycrank+241,	yysvec+24,	yyvstop+283,
yycrank+256,	yysvec+24,	yyvstop+285,
yycrank+210,	yysvec+24,	yyvstop+287,
yycrank+219,	yysvec+24,	yyvstop+289,
yycrank+232,	yysvec+24,	yyvstop+291,
yycrank+266,	yysvec+24,	yyvstop+293,
yycrank+269,	yysvec+24,	yyvstop+295,
yycrank+273,	yysvec+24,	yyvstop+297,
yycrank+261,	yysvec+24,	yyvstop+299,
yycrank+262,	yysvec+24,	yyvstop+301,
yycrank+274,	yysvec+24,	yyvstop+303,
yycrank+294,	yysvec+24,	yyvstop+305,
yycrank+294,	yysvec+24,	yyvstop+307,
yycrank+292,	yysvec+24,	yyvstop+309,
yycrank+304,	yysvec+24,	yyvstop+311,
yycrank+291,	yysvec+24,	yyvstop+313,
yycrank+310,	yysvec+24,	yyvstop+315,
yycrank+312,	yysvec+24,	yyvstop+317,
yycrank+0,	yysvec+24,	yyvstop+319,
yycrank+319,	yysvec+24,	yyvstop+322,
yycrank+308,	yysvec+24,	yyvstop+324,
yycrank+312,	yysvec+24,	yyvstop+326,
yycrank+305,	yysvec+24,	yyvstop+328,
yycrank+321,	yysvec+24,	yyvstop+330,
yycrank+322,	yysvec+24,	yyvstop+333,
yycrank+321,	yysvec+24,	yyvstop+335,
yycrank+0,	yysvec+24,	yyvstop+337,
yycrank+319,	yysvec+24,	yyvstop+340,
yycrank+332,	yysvec+24,	yyvstop+342,
yycrank+322,	yysvec+24,	yyvstop+344,
yycrank+325,	yysvec+24,	yyvstop+346,
yycrank+334,	yysvec+24,	yyvstop+348,
yycrank+332,	yysvec+24,	yyvstop+350,
yycrank+336,	yysvec+24,	yyvstop+352,
yycrank+335,	yysvec+24,	yyvstop+354,
yycrank+351,	yysvec+24,	yyvstop+356,
yycrank+337,	yysvec+24,	yyvstop+358,
yycrank+355,	yysvec+24,	yyvstop+360,
yycrank+340,	yysvec+24,	yyvstop+362,
yycrank+345,	yysvec+24,	yyvstop+364,
yycrank+347,	yysvec+24,	yyvstop+366,
yycrank+357,	yysvec+24,	yyvstop+368,
yycrank+0,	yysvec+24,	yyvstop+370,
yycrank+0,	yysvec+24,	yyvstop+373,
yycrank+359,	yysvec+24,	yyvstop+376,
yycrank+352,	yysvec+24,	yyvstop+378,
yycrank+357,	yysvec+24,	yyvstop+380,
yycrank+0,	0,		yyvstop+382,
yycrank+393,	yysvec+24,	yyvstop+384,
yycrank+0,	yysvec+24,	yyvstop+386,
yycrank+349,	yysvec+24,	yyvstop+389,
yycrank+363,	yysvec+24,	yyvstop+391,
yycrank+358,	yysvec+24,	yyvstop+393,
yycrank+0,	yysvec+24,	yyvstop+395,
yycrank+0,	yysvec+24,	yyvstop+398,
yycrank+362,	yysvec+24,	yyvstop+401,
yycrank+0,	yysvec+24,	yyvstop+403,
yycrank+352,	yysvec+24,	yyvstop+406,
yycrank+352,	yysvec+24,	yyvstop+408,
yycrank+364,	yysvec+24,	yyvstop+410,
yycrank+353,	yysvec+24,	yyvstop+412,
yycrank+363,	yysvec+24,	yyvstop+414,
yycrank+0,	yysvec+24,	yyvstop+416,
yycrank+362,	yysvec+24,	yyvstop+419,
yycrank+372,	yysvec+24,	yyvstop+421,
yycrank+366,	yysvec+24,	yyvstop+423,
yycrank+359,	yysvec+24,	yyvstop+425,
yycrank+360,	yysvec+24,	yyvstop+427,
yycrank+0,	yysvec+24,	yyvstop+429,
yycrank+376,	yysvec+24,	yyvstop+432,
yycrank+364,	yysvec+24,	yyvstop+434,
yycrank+382,	yysvec+24,	yyvstop+436,
yycrank+366,	yysvec+24,	yyvstop+438,
yycrank+0,	yysvec+24,	yyvstop+440,
yycrank+363,	yysvec+24,	yyvstop+443,
yycrank+0,	yysvec+24,	yyvstop+445,
yycrank+385,	yysvec+24,	yyvstop+448,
yycrank+386,	yysvec+24,	yyvstop+450,
yycrank+383,	yysvec+24,	yyvstop+452,
yycrank+380,	yysvec+24,	yyvstop+454,
yycrank+372,	yysvec+24,	yyvstop+456,
yycrank+371,	yysvec+24,	yyvstop+458,
yycrank+383,	yysvec+24,	yyvstop+460,
yycrank+375,	yysvec+24,	yyvstop+462,
yycrank+391,	yysvec+24,	yyvstop+464,
yycrank+387,	yysvec+24,	yyvstop+466,
yycrank+0,	yysvec+24,	yyvstop+468,
yycrank+373,	yysvec+24,	yyvstop+471,
yycrank+378,	yysvec+24,	yyvstop+473,
yycrank+0,	yysvec+24,	yyvstop+475,
yycrank+0,	yysvec+24,	yyvstop+478,
yycrank+393,	yysvec+24,	yyvstop+481,
yycrank+0,	yysvec+24,	yyvstop+483,
yycrank+0,	yysvec+24,	yyvstop+486,
yycrank+398,	yysvec+24,	yyvstop+489,
yycrank+399,	yysvec+24,	yyvstop+491,
yycrank+0,	yysvec+24,	yyvstop+493,
yycrank+0,	yysvec+24,	yyvstop+496,
yycrank+0,	yysvec+24,	yyvstop+499,
yycrank+0,	yysvec+24,	yyvstop+502,
yycrank+387,	yysvec+24,	yyvstop+505,
yycrank+390,	yysvec+24,	yyvstop+507,
yycrank+398,	yysvec+24,	yyvstop+509,
yycrank+400,	yysvec+24,	yyvstop+511,
yycrank+0,	yysvec+24,	yyvstop+513,
yycrank+393,	yysvec+24,	yyvstop+516,
yycrank+0,	yysvec+24,	yyvstop+519,
yycrank+397,	yysvec+24,	yyvstop+522,
yycrank+394,	yysvec+24,	yyvstop+524,
yycrank+388,	yysvec+24,	yyvstop+526,
yycrank+395,	yysvec+24,	yyvstop+528,
yycrank+404,	yysvec+24,	yyvstop+530,
yycrank+406,	yysvec+24,	yyvstop+532,
yycrank+405,	yysvec+24,	yyvstop+534,
yycrank+393,	yysvec+24,	yyvstop+536,
yycrank+411,	yysvec+24,	yyvstop+538,
yycrank+412,	yysvec+24,	yyvstop+540,
yycrank+402,	yysvec+24,	yyvstop+542,
yycrank+0,	yysvec+24,	yyvstop+544,
yycrank+414,	yysvec+24,	yyvstop+547,
yycrank+0,	yysvec+24,	yyvstop+549,
yycrank+410,	yysvec+24,	yyvstop+552,
yycrank+401,	yysvec+24,	yyvstop+554,
yycrank+401,	yysvec+24,	yyvstop+556,
yycrank+412,	yysvec+24,	yyvstop+559,
yycrank+0,	yysvec+24,	yyvstop+561,
yycrank+419,	yysvec+24,	yyvstop+564,
yycrank+409,	yysvec+24,	yyvstop+566,
yycrank+403,	yysvec+24,	yyvstop+568,
yycrank+405,	yysvec+24,	yyvstop+570,
yycrank+0,	yysvec+24,	yyvstop+572,
yycrank+407,	yysvec+24,	yyvstop+575,
yycrank+402,	yysvec+24,	yyvstop+577,
yycrank+413,	yysvec+24,	yyvstop+579,
yycrank+424,	yysvec+24,	yyvstop+581,
yycrank+0,	yysvec+24,	yyvstop+583,
yycrank+427,	yysvec+24,	yyvstop+586,
yycrank+430,	yysvec+24,	yyvstop+588,
yycrank+0,	yysvec+24,	yyvstop+590,
yycrank+427,	yysvec+24,	yyvstop+593,
yycrank+428,	yysvec+24,	yyvstop+595,
yycrank+414,	yysvec+24,	yyvstop+597,
yycrank+0,	yysvec+24,	yyvstop+599,
yycrank+0,	yysvec+24,	yyvstop+602,
yycrank+0,	yysvec+24,	yyvstop+605,
yycrank+0,	yysvec+24,	yyvstop+608,
yycrank+420,	yysvec+24,	yyvstop+611,
yycrank+0,	yysvec+24,	yyvstop+613,
yycrank+431,	yysvec+24,	yyvstop+616,
yycrank+417,	yysvec+24,	yyvstop+618,
yycrank+0,	yysvec+24,	yyvstop+620,
yycrank+433,	yysvec+24,	yyvstop+623,
yycrank+0,	yysvec+24,	yyvstop+625,
yycrank+0,	yysvec+24,	yyvstop+628,
yycrank+0,	yysvec+24,	yyvstop+631,
yycrank+425,	yysvec+24,	yyvstop+634,
yycrank+426,	yysvec+24,	yyvstop+636,
yycrank+436,	yysvec+24,	yyvstop+638,
yycrank+439,	yysvec+24,	yyvstop+640,
yycrank+0,	yysvec+24,	yyvstop+642,
yycrank+0,	yysvec+24,	yyvstop+645,
yycrank+438,	yysvec+24,	yyvstop+648,
yycrank+430,	yysvec+24,	yyvstop+650,
yycrank+431,	yysvec+24,	yyvstop+652,
yycrank+0,	yysvec+24,	yyvstop+654,
yycrank+0,	yysvec+24,	yyvstop+657,
yycrank+0,	yysvec+24,	yyvstop+660,
yycrank+426,	yysvec+24,	yyvstop+663,
yycrank+432,	yysvec+24,	yyvstop+665,
yycrank+443,	yysvec+24,	yyvstop+667,
yycrank+445,	yysvec+24,	yyvstop+669,
yycrank+441,	yysvec+24,	yyvstop+671,
yycrank+431,	yysvec+24,	yyvstop+673,
yycrank+433,	yysvec+24,	yyvstop+675,
yycrank+447,	yysvec+24,	yyvstop+677,
yycrank+0,	yysvec+24,	yyvstop+679,
yycrank+0,	yysvec+24,	yyvstop+682,
yycrank+428,	yysvec+24,	yyvstop+685,
yycrank+0,	yysvec+24,	yyvstop+687,
yycrank+0,	yysvec+24,	yyvstop+690,
yycrank+0,	yysvec+24,	yyvstop+693,
yycrank+450,	yysvec+24,	yyvstop+696,
yycrank+452,	yysvec+24,	yyvstop+698,
yycrank+0,	yysvec+24,	yyvstop+700,
0,	0,	0};
struct yywork *yytop = yycrank+552;
struct yysvf *yybgin = yysvec+1;
unsigned char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,011 ,011 ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,'+' ,01  ,'+' ,01  ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'8' ,'8' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'E' ,'A' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'X' ,'G' ,'G' ,01  ,01  ,01  ,01  ,'G' ,
01  ,'A' ,'A' ,'A' ,'A' ,'E' ,'A' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'X' ,'G' ,'G' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
#ident	"$Revision: 1.14 $"

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
#if defined(__cplusplus) || defined(__STDC__)
int yylook(void)
#else
yylook()
#endif
{
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
#ifndef LONGLINES
			if(yylastch > &yytext[YYLMAX]) {
				fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
				exit(1);
			}
#endif
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (void *)yyt > (void *)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
#ifndef LONGLINES
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
#endif
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((void *)yyt < (void *)yycrank) {	/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
#ifndef LONGLINES
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
#endif
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
#ifndef LONGLINES
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
#endif
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = (int)(yylastch-yytext+1);
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
#if defined(__cplusplus) || defined(__STDC__)
int yyback(int *p, int m)
#else
yyback(p, m)
	int *p;
#endif
{
	if (p==0) return(0);
	while (*p) {
		if (*p++ == m)
			return(1);
	}
	return(0);
}
	/* the following are only used in the lex library */
#if defined(__cplusplus) || defined(__STDC__)
int yyinput(void)
#else
yyinput()
#endif
{
	return(input());
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyoutput(int c)
#else
yyoutput(c)
  int c; 
#endif
{
	output(c);
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyunput(int c)
#else
yyunput(c)
   int c; 
#endif
{
	unput(c);
	}
