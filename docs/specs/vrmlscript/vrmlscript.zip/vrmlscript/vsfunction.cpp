/*
 * VsFunction.c++
 *
 *     Implementation of classes:
 *        VsFunctionDef
 *        VsFunctionCall
 *	  VsMethodCall
 *	  VsMemberAccess
 *
 * Copyright (C) 1996, Silicon Graphics,  Inc.
 */

#include <assert.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "vsfunction.h"
#include "vsstatement.h"
#include "vsparse.h"
#include "jsmath.h"

#ifdef __sgi
double JsMath::E       = M_E;
double JsMath::LN10    = M_LN10;
double JsMath::LN2     = M_LN2;
double JsMath::PI      = M_PI;
double JsMath::SQRT1_2 = M_SQRT1_2;
double JsMath::SQRT2   = M_SQRT2;
#else
double JsMath::E       = 2.7182818284590452354;
double JsMath::LN10    = 2.30258509299404568402;
double JsMath::LN2     = 0.69314718055994530942;
double JsMath::PI      = 3.14159265358979323846;
double JsMath::SQRT1_2 = 0.70710678118654752440;
double JsMath::SQRT2   = 1.41421356237309504880;
#endif

#ifdef __sgi
#include <alloca.h> /* For alloca() on SGI */
#endif              /* (alloca() is defined in <malloc.h> on PC) */

// While parsing, function currently being defined:
VsFunctionDef *VsFunctionDef::curFunction = NULL;

VsFunctionDef::VsFunctionDef(const char *_name, VsParseTree *_parent)
{
    name = strdup(_name);
    numLocals = numArgs = 0;
    statements = NULL;
    parent = _parent;
    assert(curFunction == NULL);
    curFunction = this;
}

VsFunctionDef::~VsFunctionDef()
{
    free(name);
    for (int i = 0; i < argOrLocalNames.getLength(); i++) {
	char *n = (char *)argOrLocalNames[i];
	free(n);
    }
    if (statements != NULL)
	delete statements;

#ifdef __sgi
    // Make sure curFunction is set to NULL.  If there was a syntax
    // error inside a function, curFunction may be left in an unknown
    // state.  Make sure it is cleared here.
    curFunction = NULL;
#endif
}

void
VsFunctionDef::endDefinition(VsStatementList *stmnts)
{
    assert(curFunction == this);
    statements = stmnts;
    curFunction = NULL;
}

void
VsFunctionDef::addArg(const char *argName)
{
    assert(curFunction->numLocals == 0);

    ++curFunction->numArgs;
    curFunction->argOrLocalNames.append(strdup(argName));
}

VsVar *
VsFunctionDef::findIdentifier(const char *name)
{
    assert(curFunction != NULL);

    // Ok, look through local vars and arguments, last-defined first:
    for (int i = curFunction->getNumLocals()-1; i >= 0; i--) {
	const char *n = (const char *)curFunction->argOrLocalNames[i];
	if (strcmp(n, name) == 0) {
	    return new VsArgOrLocal(i);
	}
    }

    VsVar *result = curFunction->parent->getGlobalVar(name);

    if (result == NULL) {
	// Not found, create a new local variable:
	++curFunction->numLocals;
	curFunction->argOrLocalNames.append(strdup(name));
	result = new VsArgOrLocal(curFunction->getNumLocals()-1);
    }

    return result;
}

VsFunctionCall::VsFunctionCall(VsFunctionDef *_func, VsExprList &exprs)
{
    function = _func;

    for (int i = 0; i < exprs.getLength(); i++) {
	args[i] = exprs[i];
	args[i]->ref();
    }
    locals = NULL;
}

VsFunctionCall::~VsFunctionCall()
{
    for (int i = 0; i < args.getLength(); i++) {
	args[i]->unref();
    }
}

VsValue
VsFunctionCall::evaluate(VsFunctionCall *parent)
{
    returnValue.type = VsValue::vVOID;

    VsValue *callStack;  // Previous args, locals, needed if recursing

    // Gotta allocate new locals[].  Use alloca() for speed.
    callStack = locals;
    int numL = function->getNumLocals();

    if (numL == 0)
	locals = NULL;
    else {
        locals = (VsValue *)alloca(sizeof(VsValue)*function->getNumLocals());

        // Evaluate arguments:
	for (int i = 0; i < function->getNumArgs(); i++) {
	    locals[i] = args[i]->evaluate(parent);
	}

        // And give other locals/args a VOID value:
        for (i = function->getNumArgs(); i < function->getNumLocals(); i++) {
	    locals[i].type = VsValue::vVOID;  // ??? UNINIT ???
        }
    }

    // Execute statements until we get a return:
    VsStatementList *stmnts = function->statements;
    for (int i = 0; stmnts != NULL && i < stmnts->getLength(); i++) {
	VsStatement *stmt = (*stmnts)[i];
	VsStatement::Status s = stmt->execute(this);
	if (s == VsStatement::RETURN) {
	    break;
	}
    }

    // ??? Delete any string-valued args or locals ???

    // Unwind call stack
    locals = callStack;

    return returnValue;
}

void
VsFunctionCall::setReturnValue(const VsValue &val)
{
    returnValue = val;
}

VsValue
VsFunctionCall::getArg(int whichArg)
{
    if (whichArg >= function->getNumLocals()) {
	// Reference to un-passed param, return NULL value
	return VsValue::nothing;
    }
    return locals[whichArg];
}

void
VsFunctionCall::setArgOrLocal(int which, const VsValue &newVal)
{
    if (which < function->getNumLocals()) {
	locals[which] = newVal;
    }
}

int		
VsFunctionCall::isAnUnimplementedFunction(const char* fName)
{
    if (!strcmp(fName, "SFBool")) {
	return 1;
    } else if (!strcmp(fName, "SFColor")) {
	return 1;
    } else if (!strcmp(fName, "SFFloat")) {
	return 1;
    } else if (!strcmp(fName, "SFImage")) {
	return 1;
    } else if (!strcmp(fName, "SFInt32")) {
	return 1;
    } else if (!strcmp(fName, "SFNode")) {
	return 1;
    } else if (!strcmp(fName, "SFRotation")) {
	return 1;
    } else if (!strcmp(fName, "SFString")) {
	return 1;
    } else if (!strcmp(fName, "SFTime")) {
	return 1;
    } else if (!strcmp(fName, "SFVec2f")) {
	return 1;
    } else if (!strcmp(fName, "SFVec3f")) {
	return 1;
    } else if (!strcmp(fName, "MFColor")) {
	return 1;
    } else if (!strcmp(fName, "MFFloat")) {
	return 1;
    } else if (!strcmp(fName, "MFInt32")) {
	return 1;
    } else if (!strcmp(fName, "MFNode")) {
	return 1;
    } else if (!strcmp(fName, "MFRotation")) {
	return 1;
    } else if (!strcmp(fName, "MFString")) {
	return 1;
    } else if (!strcmp(fName, "MFVec2f")) {
	return 1;
    } else if (!strcmp(fName, "MFVec3f")) {
	return 1;
    } else if (!strcmp(fName, "parseInt")) {
	return 1;
    } else if (!strcmp(fName, "parseFloat")) {
	return 1;
    }

    return 0;
}

VsArgOrLocal::VsArgOrLocal(int _whichArg)
{
    whichArg = _whichArg;
}

VsArgOrLocal::~VsArgOrLocal()
{
}

VsValue
VsArgOrLocal::evaluate(VsFunctionCall *f)
{
    return f->getArg(whichArg);
}

VsValue
VsArgOrLocal::assign(const VsValue &v, VsFunctionCall *f)
{
    f->setArgOrLocal(whichArg, v);
    return v;
}

VsMethodCall::VsMethodCall(VsExpr* _obj,
			     const char* funcName,
			     VsExprList &exprs)
{
    obj = _obj;

    if (obj == NULL) {	    // MATH object is a special case
	if (!strcmp(funcName, "abs")) {
	    func = fABS;
	} else if (!strcmp(funcName, "acos")) {
	    func = fACOS;
	} else if (!strcmp(funcName, "asin")) {
	    func = fASIN;
	} else if (!strcmp(funcName, "atan")) {
	    func = fATAN;
	} else if (!strcmp(funcName, "ceil")) {
	    func = fCEIL;
	} else if (!strcmp(funcName, "cos")) {
	    func = fCOS;
	} else if (!strcmp(funcName, "exp")) {
	    func = fEXP;
	} else if (!strcmp(funcName, "floor")) {
	    func = fFLOOR;
	} else if (!strcmp(funcName, "log")) {
	    func = fLOG;
	} else if (!strcmp(funcName, "max")) {
	    func = fMAX;
	} else if (!strcmp(funcName, "min")) {
	    func = fMIN;
	} else if (!strcmp(funcName, "pow")) {
	    func = fPOW;
	} else if (!strcmp(funcName, "random")) {
	    func = fRANDOM;
	} else if (!strcmp(funcName, "round")) {
	    func = fROUND;
	} else if (!strcmp(funcName, "sin")) {
	    func = fSIN;
	} else if (!strcmp(funcName, "sqrt")) {
	    func = fSQRT;
	} else if (!strcmp(funcName, "tan")) {
	    func = fTAN;
	} else {
	    func = fUNKNOWN;
	}
    }

    for (int i = 0; i < exprs.getLength(); i++) {
	args[i] = exprs[i];
	args[i]->ref();
    }
}

VsMethodCall::~VsMethodCall()
{
    for (int i = 0; i < args.getLength(); i++) {
	args[i]->unref();
    }
}

VsValue
VsMethodCall::evaluate(VsFunctionCall *parent)
{
    returnValue.type = VsValue::vVOID;

    if (obj == NULL) {	// MATH
	switch (func) {
	    case fABS:
		returnValue.number = JsMath::abs((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fACOS:
		returnValue.number = JsMath::acos((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fASIN:
		returnValue.number = JsMath::asin((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fATAN:
		returnValue.number = JsMath::atan((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fCEIL:
		returnValue.number = JsMath::ceil((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fCOS:
		returnValue.number = JsMath::cos((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fEXP:
		returnValue.number = JsMath::exp((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fFLOOR:
		returnValue.number = JsMath::floor((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fLOG:
		returnValue.number = JsMath::log((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fMAX:
		returnValue.number = JsMath::max((args[0]->evaluate(parent)).number,
						 (args[1]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fMIN:
		returnValue.number = JsMath::min((args[0]->evaluate(parent)).number,
						 (args[1]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fPOW:
		returnValue.number = JsMath::pow((args[0]->evaluate(parent)).number,
						 (args[1]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fRANDOM:
		returnValue.number = JsMath::random();
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fROUND:
		returnValue.number = JsMath::round((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fSIN:
		returnValue.number = JsMath::sin((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fSQRT:
		returnValue.number = JsMath::sqrt((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fTAN:
		returnValue.number = JsMath::tan((args[0]->evaluate(parent)).number);
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case fUNKNOWN:
		returnValue.type = VsValue::vVOID;
		break;
	}
    }

    return returnValue;
}


VsMemberAccess::VsMemberAccess(VsExpr* _obj,
			     const char* memName)
{
    obj = _obj;

    if (obj == NULL) {	    // MATH object
	
	if (!strcmp(memName, "E")) {
	    member = mE;
	} else if (!strcmp(memName, "LN10")) {
	    member = mLN10;
	} else if (!strcmp(memName, "LN2")) {
	    member = mLN2;
	} else if (!strcmp(memName, "PI")) {
	    member = mPI;
	} else if (!strcmp(memName, "SQRT1_2")) {
	    member = mSQRT1_2;
	} else if (!strcmp(memName, "SQRT2")) {
	    member = mSQRT2;
	} 
    }
}

VsMemberAccess::~VsMemberAccess()
{
 
}

VsValue
VsMemberAccess::evaluate(VsFunctionCall *parent)
{
    returnValue.type = VsValue::vVOID;

    if (obj == NULL) {	// MATH object
	switch (member) {
	    case mE:
		returnValue.number = JsMath::E;
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case mLN10:
		returnValue.number = JsMath::LN10;
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case mLN2:
		returnValue.number = JsMath::LN2;
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case mPI:
		returnValue.number = JsMath::PI;
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case mSQRT1_2:
		returnValue.number = JsMath::SQRT1_2;
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case mSQRT2:
		returnValue.number = JsMath::SQRT2;
		returnValue.type   = VsValue::vNUMBER;
		break;
	    case mUNKNOWN:
		returnValue.type = VsValue::vVOID;
		break;
	}
    }

    return returnValue;
}
